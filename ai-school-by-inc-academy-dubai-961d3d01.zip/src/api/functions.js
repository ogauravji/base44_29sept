import { base44 } from './base44Client';


export const paymentWebhook = base44.functions.paymentWebhook;

export const generateCheckout = base44.functions.generateCheckout;

export const webhook = base44.functions.webhook;

export const syncEnrollments = base44.functions.syncEnrollments;

export const createInquiry = base44.functions.createInquiry;

export const sendConfirmationEmail = base44.functions.sendConfirmationEmail;

export const checkPaymentStatus = base44.functions.checkPaymentStatus;

export const subscribeNewsletter = base44.functions.subscribeNewsletter;

export const sendNewsletterEmail = base44.functions.sendNewsletterEmail;

export const sendAdminNotification = base44.functions.sendAdminNotification;

export const registerFreeCourse = base44.functions.registerFreeCourse;

export const registerAffiliate = base44.functions.registerAffiliate;

export const approveAffiliate = base44.functions.approveAffiliate;

export const trackAffiliateReferral = base44.functions.trackAffiliateReferral;

export const loginAffiliate = base44.functions.loginAffiliate;

export const getAffiliateStats = base44.functions.getAffiliateStats;

export const sendAffiliateEmails = base44.functions.sendAffiliateEmails;

export const debugAffiliate = base44.functions.debugAffiliate;

export const createTestAffiliate = base44.functions.createTestAffiliate;

export const listAllAffiliates = base44.functions.listAllAffiliates;

export const createSimpleAffiliate = base44.functions.createSimpleAffiliate;

export const createTestAffiliateWithProperHash = base44.functions.createTestAffiliateWithProperHash;

export const requestPasswordReset = base44.functions.requestPasswordReset;

export const resetPassword = base44.functions.resetPassword;

export const sendPasswordResetEmail = base44.functions.sendPasswordResetEmail;

export const sendPasswordResetConfirmation = base44.functions.sendPasswordResetConfirmation;

export const testUpdate = base44.functions.testUpdate;

export const requestPasswordResetSimple = base44.functions.requestPasswordResetSimple;

export const resetPasswordSimple = base44.functions.resetPasswordSimple;

export const debugAffiliateComplete = base44.functions.debugAffiliateComplete;

export const fixAffiliateLogin = base44.functions.fixAffiliateLogin;

