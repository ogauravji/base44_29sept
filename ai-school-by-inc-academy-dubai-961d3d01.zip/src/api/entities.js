import { base44 } from './base44Client';


export const Enrollment = base44.entities.Enrollment;

export const Inquiry = base44.entities.Inquiry;

export const Registration = base44.entities.Registration;

export const BlogPost = base44.entities.BlogPost;

export const Newsletter = base44.entities.Newsletter;

export const FreeCourseRegistration = base44.entities.FreeCourseRegistration;

export const AffiliateApplication = base44.entities.AffiliateApplication;

export const Affiliate = base44.entities.Affiliate;

export const AffiliateReferral = base44.entities.AffiliateReferral;



// auth sdk:
export const User = base44.auth;