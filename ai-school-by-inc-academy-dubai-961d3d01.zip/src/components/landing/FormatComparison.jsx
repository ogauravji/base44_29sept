import React, { useState } from "react";
import { motion, useInView } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Calendar,
  Clock,
  CheckCircle2,
  ArrowRight,
  Globe,
  Users,
  BookOpen,
  Zap,
  Target
} from "lucide-react";
import PaymentButton from "@/components/common/PaymentButton";
import InquiryFormModal from "@/components/common/InquiryFormModal";
import { Button } from "@/components/ui/button";

const programs = [
  {
    name: "Level 1: AI Skills Foundation",
    originalPriceUSD: "$1250",
    priceUSD: "$999",
    priceAED: "AED 3,250",
    duration: "5 Days (3 hours/day)",
    schedule: "Aug 26 - Aug 31, 2025",
    time: "7pm - 10pm Dubai Time",
    icon: Globe,
    popular: true,
    level: "Beginner to Intermediate",
    features: [
      "Live, interactive Zoom sessions",
      "Master 15+ AI tools and platforms",
      "Hands-on practical exercises",
      "Private WhatsApp group access",
      "Bonus: Workflow Automation Module",
      "AI Agent Creation Workshop",
      "200+ prompt library included",
      "Certificate of completion"
    ],
    courseType: "online-cohort"
  },
  {
    name: "Level 2: AI Skills Accelerator", 
    originalPriceUSD: "$1875",
    priceUSD: "$1500",
    priceAED: "AED 5,500",
    duration: "10 Days (3 hours/day)",
    schedule: "Sep 6 - Sep 20, 2025",
    time: "7pm - 10pm Dubai Time",
    icon: Target,
    popular: false,
    level: "Advanced",
    features: [
      "Advanced AI system development",
      "Custom AI agent deployment",
      "API integrations masterclass",
      "No-code automation platforms",
      "Predictive analytics with AI",
      "Full capstone project",
      "1-on-1 mentoring sessions",
      "Lifetime community access"
    ],
    courseType: "ai-accelerator"
  }
];

const freeWebinar = {
  name: "AI Skills to 10x Your Career in 2025",
  price: "$10",
  duration: "3 Hours",
  schedule: "March 10, 2025", 
  time: "6pm - 9pm Dubai Time",
  icon: BookOpen,
  features: [
    "Essential AI skills overview",
    "7 core tools every professional needs",
    "Hands-on exercises",
    "Career transformation roadmap",
    "Bonus: $500+ resource pack",
    "Live Q&A session"
  ],
  courseType: "mastermind-session"
};

export default function FormatComparison() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [isModalOpen, setIsModalOpen] = useState(false);

  const openModal = () => setIsModalOpen(true);

  return (
    <>
      <InquiryFormModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        title="Corporate & Group Bookings"
        subtitle="Please fill in your details, and our team will get back to you with customized group pricing."
      />
      <section ref={ref} id="programs" className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-16"
          >
            <Badge variant="outline" className="px-4 py-2 text-sm font-medium border-indigo-200 text-indigo-700 mb-6">
              <Calendar className="w-4 h-4 mr-2" />
              Choose Your Learning Path
            </Badge>

            <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
              AI Professional 
              <span className="bg-gradient-to-r from-indigo-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent"> Training Programs</span>
            </h2>

            <p className="text-xl text-gray-600 max-w-3xl mx-auto font-light">
              Start with our foundation course or jump into advanced AI system development. 
              All programs are live, online, and instructor-led.
            </p>
          </motion.div>

          {/* Free Webinar Section */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
            transition={{ duration: 0.6 }}
            className="mb-12"
          >
            <div className="text-center mb-8">
              <Badge className="bg-green-100 text-green-800 px-4 py-2 text-sm font-semibold mb-4">
                🔥 Special Introductory Session
              </Badge>
              <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
                Start Your AI Journey Here
              </h3>
            </div>
            
            <Card className="border-2 border-green-300 bg-gradient-to-br from-green-50 to-blue-50 max-w-4xl mx-auto">
              <CardContent className="p-8">
                <div className="grid md:grid-cols-3 gap-6 items-center">
                  <div className="md:col-span-2">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-600 rounded-xl flex items-center justify-center">
                        <freeWebinar.icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h4 className="text-xl font-bold text-gray-900">{freeWebinar.name}</h4>
                        <p className="text-green-600 font-semibold">{freeWebinar.duration} • {freeWebinar.schedule}</p>
                      </div>
                    </div>
                    
                    <div className="grid sm:grid-cols-2 gap-2 text-sm mb-4">
                      {freeWebinar.features.map((feature, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                          <span className="text-gray-700">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div className="text-center">
                    <div className="mb-4">
                      <span className="text-3xl font-bold text-green-600">{freeWebinar.price}</span>
                      <p className="text-sm text-gray-500">Introductory Offer</p>
                    </div>
                    <PaymentButton
                      courseType={freeWebinar.courseType}
                      className="w-full bg-green-600 hover:bg-green-700 text-white py-3 font-semibold rounded-xl"
                    >
                      Join 3-Hour Session
                    </PaymentButton>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          {/* Main Programs */}
          <div className="grid lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
            {programs.map((program, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
                transition={{ duration: 0.6, delay: (index + 1) * 0.2 }}
                className="h-full"
              >
                <Card className={`relative h-full flex flex-col transition-all duration-300 hover:shadow-2xl border-2 overflow-hidden rounded-2xl ${
                  program.popular 
                    ? 'border-indigo-600 bg-indigo-50/30' 
                    : 'border-gray-200 bg-white'
                }`}>
                  
                  <CardHeader className="p-8 relative">
                    {program.popular && (
                      <Badge className="absolute top-6 right-6 bg-indigo-100 text-indigo-800 border-indigo-200 font-semibold shadow-sm">
                        Most Popular
                      </Badge>
                    )}
                    <div className="flex items-center gap-4 mb-4">
                        <div className={`w-14 h-14 rounded-xl flex items-center justify-center shadow-lg ${
                            program.popular
                            ? 'bg-gradient-to-r from-indigo-600 to-cyan-600'
                            : 'bg-gradient-to-r from-gray-600 to-gray-700'
                        }`}>
                            <program.icon className="w-7 h-7 text-white" />
                        </div>
                        <div>
                          <CardTitle className="text-xl font-bold text-gray-900">
                              {program.name}
                          </CardTitle>
                          <p className="text-sm text-gray-600">{program.level}</p>
                        </div>
                    </div>
                  </CardHeader>

                  <CardContent className="p-8 pt-0 flex-grow flex flex-col">
                    {/* Pricing */}
                    <div className="mb-6">
                        <p className="text-4xl font-extrabold text-gray-900">{program.priceAED}</p>
                        <p className="text-base text-gray-500 mt-1">
                            <span className="line-through">{program.originalPriceUSD}</span> / approx. {program.priceUSD}
                        </p>
                        <Badge variant="destructive" className="mt-2 animate-pulse bg-gradient-to-r from-red-500 to-orange-500 text-white border-0 font-medium">20% OFF - LIMITED TIME</Badge>
                    </div>

                    {/* CTA Button */}
                    <div className="mb-6">
                        <PaymentButton
                        courseType={program.courseType}
                        className={`w-full py-4 text-lg font-semibold rounded-xl transition-all duration-300 group ${
                            program.popular
                            ? 'bg-gradient-to-r from-indigo-600 to-cyan-600 text-white shadow-lg hover:shadow-xl'
                            : 'bg-gray-900 hover:bg-gray-800 text-white'
                        }`}
                        >
                        Enroll Now
                        <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                        </PaymentButton>
                    </div>

                    <div className="h-px bg-gray-200 my-2"></div>
                    
                    {/* Features */}
                    <div className="space-y-3 my-6 flex-grow">
                        {program.features.map((feature, featureIndex) => (
                        <div key={featureIndex} className="flex items-start gap-3">
                            <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                            <span className="text-gray-700">{feature}</span>
                        </div>
                        ))}
                    </div>

                    <div className="h-px bg-gray-200 my-2"></div>

                    {/* Key Details */}
                    <div className="space-y-3 mt-6 text-sm">
                        <div className="flex items-center gap-3 text-gray-600">
                        <Clock className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                        <span className="font-medium">Duration:</span>
                        <span>{program.duration}</span>
                        </div>
                        <div className="flex items-center gap-3 text-gray-600">
                        <Calendar className="w-4 h-4 text-indigo-500 flex-shrink-0" />
                        <span className="font-medium">Schedule:</span>
                        <span>{program.schedule}</span>
                        </div>
                        <div className="flex items-center gap-3 text-gray-600">
                        <Globe className="w-4 h-4 text-teal-500 flex-shrink-0" />
                        <span className="font-medium">Time:</span>
                        <span>{program.time}</span>
                        </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>

          {/* Additional Info */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-center mt-12"
          >
            <p className="text-gray-600 mb-4">
              Need a custom package for your team?
              <Button variant="link" className="text-indigo-600 font-semibold p-1" onClick={openModal}>
                Contact us for group pricing
              </Button>
            </p>
            <p className="text-sm text-gray-500">
              All programs include lifetime access to course materials and community
            </p>
          </motion.div>
        </div>
      </section>
    </>
  );
}