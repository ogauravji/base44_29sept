
import React from "react";
import { motion, useInView } from "framer-motion";

const companyLogos = [
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/b7bb72bd5_1.png", // Costa
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/54cb14092_2.png", // Benefit
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/6ce71c7b9_3.png", // Emirates
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/910e47e93_13.png", // Alshaya
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/45004e39e_14.png", // Mediclinic
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d3663da03_19.png", // ZeeTV
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/33b319724_21.png", // Pepsico
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/0413d9ed3_22.png", // Unilever
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/95ee0ace2_25.png", // Samsung
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/990c50322_26.png", // Jaguar Land Rover
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/aecf564fd_28.png", // Flydubai
  "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/55767bffa_15.png", // Saudi Tourism
];

export default function ClientLogos() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const logoVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: i * 0.1,
        duration: 0.5,
      },
    }),
  };

  return (
    <section ref={ref} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-lg text-gray-600 uppercase tracking-wider font-semibold">
            Past Candidates from brands
          </p>
        </div>
        
        <motion.div
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
          className="bg-white rounded-3xl p-8 sm:p-12 shadow-2xl ring-1 ring-gray-200/50"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-x-8 gap-y-12 items-center">
            {companyLogos.map((logo, index) => (
              <motion.div
                key={index}
                custom={index}
                variants={logoVariants}
                className="flex items-center justify-center h-16 transition-transform duration-300 hover:scale-110"
              >
                <img 
                  src={logo} 
                  alt={`Client logo ${index + 1}`} 
                  className="max-h-12 w-auto object-contain filter grayscale hover:grayscale-0 transition-all duration-300" 
                />
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
