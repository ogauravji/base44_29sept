import React, { useState } from "react";
import { motion, useInView } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, CheckCircle2 } from "lucide-react";

export default function LeadMagnet() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <section ref={ref} className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-indigo-50 via-purple-50/70 to-pink-50/50 relative overflow-hidden">
      {/* Background decorative elements */}
      <div className="absolute top-10 right-10 w-64 h-64 bg-gradient-to-r from-indigo-200/30 to-purple-200/20 rounded-full blur-3xl"></div>
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-gradient-to-r from-purple-200/30 to-pink-200/20 rounded-full blur-3xl"></div>
      
      <div className="max-w-4xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
        >
          <div className="bg-gradient-to-br from-white/90 to-indigo-50/80 rounded-3xl p-8 sm:p-12 shadow-2xl backdrop-blur-sm border border-white/50">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl w-20 h-20 flex items-center justify-center mx-auto mb-8 shadow-lg">
              <Download className="w-10 h-10 text-white" />
            </div>
            
            <h2 className="text-4xl sm:text-5xl font-bold mb-6 text-gray-900">
              Get Your Free
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent block mt-2"> AI Toolkit</span>
            </h2>
            
            <p className="text-xl text-gray-700 mb-8 max-w-2xl mx-auto leading-relaxed">
              Download "25 High-Converting AI Prompts" - the same templates 
              our graduates use to create campaigns, copy, and content that converts.
            </p>

            {!isSubmitted ? (
              <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-8">
                <Input
                  type="email"
                  placeholder="Enter your business email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="bg-white border-indigo-200 text-gray-900 placeholder:text-gray-500 focus:border-indigo-400 shadow-sm"
                />
                <Button 
                  type="submit" 
                  className="bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white px-8 whitespace-nowrap font-semibold shadow-lg"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Get Free Toolkit
                </Button>
              </form>
            ) : (
              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center justify-center gap-3 text-green-600 mb-8 bg-green-50 p-4 rounded-xl border border-green-200"
              >
                <CheckCircle2 className="w-6 h-6" />
                <span className="text-lg font-semibold">Check your email for the download link!</span>
              </motion.div>
            )}

            <div className="flex flex-wrap justify-center items-center gap-6 text-sm text-gray-600 mb-8">
              <div className="flex items-center gap-2 bg-white/70 px-4 py-2 rounded-full border border-indigo-100">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <span>Instant Download</span>
              </div>
              <div className="flex items-center gap-2 bg-white/70 px-4 py-2 rounded-full border border-purple-100">
                <div className="w-2 h-2 bg-indigo-500 rounded-full"></div>
                <span>No Spam Policy</span>
              </div>
              <div className="flex items-center gap-2 bg-white/70 px-4 py-2 rounded-full border border-pink-100">
                <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                <span>Unsubscribe Anytime</span>
              </div>
            </div>

            <p className="text-sm text-gray-500">
              Join 9,000+ professionals who trust our insights and resources.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}