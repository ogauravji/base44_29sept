
import React from "react";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Calendar, Clock, Users } from "lucide-react";
import PaymentButton from "../common/PaymentButton";
import Countdown from "./Countdown";

export default function BookingSection({
  courseType,
  courseName,
  price,
  nextBatchDate,
  duration,
  seatsLeft,
  features,
  targetDate, // Add targetDate to props
}) {
  return (
    <section id="booking-section" className="py-12 md:py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4">
        <Card className="shadow-2xl border-2 border-blue-200 rounded-3xl overflow-hidden">
          <div className="grid lg:grid-cols-2">
            {/* Left side: Features */}
            <div className="p-6 md:p-8 bg-white">
              <h3 className="text-2xl font-bold text-gray-900 mb-4">What You'll Get</h3>
              <ul className="space-y-3">
                {features.map((feature, index) => (
                  <li key={index} className="flex items-center gap-3">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Right side: Booking */}
            <div className="p-6 md:p-8 bg-gradient-to-br from-blue-500 to-indigo-600 text-white">
              <CardHeader className="p-0 mb-4">
                <Badge variant="secondary" className="mb-2 w-fit bg-yellow-400 text-black font-semibold">Limited Seats Available</Badge>
                <CardTitle className="text-3xl font-bold">{courseName}</CardTitle>
                <div className="text-4xl font-bold mt-2">${price}</div>
              </CardHeader>
              <CardContent className="p-0">
                <div className="space-y-3 text-blue-100 mb-6">
                  {nextBatchDate && <div className="flex items-center gap-2"><Calendar className="w-5 h-5"/><span>Next Batch: <strong>{nextBatchDate}</strong></span></div>}
                  <div className="flex items-center gap-2"><Clock className="w-5 h-5"/><span>Duration: <strong>{duration}</strong></span></div>
                  <div className="flex items-center gap-2"><Users className="w-5 h-5"/><span>Only <strong>{seatsLeft}</strong> seats left!</span></div>
                </div>

                <div className="mb-6">
                    <p className="text-center text-sm text-yellow-300 font-semibold mb-2">Offer ends in:</p>
                    {targetDate && <Countdown targetDate={targetDate} />}
                </div>
                
                <PaymentButton
                  courseType={courseType}
                  courseName={courseName}
                  price={price}
                  className="w-full bg-yellow-400 hover:bg-yellow-500 text-black font-bold text-lg py-3 rounded-lg shadow-lg"
                >
                  Enroll Now for ${price}
                </PaymentButton>
              </CardContent>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}
