import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, PlayCircle, Star, Users, Calendar, Award, Brain, X } from "lucide-react";
import { motion } from "framer-motion";
import InquiryFormModal from "@/components/common/InquiryFormModal";
import PaymentButton from "@/components/common/PaymentButton";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function HeroSection() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isVideoModalOpen, setIsVideoModalOpen] = useState(false);

  const openModal = () => setIsModalOpen(true);
  const openVideoModal = () => setIsVideoModalOpen(true);

  return (
    <>
      <InquiryFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Join the AI Masterclass"
        subtitle="Reserve your spot and transform your work with AI." />

      {/* Video Modal */}
      {isVideoModalOpen &&
      <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50" onClick={() => setIsVideoModalOpen(false)}>
          <div className="relative max-w-4xl mx-4 w-full" onClick={(e) => e.stopPropagation()}>
            <button
            onClick={() => setIsVideoModalOpen(false)}
            className="absolute -top-8 right-0 text-white hover:text-gray-300 transition-colors"
            aria-label="Close video">

              <X className="w-8 h-8" />
            </button>
            <div className="aspect-video bg-black rounded-xl overflow-hidden">
              <iframe
              width="100%"
              height="100%"
              src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1"
              title="AI Masterclass Preview"
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full">
            </iframe>
            </div>
          </div>
        </div>
      }

      <section className="relative min-h-screen flex items-center justify-center pt-16 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-50 via-cyan-50/50 to-teal-50/40"></div>
        <div className="absolute top-10 right-20 w-80 h-80 bg-gradient-to-br from-indigo-200/25 to-cyan-200/15 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-10 left-20 w-96 h-96 bg-gradient-to-tr from-cyan-200/20 to-teal-200/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
        <div className="absolute top-1/2 right-1/4 w-64 h-64 bg-gradient-to-r from-teal-200/15 to-indigo-200/20 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '4s' }}></div>
        
        <div className="relative max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="text-center lg:text-left">
              {/* Badge */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="mb-8">

                <Badge variant="outline" className="inline-flex items-center px-6 py-3 text-base font-medium bg-white/95 border-indigo-300 text-indigo-800 shadow-lg backdrop-blur-sm">
                  <Award className="w-5 h-5 mr-2" />
                  AI Skills for Every Professional
                </Badge>
              </motion.div>

              {/* Main Headline */}
              <motion.h1
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-4xl sm:text-5xl lg:text-7xl font-bold text-gray-900 mb-6 leading-tight">

                Master AI Skills
                <span className="bg-gradient-to-r from-indigo-600 via-cyan-600 to-teal-600 bg-clip-text text-transparent block mt-2">
                  Drive 10X Growth
                </span>
              </motion.h1>

              {/* Subheadline */}
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }} 
                className="text-gray-700 mb-8 mx-auto text-base font-light sm:text-2xl max-w-3xl lg:mx-0 leading-relaxed">
                Transform your business operations with AI. Learn from 9,000+ professionals who've implemented our frameworks to <span className="font-semibold text-indigo-700">reduce operational costs by 70%</span> and <span className="font-semibold text-teal-700">increase productivity by 300%</span>
              </motion.p>

              {/* Key Benefits */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
                className="flex flex-wrap justify-center lg:justify-start items-center gap-6 mb-12 text-sm text-gray-800">

                <div className="flex items-center gap-2 bg-white/90 px-4 py-2 rounded-full shadow-md border border-indigo-100 backdrop-blur-sm">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                  <span className="font-medium">No Coding Required</span>
                </div>
                <div className="flex items-center gap-2 bg-white/90 px-4 py-2 rounded-full shadow-md border border-cyan-100 backdrop-blur-sm">
                  <div className="w-2 h-2 bg-cyan-500 rounded-full animate-pulse" style={{ animationDelay: '1s' }}></div>
                  <span className="font-medium">Business-Ready Tools</span>
                </div>
                <div className="flex items-center gap-2 bg-white/90 px-4 py-2 rounded-full shadow-md border border-teal-100 backdrop-blur-sm">
                  <div className="w-2 h-2 bg-teal-500 rounded-full animate-pulse" style={{ animationDelay: '2s' }}></div>
                  <span className="font-medium">ROI-Focused Strategies</span>
                </div>
              </motion.div>

              {/* CTA Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start items-center mb-8">

                 <Link to={createPageUrl("Level1Foundation")}>
                    <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-xl shadow-lg group w-full sm:w-auto">
                        View Level 1 Program
                        <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                </Link>
                <Link to={createPageUrl("Level2Accelerator")}>
                    <Button size="lg" variant="outline" className="w-full sm:w-auto">
                        Explore Level 2
                    </Button>
                </Link>
              </motion.div>
            </div>

            {/* Hero Image/Video Section */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.4 }}
              className="relative">

              <div className="bg-gradient-to-br from-white/95 to-indigo-50/80 rounded-3xl p-8 shadow-2xl backdrop-blur-lg border border-white/60 ring-1 ring-indigo-200/20">
                <div
                  className="flex items-center justify-center h-64 bg-gradient-to-br from-indigo-50 to-cyan-50 rounded-2xl cursor-pointer group hover:from-indigo-100 hover:to-cyan-100 transition-all duration-300 border border-indigo-200/50 shadow-inner"
                  onClick={openVideoModal}>

                  <div className="flex flex-col items-center">
                    <div className="w-16 h-16 bg-gradient-to-r from-indigo-600 via-cyan-600 to-teal-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300 shadow-xl">
                      <PlayCircle className="w-8 h-8 text-white" />
                    </div>
                    <span className="text-lg font-semibold text-gray-800">Watch Free Masterclass Preview</span>
                    <span className="text-sm text-gray-600">See what industry leaders are saying (3 min)</span>
                  </div>
                </div>
                
                {/* Stats overlay on image */}
                <div className="mt-6 grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-white/80 rounded-xl border border-indigo-100 shadow-sm backdrop-blur-sm">
                    <div className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-cyan-600 bg-clip-text text-transparent">10+hrs</div>
                    <div className="text-sm text-gray-600">Hands-on Intensive Training</div>
                  </div>
                  <div className="text-center p-4 bg-white/80 rounded-xl border border-cyan-100 shadow-sm backdrop-blur-sm">
                    <div className="text-2xl font-bold bg-gradient-to-r from-cyan-600 to-teal-600 bg-clip-text text-transparent">50+</div>
                    <div className="text-sm text-gray-600">AI Tools Covered</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-wrap justify-center items-center gap-12 mt-16 text-sm text-gray-600">

            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">9,000+</div>
              <div>Professionals Trained</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">15+</div>
              <div>Years Experience</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">4.9/5</div>
              <div className="flex items-center justify-center gap-1 mt-1">
                {[...Array(5)].map((_, i) =>
                <Star key={i} className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                )}
              </div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-gray-900">300+</div>
              <div>Agencies Consulting</div>
            </div>
          </motion.div>
        </div>
      </section>
    </>);

}