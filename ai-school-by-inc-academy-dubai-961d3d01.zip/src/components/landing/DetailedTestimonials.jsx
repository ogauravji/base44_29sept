import React from "react";
import { motion, useInView } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Quote } from "lucide-react";

const testimonialsData = [
  {
    quote: "This program completely transformed how we approach marketing. Within 60 days of implementing Gaurav's AI frameworks, we reduced our content creation costs by 65% while increasing lead quality by 240%. The strategic approach to AI adoption was exactly what we needed.",
    author: "Sarah Ahmad",
    role: "Chief Marketing Officer",
    industry: "SaaS",
    avatar: "SA",
    rating: 5
  },
  {
    quote: "As a founder, I was skeptical about AI replacing human creativity. Gaurav showed us how AI amplifies human strategy instead. We launched 5 new product campaigns in one quarter - something that would have taken us a year before. The ROI frameworks are game-changing.",
    author: "Ahmed Al-Rashid",
    role: "Founder & CEO",
    industry: "E-commerce",
    avatar: "AA",
    rating: 5
  },
  {
    quote: "The most practical and immediately actionable training I've attended in 15 years. Gaurav's real-world experience shows in every module. We implemented his prompt engineering framework and saw our email open rates jump from 18% to 42% within 3 weeks.",
    author: "Lisa Chen",
    role: "Marketing Director",
    industry: "Real Estate",
    avatar: "LC",
    rating: 5
  }
];

const TestimonialCard = ({ testimonial }) => {
  return (
    <Card className="h-full border-0 bg-white shadow-lg hover:shadow-xl transition-all duration-300 flex flex-col">
      <CardContent className="p-6 sm:p-8 flex-grow flex flex-col">
        <div className="flex-grow">
          <Quote className="w-8 h-8 text-gray-200 mb-4" />
          <p className="text-gray-600 text-base sm:text-lg leading-relaxed mb-6 italic">
            "{testimonial.quote}"
          </p>
        </div>

        {/* Author Info */}
        <div className="flex items-center gap-4 pt-4 border-t border-gray-100">
          <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full flex items-center justify-center text-white font-bold text-lg">
            {testimonial.avatar}
          </div>
          <div className="flex-1">
            <p className="font-bold text-gray-900">{testimonial.author}</p>
            <p className="text-sm text-gray-500">{testimonial.role}, {testimonial.industry}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default function DetailedTestimonials() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true });

  return (
    <section ref={ref} className="bg-gray-50 py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto space-y-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center"
        >
          <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl">
            Don't Just Take Our Word For It
          </h2>
          <p className="mt-4 text-lg leading-8 text-gray-600">
            Hear from professionals who have transformed their careers with our AI training.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 gap-12 lg:grid-cols-3 lg:gap-8">
          {testimonialsData.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
            >
              <TestimonialCard testimonial={testimonial} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}