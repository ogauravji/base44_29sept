
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, HelpCircle } from "lucide-react";

const faqData = {
  General: [
    {
      q: "Do I need any prior AI knowledge or technical skills?",
      a: "Not at all. This course is designed for professionals from all backgrounds. We start with the fundamentals and frankly, focus on practical, non-technical applications of AI that you can use immediately. This is not for software engineers, but for business leaders and professionals who need to USE AI immediately. Think of it like this: You learn to drive a car and use it as an advantage. You do not need to know how the engine works to achieve this. Similar concept here."
    },
    {
      q: "Who is the trainer for this course?",
      a: "The course is led by Gaurav Oberoi, a globally recognized expert with over 15 years of experience and a former regional trainer for Google. He has trained over 9,000 professionals across the MENA region, including executives from ADNOC, Emirates NBD, MBC, and more. He is also a visiting lecturer at the London Business School, Hult International Business School, and others."
    },
    {
      q: "What makes this course different from other AI training programs?",
      a: "Our course focuses on practical business applications rather than technical theory. You'll learn to implement AI tools immediately in your work, with real-world examples and hands-on exercises tailored for executives and business leaders."
    },
    {
      q: "Is this course suitable for non-technical professionals?",
      a: "Absolutely! The course is specifically designed for business professionals, executives, and anyone looking to leverage AI. No coding or technical background is required. We focus on using AI tools through user-friendly interfaces."
    },
    {
      q: "What industries can benefit from this training?",
      a: "This training is applicable across all industries including retail, finance, healthcare, real estate, FMCG, technology, consulting, and more. The AI frameworks taught are universal and can be adapted to any business context."
    },
    {
      q: "How will I join the session?",
      a: "You'll receive a Zoom/Google Meet link by email 24 hours before the session."
    },
    {
      q: "Do I need to install any software before the class?",
      a: "No special software is required. We'll guide you on free AI tools you can use directly in your browser."
    },
    {
      q: "What should I prepare before attending?",
      a: "Ensure a stable internet connection, a laptop/desktop, and a distraction-free environment."
    },
    {
      q: "Can I join from my phone or tablet?",
      a: "Yes, but for best participation and hands-on activities, we recommend a laptop or desktop."
    },
    {
      q: "Will there be hands-on exercises?",
      a: "Yes. All sessions are designed to be practical, with live demos and exercises."
    }
  ],
  "Course Content": [
    {
      q: "What's included in the Level 1 AI Skills Foundation program?",
      a: "Level 1 includes 5 live sessions (3 hours each) covering AI fundamentals, 15+ tools, hands-on exercises, bonus automation module, community access, and certification. Perfect for beginners to intermediate users."
    },
    {
      q: "What's covered in the Level 2 AI Skills Accelerator program?",
      a: "Level 2 is our advanced 30-hour program covering AI API integrations, custom agent development, advanced automation, predictive analytics, and a full capstone project where you deploy an AI solution for a real business use case."
    },
    {
      q: "Will I receive a certificate upon completion?",
      a: "Yes, upon successful completion of either program, you will receive a digital certificate from Inc. Academy, which you can share on your LinkedIn profile and resume."
    },
    {
      q: "What specific AI tools will I learn?",
      a: "You'll master ChatGPT, Claude, Midjourney, Canva AI, Notion AI, and 15+ other cutting-edge tools. Level 2 includes API integrations with OpenAI, Make.com, Zapier, and custom AI development platforms."
    },
    {
      q: "Are the course materials updated regularly?",
      a: "Yes, our curriculum is continuously updated to reflect the latest AI developments and tools. We ensure you're learning the most current and effective strategies in the rapidly evolving AI landscape."
    },
    {
      q: "Is there homework or assignments?",
      a: "Yes, each session includes practical exercises and real-world projects that you can immediately implement in your work. These hands-on assignments ensure you gain practical experience, not just theoretical knowledge."
    },
    {
      q: "I'm already using ChatGPT/AI — will this still be useful?",
      a: "Yes. Even experienced users will discover advanced strategies, frameworks, and workflows they've never seen before."
    },
    {
      q: "Can beginners attend?",
      a: "Yes. We start with fundamentals and progress to advanced use cases quickly."
    },
    {
      q: "Will you cover examples relevant to my industry?",
      a: "Yes. We share use cases across marketing, FMCG, B2B, retail, eCommerce, services, and more."
    }
  ],
  "Logistics & Support": [
    {
      q: "How are the bootcamps delivered?",
      a: "Both our online cohort and in-person bootcamp in Dubai are live and interactive, led by expert trainers. You'll participate in hands-on exercises and real-time Q&A."
    },
    {
      q: "What if I can't attend a live session?",
      a: "You can reschedule to another cohort date with at least 48 hours notice. Our methodology relies on live participation for optimal results."
    },
    {
      q: "Can I retake the course?",
      a: "Yes, graduates can re-attend the same course for 25% discount within 12 months, subject to availability. This allows you to refresh your skills in the fast-evolving field of AI."
    }
  ],
  "Technical Requirements": [
    {
      q: "What technical requirements do I need for the online program?",
      a: "You'll need a reliable internet connection, a computer or laptop with a webcam and microphone, and access to Zoom. We'll provide detailed setup instructions before the course begins."
    },
    {
      q: "Do I need to purchase any AI tools or software?",
      a: "Some tools offer free tiers that are sufficient for learning, while others may require subscriptions. We'll provide guidance on which tools to invest in based on your specific needs and budget."
    },
    {
      q: "Will I get access to premium AI tool accounts?",
      a: "While we don't provide account access, we'll show you how to maximize free tiers and guide you on which premium subscriptions offer the best ROI for your specific use case."
    }
  ],
  "Outcomes & Policies": [
    {
      q: "Is there ongoing support after the course?",
      a: "Yes! You'll get lifetime access to our private WhatsApp community where you can ask questions, share experiences, and network with fellow graduates and industry experts."
    },
    {
      q: "Do you provide job placement assistance?",
      a: "While this is not a job placement program, the skills you learn will significantly enhance your employability. We focus on practical skills for career growth, resume enhancement, and leveraging AI in job searches."
    },
    {
      q: "Are there advanced courses available?",
      a: "Yes! Our Level 2 AI Skills Accelerator is perfect for graduates wanting advanced training. We also regularly offer specialized workshops with exclusive pricing for graduates."
    },
    {
      q: "Can I retake the course?",
      a: "Graduates can attend future sessions at a 50% discount, subject to availability. This allows you to refresh your knowledge and learn about new tools and techniques."
    },
    {
      q: "Will I get session materials?",
      a: "Yes. You'll receive templates, cheat sheets, and resources after the session."
    },
    {
      q: "Will there be follow-up support?",
      a: "For Level 1 and Level 2 courses, yes — you'll be added to a private group for ongoing Q&A."
    },
    {
      q: "What if I have questions after the workshop?",
      a: "You can email us or join our private group (for eligible programs)."
    },
    {
      q: "Will there be another batch if I can't attend?",
      a: "Yes, we run these sessions regularly. Check the website for upcoming dates."
    }
  ],
  "Business Impact": [
    {
      q: "How quickly will I see ROI from this training?",
      a: "Most participants report immediate improvements in productivity and efficiency. Within 30 days of completing the course, you should see measurable improvements in your work processes and output quality."
    },
    {
      q: "Can I implement these strategies in my current role immediately?",
      a: "Absolutely! The course is designed for immediate implementation. You'll leave with actionable strategies, templates, and tools that you can start using right away in your current position."
    },
    {
      q: "Will this help me advance in my career?",
      a: "Yes, AI skills are increasingly becoming essential for career advancement. This training positions you as an AI-savvy professional, making you more valuable to current and future employers."
    }
  ]
};

const FAQItem = ({ faq, isOpen, onClick }) => (
  <div className="border-b border-gray-200 last:border-b-0">
    <button
      onClick={onClick}
      className="w-full flex justify-between items-center text-left py-6 px-6 group"
    >
      <span className={`text-lg font-medium transition-colors duration-300 ${isOpen ? 'text-blue-600' : 'text-gray-800 group-hover:text-blue-600'}`}>{faq.q}</span>
      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center transition-all duration-300 ${isOpen ? 'bg-blue-600 text-white rotate-90' : 'bg-gray-100 group-hover:bg-blue-100 text-gray-500'}`}>
        <ChevronRight
          className={`transform transition-transform duration-300 w-5 h-5`}
        />
      </div>
    </button>
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: 0.3, ease: "easeInOut" }}
        >
          <div className="pb-6 px-6">
            <p className="text-gray-600 leading-relaxed">{faq.a}</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  </div>
);

export default function ProfessionalFAQ() {
  const [activeCategory, setActiveCategory] = useState("General");
  const [openFAQ, setOpenFAQ] = useState(0);

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50/70">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <Badge variant="outline" className="px-4 py-2 text-sm font-medium border-purple-200 text-purple-700 mb-6">
            <HelpCircle className="w-4 h-4 mr-2" />
            Your Questions Answered
          </Badge>
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900">
            Frequently Asked 
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent"> Questions</span>
          </h2>
        </div>

        <div className="grid lg:grid-cols-4 gap-12">
          <div className="lg:col-span-1">
            <div className="sticky top-28">
              <h3 className="text-xl font-bold mb-6 text-gray-800">Categories</h3>
              <div className="space-y-2">
                {Object.keys(faqData).map((category) => (
                  <button
                    key={category}
                    onClick={() => {
                      setActiveCategory(category);
                      setOpenFAQ(0);
                    }}
                    className={`w-full text-left px-4 py-3 rounded-lg transition-all duration-300 font-medium ${
                      activeCategory === category
                        ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
                        : "hover:bg-blue-50 hover:text-blue-700 text-gray-600"
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="bg-white rounded-2xl overflow-hidden shadow-xl border border-gray-100">
              {faqData[activeCategory].map((faq, index) => (
                <FAQItem
                  key={index}
                  faq={faq}
                  isOpen={openFAQ === index}
                  onClick={() => setOpenFAQ(openFAQ === index ? -1 : index)}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
