import React, { useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Clock, DollarSign, BrainCircuit } from 'lucide-react';

export default function ROI_Calculator() {
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const [teamSize, setTeamSize] = useState(10);
  const [avgSalary, setAvgSalary] = useState(15000);

  const calculateROI = () => {
    const timeSavedPerWeek = teamSize * 5; // Assuming 5 hours saved per employee per week
    const productivityGain = timeSavedPerWeek * 4 * 12; // Per year
    const costSavings = avgSalary / (40 * 4) * productivityGain; // Annual savings

    return {
      timeSaved: productivityGain.toLocaleString(),
      costSavings: costSavings.toLocaleString('en-US', { style: 'currency', currency: 'AED', minimumFractionDigits: 0 })
    };
  };

  const { timeSaved, costSavings } = calculateROI();

  return (
    <section ref={ref} className="bg-white px-4 py-6 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 30 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16">

          <Badge variant="outline" className="px-6 py-3 text-base font-medium border-purple-200 text-purple-700 mb-8">
            <BrainCircuit className="w-5 h-5 mr-2" />
            Calculate Your AI ROI
          </Badge>
          
          <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
            Unlock Your Team's
            <span className="bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent"> Potential</span>
          </h2>
          
          <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
            Use our interactive calculator to estimate the potential time and cost savings 
            your organization could achieve by implementing the AI frameworks taught in our course.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
          transition={{ duration: 0.8, delay: 0.4 }}>

          <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center bg-gray-50 p-8 rounded-3xl shadow-lg">
            {/* Calculator Inputs */}
            <div className="space-y-8">
              <div>
                <label className="text-lg font-semibold text-gray-800">Team Size</label>
                <div className="flex items-center gap-4 mt-2">
                  <Slider
                    value={[teamSize]}
                    onValueChange={(value) => setTeamSize(value[0])}
                    max={100}
                    step={1}
                    className="w-full" />

                  <span className="font-bold text-xl text-purple-600 w-16 text-center">{teamSize}</span>
                </div>
              </div>
              <div>
                <label className="text-lg font-semibold text-gray-800">Average Monthly Salary (AED)</label>
                <div className="flex items-center gap-4 mt-2">
                  <Slider
                    value={[avgSalary]}
                    onValueChange={(value) => setAvgSalary(value[0])}
                    min={5000}
                    max={50000}
                    step={1000}
                    className="w-full" />

                  <span className="font-bold text-xl text-purple-600 w-24 text-center">{avgSalary.toLocaleString()}</span>
                </div>
              </div>
            </div>

            {/* Results Display */}
            <div className="text-center bg-gradient-to-br from-purple-600 to-blue-600 text-white p-8 rounded-2xl">
              <h3 className="text-2xl font-bold mb-6">Estimated Annual ROI</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="bg-white/20 p-6 rounded-xl">
                  <Clock className="w-8 h-8 mx-auto mb-3" />
                  <p className="text-3xl text-xs font-bold">{timeSaved}</p>
                  <p className="text-purple-200">Hours Saved</p>
                </div>
                <div className="bg-white/20 p-6 rounded-xl">
                  <DollarSign className="w-8 h-8 mx-auto mb-3" />
                  <p className="text-3xl text-xs font-bold">{costSavings}</p>
                  <p className="text-purple-200">Productivity Gain</p>
                </div>
              </div>
              <p className="text-sm mt-6 text-purple-200 opacity-80">
                *Estimates are based on an average of 5 hours saved per employee per week. Actual results may vary.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>);

}