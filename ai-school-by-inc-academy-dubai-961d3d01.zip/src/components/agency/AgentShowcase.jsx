import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Megaphone, 
  Users, 
  HeartHandshake, 
  Building2, 
  GraduationCap, 
  Plane,
  TrendingUp,
  ShoppingBag,
  Package,
  Home,
  Bot,
  Banknote,
  Sparkles,
  Zap,
  Target
} from 'lucide-react';
import { motion } from 'framer-motion';

const agentData = {
  "Marketing & Advertising": {
    icon: Megaphone,
    color: "from-purple-500 to-pink-500",
    bgColor: "bg-gradient-to-r from-purple-50 to-pink-50",
    agents: [
      { 
        title: "Campaign Optimizer Agent", 
        description: "Adjusts budgets, creatives, and audience targeting in real-time across platforms.",
        icon: Target
      },
      { 
        title: "Customer Persona Generator", 
        description: "Builds dynamic personas using CRM, web analytics, and sales data.",
        icon: Users
      },
      { 
        title: "AI Creative Brief Assistant", 
        description: "Converts product or promo goals into AI-ready creative briefs for content or ad generation.",
        icon: Sparkles
      },
      { 
        title: "Performance Insights Bot", 
        description: "Delivers daily summaries of campaign KPIs and trends with executive-level commentary.",
        icon: TrendingUp
      }
    ]
  },
  "E-Commerce & D2C": {
    icon: ShoppingBag,
    color: "from-green-500 to-emerald-500",
    bgColor: "bg-gradient-to-r from-green-50 to-emerald-50",
    agents: [
      { 
        title: "Product Copywriter Agent", 
        description: "Writes SEO-friendly product titles, benefits, and specs in brand tone.",
        icon: Bot
      },
      { 
        title: "AI Visual Merchandiser", 
        description: "Optimizes product placement on web/app based on behavioral data.",
        icon: TrendingUp
      },
      { 
        title: "Cart Abandonment Rescuer Bot", 
        description: "Sends smart, personalized nudges to recover lost sales via WhatsApp/email.",
        icon: Zap
      },
      { 
        title: "Review Summarizer Bot", 
        description: "Analyzes customer feedback and auto-generates sentiment-based product insights.",
        icon: Users
      }
    ]
  },
  "FMCG": {
    icon: Package,
    color: "from-orange-500 to-red-500",
    bgColor: "bg-gradient-to-r from-orange-50 to-red-50",
    agents: [
      { 
        title: "Retail Shelf Intelligence Agent", 
        description: "Tracks planogram compliance using store photos and AI vision models.",
        icon: Target
      },
      { 
        title: "Demand Forecasting Bot", 
        description: "Predicts sales demand across SKUs and geographies using weather, events, and historical trends.",
        icon: TrendingUp
      },
      { 
        title: "Retail Activation Bot", 
        description: "Plans and monitors in-store campaigns, tracking real-time footfall and conversions.",
        icon: Zap
      },
      { 
        title: "Distributor Engagement Assistant", 
        description: "Auto-generates performance dashboards, stock alerts, and promotion plans for regional distributors.",
        icon: Users
      }
    ]
  },
  "B2B & SaaS": {
    icon: Building2,
    color: "from-blue-500 to-indigo-500",
    bgColor: "bg-gradient-to-r from-blue-50 to-indigo-50",
    agents: [
      { 
        title: "Outbound Sales Agent", 
        description: "Crafts hyper-personalized cold emails using ICP data and previous interactions.",
        icon: Target
      },
      { 
        title: "Proposal Generator Agent", 
        description: "Auto-creates proposals, decks, and pricing sheets customized to client needs.",
        icon: Bot
      },
      { 
        title: "Client Health Monitor", 
        description: "Analyzes usage data and support tickets to identify churn risks.",
        icon: TrendingUp
      },
      { 
        title: "B2B Growth Dashboard Bot", 
        description: "Combines CRM, ad, and revenue data into a single, daily snapshot for leadership.",
        icon: Sparkles
      }
    ]
  },
  "Real Estate": {
    icon: Home,
    color: "from-cyan-500 to-teal-500",
    bgColor: "bg-gradient-to-r from-cyan-50 to-teal-50",
    agents: [
      { 
        title: "Listing Intelligence Bot", 
        description: "Generates SEO listings, ads, and social content for properties.",
        icon: Bot
      },
      { 
        title: "Lead Nurture Bot", 
        description: "Engages leads with local property insights, investment guides, and site visit bookings.",
        icon: Users
      },
      { 
        title: "ROI Projection Agent", 
        description: "Calculates long-term yield, IRR, and price appreciation based on location and property type.",
        icon: TrendingUp
      },
      { 
        title: "Developer Dashboard Agent", 
        description: "Summarizes sales funnel, inquiries, and top-performing agents weekly.",
        icon: Sparkles
      }
    ]
  },
  "Finance & Banking": {
    icon: Banknote,
    color: "from-emerald-500 to-green-600",
    bgColor: "bg-gradient-to-r from-emerald-50 to-green-50",
    agents: [
      { 
        title: "Credit Risk Analyzer", 
        description: "Flags anomalies and potential risk factors in loan applications using historical repayment models.",
        icon: Target
      },
      { 
        title: "Portfolio Summary Agent", 
        description: "Prepares visual performance summaries for clients and advisors.",
        icon: TrendingUp
      },
      { 
        title: "AML Compliance Assistant", 
        description: "Detects suspicious transaction patterns and compliance breaches.",
        icon: Zap
      },
      { 
        title: "Chatbot Banker", 
        description: "Answers customer FAQs, tracks spending patterns, and nudges users to save/invest.",
        icon: Bot
      }
    ]
  },
  "Healthcare": {
    icon: HeartHandshake,
    color: "from-red-500 to-pink-500",
    bgColor: "bg-gradient-to-r from-red-50 to-pink-50",
    agents: [
      { 
        title: "EMR Summarizer Bot", 
        description: "Converts detailed patient records into structured, usable insights for doctors.",
        icon: Bot
      },
      { 
        title: "AI Health Assistant", 
        description: "Suggests diagnostics or follow-ups based on reported symptoms and medical history.",
        icon: Sparkles
      },
      { 
        title: "Clinical Research Scanner", 
        description: "Extracts insights and trial data from research papers for medtech R&D.",
        icon: Target
      },
      { 
        title: "Patient Reminder Agent", 
        description: "Sends personalized reminders for meds, lab tests, or teleconsults.",
        icon: Users
      }
    ]
  },
  "Travel": {
    icon: Plane,
    color: "from-amber-500 to-orange-500",
    bgColor: "bg-gradient-to-r from-amber-50 to-orange-50",
    agents: [
      { 
        title: "Trip Planner Agent", 
        description: "Creates full itineraries using user preferences, visa rules, and live weather.",
        icon: Bot
      },
      { 
        title: "Hotel Recommender Bot", 
        description: "Suggests room upgrades or add-ons pre-check-in using past behavior.",
        icon: Sparkles
      },
      { 
        title: "Review Sentiment Agent", 
        description: "Scans reviews and generates improvement insights for GMs and marketing.",
        icon: TrendingUp
      },
      { 
        title: "Event Concierge Bot", 
        description: "Manages RSVPs, logistics, and guest coordination for MICE & weddings.",
        icon: Users
      }
    ]
  }
};

export default function AgentShowcase() {
  const [activeTab, setActiveTab] = useState("Marketing & Advertising");

  return (
    <div className="w-full">
      <div className="text-center mb-12">
        <div className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 font-semibold mb-6">
          <Sparkles className="w-5 h-5" />
          <span>AI-Powered Industry Solutions</span>
        </div>
        <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-dark mb-4">
          Custom AI Agents for
          <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent block md:inline md:ml-3">
            Every Industry
          </span>
        </h2>
        <p className="text-lg md:text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
          Discover powerful, industry-specific AI agents designed to automate workflows, 
          boost productivity, and transform business operations across sectors.
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-4 lg:grid-cols-8 h-auto mb-8 bg-gray-100 rounded-2xl p-2">
          {Object.keys(agentData).map(industry => (
            <TabsTrigger 
              key={industry} 
              value={industry} 
              className="text-xs md:text-sm font-medium px-2 py-3 rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-300"
            >
              <div className="flex flex-col items-center gap-2">
                <agentData[industry].icon className="w-4 h-4 md:w-5 md:h-5" />
                <span className="hidden sm:block">{industry}</span>
                <span className="sm:hidden">{industry.split(' ')[0]}</span>
              </div>
            </TabsTrigger>
          ))}
        </TabsList>

        {Object.entries(agentData).map(([industry, data]) => (
          <TabsContent key={industry} value={industry} className="mt-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className={`rounded-3xl p-6 md:p-8 mb-8 ${data.bgColor}`}
            >
              <div className="flex items-center gap-4 mb-6">
                <div className={`w-12 h-12 md:w-16 md:h-16 rounded-2xl bg-gradient-to-r ${data.color} flex items-center justify-center shadow-lg`}>
                  <data.icon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl md:text-3xl font-bold text-dark">{industry}</h3>
                  <p className="text-gray-600">AI-powered solutions for modern {industry.toLowerCase()}</p>
                </div>
              </div>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {data.agents.map((agent, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 group h-full bg-white rounded-2xl overflow-hidden">
                    <CardHeader className="pb-4">
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${data.color} flex items-center justify-center shadow-md group-hover:scale-110 transition-transform duration-300`}>
                          <agent.icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <CardTitle className="text-lg font-bold text-dark leading-tight group-hover:text-purple-600 transition-colors">
                            {agent.title}
                          </CardTitle>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                        {agent.description}
                      </p>
                      <div className="mt-4 pt-4 border-t border-gray-100">
                        <Badge variant="secondary" className="text-xs font-medium">
                          AI Powered
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>

      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.5 }}
        className="text-center mt-16 p-8 rounded-3xl bg-gradient-to-r from-purple-50 to-pink-50"
      >
        <h3 className="text-2xl md:text-3xl font-bold text-dark mb-4">
          Ready to Build Your Custom AI Agent?
        </h3>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          Let our experts create industry-specific AI solutions tailored to your business needs and workflows.
        </p>
        <button className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
          Start Your AI Transformation
        </button>
      </motion.div>
    </div>
  );
}