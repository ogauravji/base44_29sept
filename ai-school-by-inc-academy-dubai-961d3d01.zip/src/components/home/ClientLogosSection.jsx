import React from 'react';

const clientLogos = [
    { src: "https://i.imghippo.com/files/AIj7022XwI.png", alt: "Google" },
    { src: "https://i.imghippo.com/files/BtVJ7689eU.png", alt: "TikTok" },
    { src: "https://i.imghippo.com/files/zETQ9249BY.png", alt: "Dubai Tourism" },
    { src: "https://i.imghippo.com/files/LjWL1133fc.png", alt: "Emirates" },
    { src: "https://i.imghippo.com/files/RymB7570vQ.png", alt: "Alshaya" },
    { src: "https://i.imghippo.com/files/IPE5684MnM.png", alt: "Unilever" },
    { src: "https://i.imghippo.com/files/QUIK6243XI.png", alt: "Etihad" },
    { src: "https://i.imghippo.com/files/CBg5407ZEg.png", alt: "Harvard Business School" }
];

export default React.memo(function ClientLogosSection() {
    return (
        <section className="bg-white pt-0 pb-16 -mt-12 relative z-10">
            <div className="mx-auto max-w-5xl px-6 lg:px-8">
                <div className="bg-white rounded-2xl shadow-xl p-8">
                    <div className="mx-auto grid max-w-lg grid-cols-4 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:max-w-none lg:grid-cols-8">
                        {clientLogos.map((client) =>
                            <img
                                key={client.src}
                                className="col-span-2 max-h-12 w-full object-contain lg:col-span-1 opacity-70"
                                src={client.src}
                                alt={client.alt}
                                width="158"
                                height="48"
                                loading="lazy"
                                decoding="async"
                            />
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
});