
import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Zap, TrendingUp, DollarSign, Users } from "lucide-react";
import PageSection from '../common/PageSection';

export default function AIDisruptingSection() {
    return (
        <PageSection className="bg-gray-900 text-white">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-12 md:mb-16">
                    <Badge className="inline-flex items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 px-6 py-2 text-sm font-semibold bg-red-50 text-red-700 border border-red-200 mb-6 hover:bg-red-600 hover:text-white hover:border-red-600">
                        <Zap className="w-5 h-5 mr-2" />
                        Industry Disruption Alert
                    </Badge>
                    <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400 mb-4 leading-tight pb-2">
                        <span className="block">AI is Disrupting</span>
                        <span className="bg-gradient-to-r from-red-600 to-orange-500 bg-clip-text text-transparent block mt-2"> Every Industry</span>
                    </h2>
                    <p className="text-lg md:text-xl text-gray-300 max-w-3xl mx-auto font-light leading-relaxed">
                        From healthcare to finance, retail to manufacturing—no sector is immune to AI transformation.
                        The companies that adapt quickly will dominate their markets.
                    </p>
                </div>

                <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center mb-12 md:mb-16">
                    <div>
                        <h3 className="text-2xl md:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400 mb-4 md:mb-6">Companies Using AI Are Already Winning</h3>
                        <div className="space-y-4 md:space-y-6">
                            <div className="flex items-start gap-3 md:gap-4">
                                <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                                    <TrendingUp className="w-5 h-5 md:w-6 md:h-6 text-white" />
                                </div>
                                <div>
                                    <h4 className="text-base md:text-lg font-semibold text-white mb-1 md:mb-2">40% Faster Decision Making</h4>
                                    <p className="text-gray-400 text-sm md:text-base">AI-powered analytics enable real-time insights and instant strategic adjustments</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-3 md:gap-4">
                                <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0">
                                    <DollarSign className="w-5 h-5 md:w-6 md:h-6 text-white" />
                                </div>
                                <div>
                                    <h4 className="text-base md:text-lg font-semibold text-white mb-1 md:mb-2">60% Cost Reduction</h4>
                                    <p className="text-gray-400 text-sm md:text-base">Automation eliminates manual processes and optimizes resource allocation</p>
                                </div>
                            </div>
                            <div className="flex items-start gap-3 md:gap-4">
                                <div className="w-10 h-10 md:w-12 md:h-12 bg-gradient-to-r from-red-500 to-red-600 rounded-xl flex items-center justify-center flex-shrink-0">
                                    <Users className="w-5 h-5 md:w-6 md:h-6 text-white" />
                                </div>
                                <div>
                                    <h4 className="text-base md:text-lg font-semibold text-white mb-1 md:mb-2">3x Better Customer Experience</h4>
                                    <p className="text-gray-400 text-sm md:text-base">Personalized interactions and 24/7 AI support create unmatched customer satisfaction</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="relative mt-10 md:mt-0">
                        <img
                            src="https://i.imghippo.com/files/aP7317BDE.png"
                            alt="AI expert robot analyzing data on a futuristic interface, demonstrating industry disruption"
                            className="rounded-2xl shadow-xl"
                            loading="lazy"
                            decoding="async"
                            width="1500" // Added for speed optimization (CLS)
                            height="1000" // Added for speed optimization (CLS)
                        />
                        <div className="absolute top-8 -right-8 w-24 h-24 md:w-32 md:h-32 bg-blue-200 rounded-full blur-3xl opacity-60"></div>
                        <div className="absolute -bottom-8 -left-8 w-32 h-32 md:w-40 md:h-40 bg-red-200 rounded-full blur-3xl opacity-60"></div>
                    </div>
                </div>
            </div>
        </PageSection>
    );
}
