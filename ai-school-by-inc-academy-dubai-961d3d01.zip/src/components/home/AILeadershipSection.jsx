import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Crown, Brain, TrendingUp, Zap, Users, ArrowRight } from "lucide-react";
import PageSection from '../common/PageSection';
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function AILeadershipSection() {
    return (
        <PageSection className="bg-gradient-to-br from-gray-900 via-blue-900 to-black text-white">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-12 md:mb-16">
                    <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-white/20 text-white border border-white/30 mb-6 md:mb-8 hover:bg-white hover:text-gray-900 transition-all">
                        <Crown className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                        Executive Leadership
                    </Badge>
                    <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 md:mb-8 leading-tight pb-2">
                        The New Era of
                        <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent block mt-2">
                            AI-Powered Leadership
                        </span>
                    </h2>
                    <p className="text-lg md:text-xl text-gray-300 max-w-4xl mx-auto font-light leading-relaxed px-4 sm:px-0">
                        Tomorrow's leaders won't just use AI—they'll think like AI. Strategic, data-driven,
                        and capable of making complex decisions at machine speed with human wisdom.
                    </p>
                </div>

                <div className="grid sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
                    {[
                        { icon: Brain, title: "Strategic AI Thinking", desc: "Make decisions backed by AI insights, not just intuition", color: "from-blue-500 to-blue-600" },
                        { icon: TrendingUp, title: "Predictive Leadership", desc: "Anticipate market changes and stay ahead of competition", color: "from-green-400 to-emerald-400" },
                        { icon: Zap, title: "Agile Execution", desc: "Implement strategies with AI-powered speed and precision", color: "from-orange-400 to-red-400" },
                        { icon: Users, title: "Team Transformation", desc: "Lead organizational change with confidence and clarity", color: "from-red-500 to-red-600" }
                    ].map((item, index) =>
                        <div key={index} className="text-center group">
                            <div className={`w-16 h-16 md:w-20 md:h-20 bg-gradient-to-r ${item.color} rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6 group-hover:scale-110 transition-transform duration-300`}>
                                <item.icon className="w-8 h-8 md:w-10 md:h-10 text-white" />
                            </div>
                            <h3 className="text-lg md:text-xl font-bold mb-3 md:mb-4">{item.title}</h3>
                            <p className="text-gray-400 text-sm md:text-base">{item.desc}</p>
                        </div>
                    )}
                </div>

                <div className="mt-12 md:mt-16 text-center">
                    <div className="bg-gray-900 rounded-3xl p-6 md:p-12 backdrop-blur-sm">
                        <h3 className="text-xl md:text-3xl font-bold mb-4 md:mb-6">
                            Ready to Become an AI-Powered Leader?
                        </h3>
                        <p className="text-gray-300 mb-6 md:mb-8 max-w-2xl mx-auto text-sm md:text-base">
                            Join the executives who are already transforming their industries with AI.
                            The question isn't whether AI will change leadership—it's whether you'll lead the change.
                        </p>
                        <Link to={createPageUrl("ai-courses")}>
                            <Button size="lg" className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 px-8 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group">
                                Start Your AI Leadership Journey
                                <ArrowRight className="w-4 h-4 md:w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                            </Button>
                        </Link>
                    </div>
                </div>
            </div>
        </PageSection>
    );
}