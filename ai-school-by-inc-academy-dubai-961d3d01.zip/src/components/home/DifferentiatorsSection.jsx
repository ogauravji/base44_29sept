import React from 'react';
import { motion } from 'framer-motion';
import { Award, CheckCircle2 } from "lucide-react";
import PageSection from '../common/PageSection';

const differentiators = [
    "Focus on Strategy, Implementation & Frameworks",
    "Not just tools — we teach application and scale",
    "Real case studies from top brands and internal teams",
    "15+ years of proven digital training legacy"
];

export default function DifferentiatorsSection() {
    return (
        <>
            <div className="h-px bg-gradient-to-r from-transparent via-gray-300 to-transparent"></div>
            <PageSection className="bg-gradient-to-br from-blue-100 via-gray-100 to-blue-50 text-gray-900 overflow-hidden">
                <div className="absolute -top-20 -left-20 w-96 h-96 bg-gradient-to-r from-orange-200/40 to-transparent rounded-full blur-3xl"></div>
                <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-gradient-to-r from-red-200/40 to-transparent rounded-full blur-3xl"></div>

                <div className="max-w-7xl mx-auto relative z-10">
                    <div className="text-center mb-12 md:mb-16">
                        <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 md:mb-8 leading-tight pb-2">
                            <span className="text-gray-900 block">How We're</span>
                            <span className="text-orange-600 block mt-2"> Different</span>
                        </h2>
                        <p className="text-lg md:text-xl text-gray-700 max-w-4xl mx-auto font-light leading-relaxed px-4 sm:px-0">
                            Not another generic AI course. We deliver strategic, implementation-focused
                            training that transforms businesses, not just individuals.
                        </p>
                    </div>

                    <div className="grid md:grid-cols-5 gap-8 md:gap-12 items-stretch">
                        <div className="md:col-span-3 bg-white/80 backdrop-blur-sm border border-blue-200/50 rounded-3xl p-6 md:p-8 shadow-lg">
                            <h3 className="text-2xl font-bold mb-6 text-gray-900">Our Strategic Edge</h3>
                            <div className="space-y-4 md:space-y-5">
                                {differentiators.map((item, index) =>
                                    <motion.div
                                        key={index}
                                        initial={{ opacity: 0, x: -20 }}
                                        whileInView={{ opacity: 1, x: 0 }}
                                        viewport={{ once: true, amount: 0.5 }}
                                        transition={{ duration: 0.5, delay: index * 0.1 }}
                                        className="flex items-start gap-4 p-4 rounded-xl bg-blue-50/60 border border-blue-200 hover:bg-blue-100/80 transition-colors">
                                        <div className="w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-lg flex items-center justify-center flex-shrink-0 mt-1">
                                            <CheckCircle2 className="w-5 h-5 text-white" />
                                        </div>
                                        <span className="text-base md:text-lg text-gray-800">{item}</span>
                                    </motion.div>
                                )}
                            </div>
                        </div>

                        <div className="md:col-span-2 bg-gradient-to-br from-blue-50/90 via-white/80 to-orange-50/90 backdrop-blur-sm border border-blue-200/50 rounded-3xl p-6 md:p-8 flex flex-col justify-between shadow-lg">
                            <div className="text-center">
                                <div className="w-16 h-16 md:w-20 md:h-20 bg-blue-100 rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6 ring-2 ring-orange-300">
                                    <Award className="w-8 h-8 md:w-10 md:h-10 text-blue-600" />
                                </div>
                                <h3 className="text-xl md:text-2xl font-bold mb-3 md:mb-4 text-gray-900">Proven Track Record</h3>
                                <p className="text-gray-700 mb-6 text-sm md:text-base">
                                    15+ years of digital training excellence with measurable business outcomes
                                    across 300+ brands and 9,000+ professionals.
                                </p>
                            </div>
                            <div className="mt-auto">
                                <div className="grid grid-cols-2 gap-4">
                                    <div className="bg-blue-100/70 p-4 rounded-xl text-center border border-blue-200">
                                        <div className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">70%</div>
                                        <div className="text-xs md:text-sm text-gray-600 mt-1">Avg. Cost Reduction</div>
                                    </div>
                                    <div className="bg-blue-100/70 p-4 rounded-xl text-center border border-blue-200">
                                        <div className="text-2xl md:text-4xl font-bold bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">5x</div>
                                        <div className="text-xs md:text-sm text-gray-600 mt-1">ROI Achievement</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </PageSection>
        </>
    );
}