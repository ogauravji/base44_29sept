import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Zap, ArrowRight } from "lucide-react";
import PageSection from '../common/PageSection';
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function BreakingNewsSection() {
    return (
        <PageSection className="bg-red-600 text-white relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-700"></div>
            <div className="relative z-10 max-w-7xl mx-auto">
                <div className="text-center mb-8">
                    <Badge className="px-4 py-2 text-sm font-bold bg-yellow-400 text-red-900 border-0 mb-4 animate-pulse hover:bg-yellow-300 hover:text-red-900">
                        <Zap className="w-4 h-4 mr-2" />
                        BREAKING: AI INDUSTRY UPDATE
                    </Badge>
                    <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
                        Don't Get Left Behind in the
                        <span className="block text-yellow-300 mt-2">AI Gold Rush</span>
                    </h2>
                </div>

                <div className="grid md:grid-cols-3 gap-6 md:gap-8">
                    <Card className="bg-white/10 backdrop-blur-sm border border-white/20 text-white">
                        <CardContent className="p-6">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
                                <span className="text-sm font-semibold text-yellow-300">JUST IN</span>
                            </div>
                            <h3 className="text-xl font-bold mb-3">OpenAI Hits $12B Revenue</h3>
                            <p className="text-gray-200 text-sm">Breaks 700 Million ChatGPT Weekly Active Users. Companies using AI report 40% productivity gains.</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white/10 backdrop-blur-sm border border-white/20 text-white">
                        <CardContent className="p-6">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
                                <span className="text-sm font-semibold text-yellow-300">TRENDING</span>
                            </div>
                            <h3 className="text-xl font-bold mb-3">Fortune 500 AI Adoption Soars</h3>
                            <p className="text-gray-200 text-sm">87% of enterprises now use AI tools. Early adopters report $2.3M average cost savings.</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white/10 backdrop-blur-sm border border-white/20 text-white">
                        <CardContent className="p-6">
                            <div className="flex items-center gap-3 mb-4">
                                <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
                                <span className="text-sm font-semibold text-yellow-300">URGENT</span>
                            </div>
                            <h3 className="text-xl font-bold mb-3">AI Job Market Explodes</h3>
                            <p className="text-gray-200 text-sm">AI-skilled professionals earn 35% more. Demand outpaces supply by 400%.</p>
                        </CardContent>
                    </Card>
                </div>

                <div className="text-center mt-8">
                    <p className="text-lg text-red-100 mb-4">The window is closing fast. Companies that don't adopt AI in 2025 risk becoming obsolete.</p>
                    <Link to={createPageUrl("ai-courses")}>
                        <Button size="lg" className="bg-yellow-400 hover:bg-yellow-300 text-red-900 px-8 py-4 font-bold rounded-xl animate-bounce">
                            Secure Your Spot Now
                            <ArrowRight className="w-5 h-5 ml-2" />
                        </Button>
                    </Link>
                </div>
            </div>
        </PageSection>
    );
}