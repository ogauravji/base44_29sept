import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { BrainCircuit, Target, Brain, Award, ArrowRight } from "lucide-react";
import PageSection from '../common/PageSection';
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function AIJobsSection() {
    return (
        <PageSection className="bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-12 md:mb-16">
                    <Badge className="inline-flex items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-purple-100 text-purple-700 border border-purple-200 mb-6 md:mb-8 hover:bg-purple-600 hover:text-white hover:border-purple-600">
                        <BrainCircuit className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                        The Future of Work
                    </Badge>
                    <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 md:mb-8 leading-tight pb-2">
                        <span className="text-gray-900 block">AI Won't Take Your Job,</span>
                        <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent block mt-2">
                            But Someone Using AI Will
                        </span>
                    </h2>
                    <p className="text-lg md:text-xl text-gray-700 max-w-4xl mx-auto font-light leading-relaxed px-4 sm:px-0">
                        The professionals who thrive in the AI era won't be the ones who fear it—they'll be the ones who master it.
                        Secure your position as an indispensable leader by becoming the AI-powered executive your company needs.
                    </p>
                </div>

                <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6 md:gap-8">
                    <Card className="bg-white/80 backdrop-blur-sm border border-red-200 shadow-lg hover:shadow-xl transition-all duration-300 rounded-2xl overflow-hidden group">
                        <CardContent className="p-6 md:p-8 text-center">
                            <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-r from-red-400 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6 group-hover:scale-110 transition-transform duration-300">
                                <Target className="w-6 h-6 md:w-8 md:h-8 text-white" />
                            </div>
                            <h3 className="text-lg md:text-xl font-bold mb-3 md:mb-4 text-gray-900">The Risk</h3>
                            <p className="text-gray-600 text-sm md:text-base">AI adoption is accelerating. Companies that don't adapt will be left behind, and so will their teams.</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white/80 backdrop-blur-sm border border-blue-200 shadow-lg hover:shadow-xl transition-all duration-300 rounded-2xl overflow-hidden group">
                        <CardContent className="p-6 md:p-8 text-center">
                            <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-r from-blue-400 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6 group-hover:scale-110 transition-transform duration-300">
                                <Brain className="w-6 h-6 md:w-8 md:h-8 text-white" />
                            </div>
                            <h3 className="text-lg md:text-xl font-bold mb-3 md:mb-4 text-gray-900">The Opportunity</h3>
                            <p className="text-gray-600 text-sm md:text-base">Be among the first in your industry to master AI marketing. Lead transformation instead of following it.</p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white/80 backdrop-blur-sm border border-green-200 shadow-lg hover:shadow-xl transition-all duration-300 rounded-2xl overflow-hidden group sm:col-span-2 md:col-span-1">
                        <CardContent className="p-6 md:p-8 text-center">
                            <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-r from-green-400 to-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-4 md:mb-6 group-hover:scale-110 transition-transform duration-300">
                                <Award className="w-6 h-6 md:w-8 md:h-8 text-white" />
                            </div>
                            <h3 className="text-lg md:text-xl font-bold mb-3 md:mb-4 text-gray-900">The Advantage</h3>
                            <p className="text-gray-600 text-sm md:text-base">Become the executive who understands AI deeply—making you invaluable to any organization.</p>
                        </CardContent>
                    </Card>
                </div>

                <div className="mt-12 md:mt-16">
                    <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-3xl p-8 md:p-12 text-white text-center shadow-2xl">
                        <h3 className="text-2xl md:text-3xl font-bold mb-4 md:mb-6">
                            Don't Wait Until It's Too Late
                        </h3>
                        <p className="text-lg md:text-xl text-purple-100 mb-6 md:mb-8 max-w-3xl mx-auto">
                            The AI revolution is happening now. Position yourself as a leader, not a follower.
                            Join the professionals who are already mastering AI marketing.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Link to={createPageUrl("ai-courses")}>
                                <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4 text-lg font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group">
                                    Start Your AI Journey Today
                                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                                </Button>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </PageSection>
    );
}