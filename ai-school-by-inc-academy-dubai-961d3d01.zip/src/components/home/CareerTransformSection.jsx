import React from 'react';
import { Badge } from "@/components/ui/badge";
import { BrainCircuit, AlertTriangle, X, Rocket, CheckCircle2 } from "lucide-react";
import PageSection from '../common/PageSection';

export default function CareerTransformSection() {
    return (
        <PageSection className="bg-gray-50">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-12 md:mb-16">
                    <Badge className="inline-flex items-center rounded-full px-6 py-2 text-sm font-semibold bg-orange-50 text-orange-700 border border-orange-200 mb-6 hover:bg-white hover:text-orange-700 transition-all">
                        <BrainCircuit className="w-5 h-5 mr-2" />
                        Career Transformation
                    </Badge>
                    <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 leading-tight">
                        <span className="text-gray-900 block">Your Career:</span>
                        <span className="bg-gradient-to-r from-red-600 to-orange-500 bg-clip-text text-transparent block mt-2">
                            Before AI vs After AI
                        </span>
                    </h2>
                    <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
                        The professionals mastering AI today will be the leaders of tomorrow
                    </p>
                </div>

                <div className="grid lg:grid-cols-2 gap-8 md:gap-12">
                    <div className="bg-white rounded-3xl p-8 shadow-lg border border-gray-200">
                        <div className="text-center mb-8">
                            <div className="w-16 h-16 bg-red-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                                <AlertTriangle className="w-8 h-8 text-red-600" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-2">Without AI Skills</h3>
                            <p className="text-red-600 font-semibold">The Struggling Professional</p>
                        </div>
                        <div className="space-y-4">
                            {[
                                "Spending 6+ hours on tasks AI does in minutes",
                                "Falling behind tech-savvy colleagues",
                                "Limited to traditional, slow methods",
                                "Constantly overwhelmed by workload",
                                "Career growth stagnating",
                                "Salary increases becoming rare"
                            ].map((item, index) =>
                                <div key={index} className="flex items-start gap-3">
                                    <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                                    <span className="text-gray-700">{item}</span>
                                </div>
                            )}
                        </div>
                    </div>

                    <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-3xl p-8 shadow-xl border border-blue-200">
                        <div className="text-center mb-8">
                            <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                                <Rocket className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-2xl font-bold text-gray-900 mb-2">With AI Mastery</h3>
                            <p className="text-green-600 font-semibold">The AI-Powered Leader</p>
                        </div>
                        <div className="space-y-4">
                            {[
                                "10x productivity with AI automation",
                                "Recognized as the 'AI expert' at work",
                                "Leading digital transformation initiatives",
                                "More strategic, less routine work",
                                "Fast-tracked for promotions",
                                "35% higher salary potential"
                            ].map((item, index) =>
                                <div key={index} className="flex items-start gap-3">
                                    <CheckCircle2 className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                                    <span className="text-gray-700">{item}</span>
                                </div>
                            )}
                        </div>
                    </div>
                </div>

                <div className="text-center mt-12">
                    <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6 border border-white/20 mb-6 sm:mb-8">
                        <h3 className="text-xl sm:text-2xl md:text-3xl font-bold mb-3 sm:mb-4 md:mb-6">
                            The Growth Opportunity is NOW
                        </h3>
                        <p className="text-base sm:text-lg text-gray-700 mb-4 sm:mb-6">
                            While 73% of professionals don't know how to use AI effectively, the 27% who do are experiencing unprecedented career acceleration.
                        </p>
                        <div className="grid sm:grid-cols-3 gap-3 sm:gap-4 mb-4 sm:mb-6">
                            <div className="text-center p-3 sm:p-4">
                                <div className="text-2xl sm:text-3xl font-bold text-blue-600">400%</div>
                                <div className="text-xs sm:text-sm text-gray-600">Job market demand</div>
                            </div>
                            <div className="text-center p-3 sm:p-4">
                                <div className="text-2xl sm:text-3xl font-bold text-green-600">35%</div>
                                <div className="text-xs sm:text-sm text-gray-600">Salary premium</div>
                            </div>
                            <div className="text-center p-3 sm:p-4">
                                <div className="text-2xl sm:text-3xl font-bold text-purple-600">2024</div>
                                <div className="text-xs sm:text-sm text-gray-600">The tipping point</div>
                            </div>
                        </div>
                        <p className="text-xs sm:text-sm text-gray-600 text-center">Join the AI revolution before it becomes mainstream</p>
                    </div>
                </div>
            </div>
        </PageSection>
    );
}