import React from 'react';
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";
import PageSection from '../common/PageSection';
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function FinalCTASection({ openModal }) {
    return (
        <PageSection className="bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900 text-white relative overflow-hidden">
            <div className="absolute top-10 right-10 w-96 h-96 bg-gradient-to-r from-blue-400/10 to-indigo-400/10 rounded-full blur-3xl"></div>
            <div className="absolute bottom-10 left-10 w-80 h-80 bg-gradient-to-r from-green-400/10 to-blue-400/10 rounded-full blur-3xl"></div>

            <div className="max-w-4xl mx-auto text-center relative z-10">
                <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-white/10 shadow-2xl">
                    <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 md:mb-8 leading-tight pb-2">
                        <span className="text-white block">Ready to Future-Proof Your</span>
                        <span className="bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent block mt-2"> Marketing with AI?</span>
                    </h2>

                    <p className="text-lg md:text-xl text-blue-100 mb-8 md:mb-12 leading-relaxed px-4 sm:px-0">
                        Join thousands of marketing leaders who've transformed their businesses with our AI frameworks.
                        The question isn't whether AI will transform marketing — it's whether you'll lead the transformation.
                    </p>

                    <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center mb-8">
                        <Link to={createPageUrl("ai-courses")}>
                            <Button size="lg" className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white px-8 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group min-w-64">
                                Join the Online Cohort
                                <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                            </Button>
                        </Link>

                        <Link to={createPageUrl("corporate-ai-workshops")}>
                            <Button size="lg" variant="outline" className="w-full sm:w-auto bg-white/10 backdrop-blur-sm text-white border-2 border-white/30 hover:bg-white hover:text-gray-900 px-8 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-2xl transition-all duration-300 group min-w-64">
                                Book Workshop for Your Team
                                <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                            </Button>
                        </Link>
                    </div>

                    <div className="flex flex-wrap justify-center items-center gap-6 md:gap-8 text-sm text-blue-200">
                        <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm hover:bg-white/20 transition-colors">
                            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                            <span>9,000+ Professionals Trained</span>
                        </div>
                        <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm hover:bg-white/20 transition-colors">
                            <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                            <span>300+ Brands Consulted</span>
                        </div>
                        <div className="flex items-center gap-2 bg-white/10 px-4 py-2 rounded-full backdrop-blur-sm hover:bg-white/20 transition-colors">
                            <div className="w-2 h-2 bg-indigo-400 rounded-full animate-pulse"></div>
                            <span>15+ Years Experience</span>
                        </div>
                    </div>
                </div>
            </div>
        </PageSection>
    );
}