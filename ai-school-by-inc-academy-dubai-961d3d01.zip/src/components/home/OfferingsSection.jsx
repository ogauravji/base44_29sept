import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Rocket, Users, Target, ArrowRight } from "lucide-react";
import PageSection from '../common/PageSection';
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

const offerings = [
    {
        icon: Users,
        title: "AI Training",
        subtitle: "For Executives & Corporate Teams",
        description: "Customized training programs to equip your teams with the skills needed to harness the power of AI.",
        color: "from-blue-600 to-blue-700",
        href: createPageUrl("ai-courses")
    },
    {
        icon: Target,
        title: "AI Consultancy",
        subtitle: "Strategic Guidance & Roadmapping",
        description: "Strategic guidance to integrate AI seamlessly into your business, aligning technology with your unique needs.",
        color: "from-green-600 to-green-700",
        href: createPageUrl("ai-consultants")
    },
    {
        icon: Rocket,
        title: "AI Implementation Agency",
        subtitle: "Done-For-You Solutions",
        description: "End-to-end implementation of AI-driven solutions that optimize your operations and drive measurable impact.",
        color: "from-orange-600 to-orange-700",
        href: createPageUrl("ai-implementation-agency")
    }
];

export default function OfferingsSection() {
    return (
        <>
            <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>
            <PageSection className="bg-white">
                <div className="max-w-7xl mx-auto">
                    <div className="text-center mb-12 md:mb-16">
                        <Badge className="inline-flex items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 px-6 py-2 text-sm font-semibold bg-blue-50 text-blue-700 border border-blue-200 mb-6 hover:bg-blue-600 hover:text-white hover:border-blue-600">
                            <Rocket className="w-5 h-5 mr-2" />
                            Complete AI Transformation
                        </Badge>
                        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 leading-tight pb-2">
                            <span className="text-gray-900">Our</span>
                            <span className="text-blue-600 block mt-1"> Offerings</span>
                        </h2>
                        <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto font-light leading-relaxed">
                            From individual upskilling to enterprise-wide transformation,
                            we provide the complete AI marketing ecosystem your business needs
                        </p>
                    </div>

                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                        {offerings.map((offering, index) =>
                            <Link key={index} to={offering.href}>
                                <Card className="shadow-lg hover:shadow-2xl transition-all duration-300 group cursor-pointer h-full bg-white/80 backdrop-blur-sm">
                                    <CardContent className="p-6">
                                        <div className={`w-12 h-12 bg-gradient-to-r ${offering.color} rounded-2xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
                                            <offering.icon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                                        </div>
                                        <h3 className="text-xl font-bold bg-gradient-to-r from-black to-gray-700 bg-clip-text text-transparent mb-2">{offering.title}</h3>
                                        <p className="text-base bg-gradient-to-r from-blue-700 to-blue-900 bg-clip-text text-transparent font-semibold mb-3">{offering.subtitle}</p>
                                        <p className="text-gray-600 leading-relaxed text-sm mb-4">{offering.description}</p>
                                        <div className="flex items-center text-blue-700 font-semibold group-hover:gap-3 transition-all duration-300">
                                            <span>Learn More</span>
                                            <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                                        </div>
                                    </CardContent>
                                </Card>
                            </Link>
                        )}
                    </div>
                </div>
            </PageSection>
        </>
    );
}