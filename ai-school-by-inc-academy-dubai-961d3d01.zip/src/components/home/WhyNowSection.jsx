import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Zap, BarChart3, Briefcase, Users, Brain } from "lucide-react";
import PageSection from '../common/PageSection';

export default function WhyNowSection() {
    return (
        <>
            <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>
            <PageSection className="bg-gray-50">
                <div className="max-w-7xl mx-auto">
                    <div className="text-center mb-12 md:mb-16">
                        <Badge className="inline-flex items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 px-6 py-2 text-sm font-semibold bg-red-50 text-red-700 border border-red-200 mb-6 hover:bg-red-600 hover:text-white hover:border-red-600">
                            <Zap className="w-5 h-5 mr-2" />
                            Critical Business Alert
                        </Badge>
                        <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4 leading-tight pb-2">
                            <span className="text-gray-900">The AI Tsunami is Coming.</span>
                            <span className="text-red-600 block mt-2">Are You Prepared?</span>
                        </h2>
                        <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto font-light leading-relaxed">
                            AI agents are replacing tasks, not people — but only for those who adapt quickly.
                            Your competition is already implementing AI. Will you lead or get left behind?
                        </p>
                    </div>

                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
                        {[
                            { icon: BarChart3, title: "Marketing & Growth", desc: "Campaign optimization, content generation, lead scoring" },
                            { icon: Briefcase, title: "Sales & Operations", desc: "Automate sales cycles, lead nurturing, and operational workflows." },
                            { icon: Users, title: "Customer Experience", desc: "Personalization, chatbots, predictive analytics" },
                            { icon: Brain, title: "Leadership & CXOs", desc: "Gain strategic insights, forecast trends, and drive top-level decisions." }
                        ].map((item, index) =>
                            <Card key={index} className="shadow-lg hover:shadow-xl transition-all duration-300 group bg-white/80 backdrop-blur-sm">
                                <CardContent className="p-6">
                                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                                        <item.icon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                                    </div>
                                    <h3 className="text-lg font-bold text-gray-900 mb-3">{item.title}</h3>
                                    <p className="text-gray-600 leading-relaxed text-sm">{item.desc}</p>
                                </CardContent>
                            </Card>
                        )}
                    </div>
                </div>
            </PageSection>
        </>
    );
}