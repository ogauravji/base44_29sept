
import React from 'react';
import { motion } from 'framer-motion';
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Globe, CheckCircle2, ArrowRight } from "lucide-react";
import PageSection from '../common/PageSection';
// import { createPageUrl } from "@/utils"; // Removed as it's no longer used for this link
// import { Link } from "react-router-dom"; // Removed as Link component is no longer used for this button

export default function AboutIncAcademySection() {
    return (
        <PageSection className="bg-white">
            <div className="max-w-7xl mx-auto">
                <div className="text-center mb-12 md:mb-16">
                    <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 border border-blue-200 mb-6 md:mb-8 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-colors">
                        <Globe className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                        Industry Leadership
                    </Badge>
                    <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-6 md:mb-8 leading-tight pb-2">
                        <span className="block">About</span>
                        <span className="text-blue-600 block mt-2"> Inc Academy</span>
                    </h2>
                </div>

                <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
                    <motion.div
                        initial={{ opacity: 0, x: -50 }}
                        whileInView={{ opacity: 1, x: 0 }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.8 }}
                        className="relative order-2 lg:order-1">
                        <div className="relative z-10">
                            <div className="w-full h-auto bg-gradient-to-br from-blue-100 to-purple-100 rounded-3xl shadow-2xl overflow-hidden ring-4 ring-white/50">
                                <img
                                    src="https://i.imghippo.com/files/tfUo2263Io.png"
                                    alt="Gaurav Oberoi, Founder of Inc. Academy"
                                    width="1200" // Added for CLS prevention
                                    height="1500" // Added for CLS prevention
                                    className="w-full h-full object-cover rounded-3xl"
                                    loading="lazy"
                                    decoding="async" />
                            </div>
                        </div>
                        <div className="absolute top-8 -right-8 w-24 h-24 md:w-32 md:h-32 bg-gradient-to-r from-blue-200/60 to-purple-200/60 rounded-full blur-3xl"></div>
                        <div className="absolute -bottom-8 -left-8 w-32 h-32 md:w-40 md:h-40 bg-gradient-to-r from-purple-200/60 to-pink-200/60 rounded-full blur-3xl"></div>
                    </motion.div>

                    <div className="order-1 lg:order-2">
                        <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 md:p-10 shadow-xl border border-white/40">
                            <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4 md:mb-6 leading-tight pb-1">
                                15+ Years of Digital Training Legacy
                            </h3>
                            <p className="text-base md:text-lg text-gray-700 leading-relaxed mb-6 md:mb-8">
                                Founded and led by Gaurav Oberoi, Inc Academy has been at the forefront of
                                digital marketing education in the MENA region. We've evolved from traditional
                                digital marketing training to become the region's leading AI marketing transformation partner.
                            </p>

                            <div className="space-y-3 md:space-y-4 mb-6 md:mb-8">
                                {[
                                    "Former Google Regional Trainer",
                                    "Dubai Tourism consultant for Expo 2020",
                                    "TikTok MENA collaborator",
                                    "Active startup investor & advisor"
                                ].map((achievement, index) =>
                                    <div key={index} className="flex items-center gap-2 md:gap-3 p-3 rounded-xl bg-gradient-to-r from-blue-50/80 to-purple-50/80 border border-blue-100">
                                        <CheckCircle2 className="w-4 h-4 md:w-5 md:h-5 text-blue-600 flex-shrink-0" />
                                        <span className="text-gray-700 text-sm md:text-base font-medium">{achievement}</span>
                                    </div>
                                )}
                            </div>

                            <div className="grid grid-cols-2 gap-4 mb-8">
                                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-2xl text-center border border-blue-200 shadow-sm">
                                    <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">9,000+</div>
                                    <p className="text-sm text-gray-600">Professionals Trained</p>
                                </div>
                                <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-2xl text-center border border-purple-200 shadow-sm">
                                    <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">15+</div>
                                    <p className="text-sm text-gray-600">Years Experience</p>
                                </div>
                            </div>

                            <a href="https://www.linkedin.com/in/gauravoberoi/" target="_blank" rel="noopener noreferrer">
                                <Button className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 md:px-8 py-3 md:py-4 font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group">
                                    Meet Gaurav Oberoi
                                    <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                                </Button>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </PageSection>
    );
}
