import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Infinity, Bot, Brain, Zap, ArrowRight } from "lucide-react";
import PageSection from '../common/PageSection';
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function FutureOfAISection() {
    return (
        <PageSection className="bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white relative overflow-hidden">
            <div className="absolute inset-0">
                <div className="absolute top-0 left-1/4 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl"></div>
                <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
            </div>

            <div className="relative z-10 max-w-7xl mx-auto">
                <div className="text-center mb-12 md:mb-16">
                    <Badge className="inline-flex items-center rounded-full px-6 py-3 text-base font-semibold bg-white/10 text-white border border-white/20 mb-8 backdrop-blur-sm hover:bg-white hover:text-gray-900 transition-all">
                        <Infinity className="w-5 h-5 mr-2" />
                        The Future is Now
                    </Badge>
                    <h2 className="text-3xl sm:text-4xl md:text-6xl font-bold mb-8 leading-tight">
                        <span className="text-white block">Welcome to the</span>
                        <span className="bg-gradient-to-r from-cyan-400 via-pink-400 to-yellow-400 bg-clip-text text-transparent block mt-2">
                            Age of AI Agents
                        </span>
                    </h2>
                    <p className="text-xl text-indigo-100 max-w-4xl mx-auto leading-relaxed">
                        By 2025, AI agents will handle 80% of routine business tasks. The question isn't if this will happen—it's whether you'll be ready.
                    </p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
                    <Card className="bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 transition-all duration-300">
                        <CardContent className="p-8 text-center">
                            <div className="w-16 h-16 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                                <Bot className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-slate-50 mb-4 text-xl font-bold">Autonomous AI Agents</h3>
                            <p className="text-indigo-100 text-sm">
                                AI agents that work 24/7, learn from every interaction, and execute complex business strategies without human oversight.
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 transition-all duration-300">
                        <CardContent className="p-8 text-center">
                            <div className="w-16 h-16 bg-gradient-to-r from-pink-400 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                                <Brain className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-slate-50 mb-4 text-xl font-bold">Predictive Intelligence</h3>
                            <p className="text-indigo-100 text-sm">
                                AI systems that predict market trends, customer behavior, and business outcomes with 95%+ accuracy.
                            </p>
                        </CardContent>
                    </Card>

                    <Card className="bg-white/10 backdrop-blur-sm border border-white/20 hover:bg-white/15 transition-all duration-300 md:col-span-2 lg:col-span-1">
                        <CardContent className="p-8 text-center">
                            <div className="w-16 h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                                <Zap className="w-8 h-8 text-white" />
                            </div>
                            <h3 className="text-slate-50 mb-4 text-xl font-bold">Instant Adaptation</h3>
                            <p className="text-indigo-100 text-sm">
                                AI that adapts strategies in real-time based on changing market conditions and performance data.
                            </p>
                        </CardContent>
                    </Card>
                </div>

                <div className="text-center">
                    <div className="bg-gradient-to-r from-cyan-500/20 to-pink-500/20 rounded-3xl p-8 md:p-12 backdrop-blur-sm border border-white/10">
                        <h3 className="text-2xl md:text-3xl font-bold mb-6">
                            The AI Transformation is Inevitable
                        </h3>
                        <p className="text-lg text-indigo-100 mb-8 max-w-3xl mx-auto">
                            The only choice you have is whether to lead the transformation or be transformed by it.
                            The professionals who master AI today will shape the business world of tomorrow.
                        </p>
                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Link to={createPageUrl("ai-courses")}>
                                <Button size="lg" className="bg-gradient-to-r from-cyan-500 to-pink-500 hover:from-cyan-400 hover:to-pink-400 text-white px-8 py-4 text-lg font-semibold rounded-2xl shadow-lg">
                                    Shape Your AI Future
                                    <ArrowRight className="w-5 h-5 ml-2" />
                                </Button>
                            </Link>
                            <Link to={createPageUrl("corporate-ai-workshops")}>
                                <Button size="lg" variant="outline" className="bg-white/10 text-white border-2 border-white/30 hover:bg-white hover:text-gray-900 px-8 py-4 text-lg font-semibold rounded-2xl">
                                    Transform Your Team
                                </Button>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </PageSection>
    );
}