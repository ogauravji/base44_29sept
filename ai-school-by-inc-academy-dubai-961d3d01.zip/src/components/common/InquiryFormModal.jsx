
import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CheckCircle, Send, Sparkles, Brain, Zap, Target } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { createInquiry } from "@/api/functions"; // Import the new backend function

export default function InquiryFormModal({ isOpen, onClose, title, subtitle }) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    companySize: "",
    interest: "",
    message: ""
  });
  const [currentStep, setCurrentStep] = useState(1);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (currentStep < 3) setCurrentStep(currentStep + 1);
  };

  const handleBack = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isSubmitting) return;

    setIsSubmitting(true);
    try {
      console.log('Submitting inquiry via backend function:', formData);
      
      // Use the new backend function
      const response = await createInquiry(formData);
      
      if (response.status !== 200) {
        // Use response.data for a more specific error message if available
        const errorData = response.data || {};
        throw new Error(`Server responded with status ${response.status}: ${errorData.error || 'Unknown server error'}`);
      }

      console.log('Inquiry submitted successfully:', response.data);
      setIsSubmitted(true);
      
      // Reset form after successful submission
      setTimeout(() => {
        onClose();
        setIsSubmitted(false);
        setCurrentStep(1);
        setFormData({ name: "", email: "", phone: "", company: "", companySize: "", interest: "", message: "" });
      }, 3000);

    } catch (error) {
      console.error("Failed to submit inquiry:", error);
      
      let errorMessage = 'Unknown error occurred';
      // Simplified error message parsing
      if (error.message) {
        errorMessage = error.message;
      }
      
      alert(`Submission failed: ${errorMessage}. Please try again or contact us directly via WhatsApp at +971 52 437 1377.`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const canProceed = () => {
    switch (currentStep) {
      case 1:
        return formData.name && formData.email && formData.phone;
      case 2:
        return formData.company && formData.companySize && formData.interest;
      case 3:
        return true;
      default:
        return false;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 border-0 shadow-2xl">
        {/* Background decorations */}
        <div className="absolute top-10 right-10 w-20 h-20 bg-blue-200/30 rounded-full blur-xl"></div>
        <div className="absolute bottom-10 left-10 w-16 h-16 bg-purple-200/30 rounded-full blur-xl"></div>
        
        <DialogHeader className="relative">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl flex items-center justify-center">
              <Brain className="w-6 h-6 text-white" />
            </div>
            <div>
              <DialogTitle className="text-2xl font-bold text-gray-900">{title}</DialogTitle>
              <DialogDescription className="text-gray-600">{subtitle}</DialogDescription>
            </div>
          </div>
          
          {/* Progress indicator */}
          {!isSubmitted && (
            <div className="flex items-center gap-2 mb-6">
              {[1, 2, 3].map((step) => (
                <div key={step} className="flex items-center">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-all duration-300 ${
                    currentStep >= step 
                      ? 'bg-gradient-to-r from-blue-600 to-purple-600 text-white' 
                      : 'bg-gray-200 text-gray-500'
                  }`}>
                    {currentStep > step ? <CheckCircle className="w-4 h-4" /> : step}
                  </div>
                  {step < 3 && <div className={`w-12 h-1 mx-2 rounded-full transition-all duration-300 ${
                    currentStep > step ? 'bg-gradient-to-r from-blue-600 to-purple-600' : 'bg-gray-200'
                  }`} />}
                </div>
              ))}
            </div>
          )}
        </DialogHeader>

        <AnimatePresence mode="wait">
          {!isSubmitted ? (
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="relative"
            >
              {currentStep === 1 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Target className="w-12 h-12 text-blue-600 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900">Let's get to know you</h3>
                    <p className="text-sm text-gray-600">Tell us about yourself</p>
                  </div>
                  
                  <div className="grid gap-4">
                    <div>
                      <Label htmlFor="name" className="text-gray-700 font-medium">Full Name *</Label>
                      <Input 
                        id="name" 
                        value={formData.name} 
                        onChange={(e) => handleChange('name', e.target.value)}
                        className="mt-1 bg-white/70 border-gray-200 focus:border-blue-500"
                        placeholder="Enter your full name"
                        required 
                      />
                    </div>
                    <div>
                      <Label htmlFor="email" className="text-gray-700 font-medium">Email Address *</Label>
                      <Input 
                        id="email" 
                        type="email" 
                        value={formData.email} 
                        onChange={(e) => handleChange('email', e.target.value)}
                        className="mt-1 bg-white/70 border-gray-200 focus:border-blue-500"
                        placeholder="your.email@company.com"
                        required 
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone" className="text-gray-700 font-medium">Phone Number *</Label>
                      <Input 
                        id="phone" 
                        type="tel" 
                        value={formData.phone} 
                        onChange={(e) => handleChange('phone', e.target.value)}
                        className="mt-1 bg-white/70 border-gray-200 focus:border-blue-500"
                        placeholder="+971 50 123 4567"
                        required 
                      />
                    </div>
                  </div>
                </div>
              )}

              {currentStep === 2 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Sparkles className="w-12 h-12 text-purple-600 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900">About your business</h3>
                    <p className="text-sm text-gray-600">Help us understand your needs</p>
                  </div>
                  
                  <div className="grid gap-4">
                    <div>
                      <Label htmlFor="company" className="text-gray-700 font-medium">Company Name *</Label>
                      <Input 
                        id="company" 
                        value={formData.company} 
                        onChange={(e) => handleChange('company', e.target.value)}
                        className="mt-1 bg-white/70 border-gray-200 focus:border-blue-500"
                        placeholder="Your company name"
                        required 
                      />
                    </div>
                    <div>
                      <Label className="text-gray-700 font-medium">Company Size *</Label>
                      <Select value={formData.companySize} onValueChange={(value) => handleChange('companySize', value)}>
                        <SelectTrigger className="mt-1 bg-white/70 border-gray-200">
                          <SelectValue placeholder="Select company size" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="startup">Startup (1-10 employees)</SelectItem>
                          <SelectItem value="small">Small (11-50 employees)</SelectItem>
                          <SelectItem value="medium">Medium (51-200 employees)</SelectItem>
                          <SelectItem value="large">Large (200+ employees)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label className="text-gray-700 font-medium">Primary Interest *</Label>
                      <Select value={formData.interest} onValueChange={(value) => handleChange('interest', value)}>
                        <SelectTrigger className="mt-1 bg-white/70 border-gray-200">
                          <SelectValue placeholder="What interests you most?" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="training">AI Marketing Training</SelectItem>
                          <SelectItem value="corporate">Corporate Workshops</SelectItem>
                          <SelectItem value="consultancy">AI Strategy Consultancy</SelectItem>
                          <SelectItem value="agency">Done-for-You Agency Services</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
              )}

              {currentStep === 3 && (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <Zap className="w-12 h-12 text-pink-600 mx-auto mb-3" />
                    <h3 className="text-lg font-semibold text-gray-900">Tell us more</h3>
                    <p className="text-sm text-gray-600">Any specific requirements or questions?</p>
                  </div>
                  
                  <div>
                    <Label htmlFor="message" className="text-gray-700 font-medium">Message (Optional)</Label>
                    <Textarea 
                      id="message" 
                      value={formData.message} 
                      onChange={(e) => handleChange('message', e.target.value)}
                      className="mt-1 bg-white/70 border-gray-200 focus:border-blue-500 min-h-[100px]"
                      placeholder="Tell us about your current challenges, goals, or any specific questions you have..."
                    />
                  </div>
                  
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="font-semibold text-blue-900 mb-2">What happens next?</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• We'll review your information within 24 hours</li>
                      <li>• Schedule a personalized consultation call</li>
                      <li>• Discuss your AI transformation roadmap</li>
                      <li>• Provide customized recommendations</li>
                    </ul>
                  </div>
                </div>
              )}

              {/* Navigation buttons */}
              <div className="flex justify-between pt-6">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={handleBack}
                  disabled={currentStep === 1}
                  className="bg-white/70"
                >
                  Back
                </Button>
                
                {currentStep < 3 ? (
                  <Button 
                    type="button" 
                    onClick={handleNext}
                    disabled={!canProceed()}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    Next
                  </Button>
                ) : (
                  <Button 
                    type="button" 
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                  >
                    {isSubmitting ? (
                      <>
                        <Send className="w-4 h-4 mr-2 animate-pulse" />
                        Submitting...
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4 mr-2" />
                        Submit Request
                      </>
                    )}
                  </Button>
                )}
              </div>
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center justify-center py-12 text-center"
            >
              <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mb-6">
                <CheckCircle className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h3>
              <p className="text-gray-600 mb-4">Your request has been received successfully.</p>
              <p className="text-sm text-gray-500">Our AI experts will be in touch within 24 hours to schedule your personalized consultation.</p>
            </motion.div>
          )}
        </AnimatePresence>
      </DialogContent>
    </Dialog>
  );
}
