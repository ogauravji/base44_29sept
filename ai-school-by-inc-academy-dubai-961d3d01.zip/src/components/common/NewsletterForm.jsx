import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Download, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { subscribeNewsletter } from "@/api/functions";

export default function NewsletterForm({ 
    source = "newsletter", 
    placeholder = "Enter your email address",
    buttonText = "Subscribe",
    buttonIcon: ButtonIcon = Download,
    className = "",
    onSuccess,
    onError
}) {
    const [email, setEmail] = useState("");
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [message, setMessage] = useState("");
    const [isError, setIsError] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (isSubmitting || !email) return;

        setIsSubmitting(true);
        setIsError(false);

        try {
            const response = await subscribeNewsletter({ email, source });
            
            if (response.data.success) {
                setIsSubmitted(true);
                setMessage(response.data.message || 'Successfully subscribed!');
                setEmail("");
                
                if (onSuccess) onSuccess(response.data);

                // Reset success state after 5 seconds
                setTimeout(() => {
                    setIsSubmitted(false);
                    setMessage("");
                }, 5000);
            } else {
                throw new Error(response.data.error || 'Subscription failed');
            }
        } catch (error) {
            console.error("Newsletter subscription error:", error);
            setIsError(true);
            setMessage(error.message || 'An error occurred. Please try again.');
            
            if (onError) onError(error);
            
            // Reset error state after 5 seconds
            setTimeout(() => {
                setIsError(false);
                setMessage("");
            }, 5000);
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isSubmitted) {
        return (
            <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className={`flex items-center justify-center gap-3 text-green-600 bg-green-100 p-4 rounded-xl border border-green-200 ${className}`}
            >
                <CheckCircle2 className="w-5 h-5" />
                <span className="font-semibold">{message}</span>
            </motion.div>
        );
    }

    if (isError) {
        return (
            <motion.div
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-4 bg-red-100 text-red-700 rounded-lg border border-red-200 ${className}`}
            >
                {message}
                <button 
                    onClick={() => {setIsError(false); setMessage("");}} 
                    className="ml-2 underline hover:no-underline"
                >
                    Try again
                </button>
            </motion.div>
        );
    }

    return (
        <form onSubmit={handleSubmit} className={`flex flex-col sm:flex-row gap-3 ${className}`}>
            <input
                type="email"
                placeholder={placeholder}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                disabled={isSubmitting}
                className="flex-1 px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50 text-gray-900"
            />
            <Button
                type="submit"
                disabled={isSubmitting || !email}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 font-semibold rounded-lg disabled:opacity-50 whitespace-nowrap"
            >
                {isSubmitting ? (
                    <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Processing...
                    </>
                ) : (
                    <>
                        <ButtonIcon className="w-4 h-4 mr-2" />
                        {buttonText}
                    </>
                )}
            </Button>
        </form>
    );
}