import React from 'react';
import { motion } from 'framer-motion';

const PageSection = ({ children, className = '', ...props }) => {
  return (
    <motion.section
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.2 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className={`py-16 md:py-24 px-4 sm:px-6 lg:px-8 ${className}`}
      {...props}
    >
      {children}
    </motion.section>
  );
};

export default PageSection;