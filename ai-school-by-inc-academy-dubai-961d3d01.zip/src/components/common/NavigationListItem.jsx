import React from 'react';
import { Link } from 'react-router-dom';
import { NavigationMenuLink } from "@/components/ui/navigation-menu";

const NavigationListItem = React.forwardRef(({ className = "", title, href, icon: Icon, children, ...props }, ref) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <Link
          to={href}
          ref={ref}
          className={`block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-accent hover:text-accent-foreground focus:bg-accent focus:text-accent-foreground ${className}`}
          {...props}
        >
          <div className="flex items-center gap-3">
             {Icon && <Icon className="h-5 w-5 text-blue-600" />}
             <div className="text-sm font-bold leading-none">{title}</div>
          </div>
          <p className="line-clamp-2 text-sm leading-snug text-muted-foreground ml-8">
            {children}
          </p>
        </Link>
      </NavigationMenuLink>
    </li>
  )
});
NavigationListItem.displayName = "NavigationListItem";

export default NavigationListItem;