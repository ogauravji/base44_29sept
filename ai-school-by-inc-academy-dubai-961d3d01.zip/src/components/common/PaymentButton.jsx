import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import PrePaymentModal from "./PrePaymentModal";
import { generateCheckout } from "@/api/functions";

export default function PaymentButton({ 
  courseType, 
  courseName, 
  price, 
  className = "", 
  children,
  ...props 
}) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const courseDetails = {
    name: courseName,
    price: price,
    type: courseType
  };

  const handleFormSubmit = async (userData) => {
    setIsProcessing(true);
    try {
      // The generateCheckout function now handles creating the pending enrollment.
      const response = await generateCheckout({
        courseType,
        userData,
        successUrl: `${window.location.origin}/success`,
        cancelUrl: window.location.href
      });

      if (response.data?.url) {
        window.location.href = response.data.url;
      } else {
        const errorMsg = response.data?.error || 'Invalid checkout URL received';
        throw new Error(errorMsg);
      }
    } catch (error) {
      console.error('Payment error:', error);
      alert(`Payment setup failed: ${error.message}. Please try again or contact support.`);
      setIsProcessing(false); // Reset on failure
    }
    // No finally block, as successful navigation doesn't need a state reset.
  };

  return (
    <>
      <Button
        onClick={() => setIsModalOpen(true)}
        className={className}
        {...props}
      >
        {children}
      </Button>

      <PrePaymentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleFormSubmit}
        courseDetails={courseDetails}
        isSubmitting={isProcessing}
      />
    </>
  );
}