import React from 'react';

// Ultra-lightweight fallback
const SuspenseFallback = () => {
  return (
    <div className="w-full h-32 flex items-center justify-center bg-gray-50">
      <div className="text-blue-600 text-sm">Loading...</div>
    </div>
  );
};

export default SuspenseFallback;