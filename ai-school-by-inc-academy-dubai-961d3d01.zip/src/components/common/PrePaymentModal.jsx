
import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { User, Mail, Phone, Building, Briefcase, Globe } from "lucide-react";

const countries = [
  "United Arab Emirates", "Saudi Arabia", "Qatar", "Kuwait", "Oman", "Bahrain",
  "India", "Pakistan", "Egypt", "Jordan", "Lebanon", "Morocco", "Tunisia",
  "United States", "United Kingdom", "Canada", "Australia", "Germany", "France",
  "Singapore", "Malaysia", "Philippines", "Other"
];

export default function PrePaymentModal({ 
  isOpen, 
  onClose, 
  onSubmit, 
  courseDetails,
  isSubmitting 
}) {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    designation: "",
    country: ""
  });

  const [errors, setErrors] = useState({});

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: "" }));
    }
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S/.test(formData.email)) {
      newErrors.email = "Please enter a valid email";
    }
    if (!formData.phone.trim()) newErrors.phone = "Phone number is required";
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      onSubmit(formData);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[500px] bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-gray-900 mb-2">
            Complete Your Enrollment
          </DialogTitle>
          <DialogDescription className="text-gray-600">
            You're enrolling in: <strong>{courseDetails?.name || 'Course'}</strong><br/>
            Price: <strong>${courseDetails?.price || '0'}</strong><br/>
            Please provide your details to continue to payment.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Name - Required */}
          <div>
            <Label htmlFor="name" className="text-gray-700 font-medium flex items-center gap-2">
              <User className="w-4 h-4" />
              Full Name *
            </Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              className={`mt-1 ${errors.name ? 'border-red-500' : ''}`}
              placeholder="Enter your full name"
            />
            {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
          </div>

          {/* Email - Required */}
          <div>
            <Label htmlFor="email" className="text-gray-700 font-medium flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email Address *
            </Label>
            <Input
              id="email"
              type="email"
              value={formData.email}
              onChange={(e) => handleChange('email', e.target.value)}
              className={`mt-1 ${errors.email ? 'border-red-500' : ''}`}
              placeholder="your.email@company.com"
            />
            {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
          </div>

          {/* Phone - Required */}
          <div>
            <Label htmlFor="phone" className="text-gray-700 font-medium flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Phone Number *
            </Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
              className={`mt-1 ${errors.phone ? 'border-red-500' : ''}`}
              placeholder="+971 50 123 4567"
            />
            {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
          </div>

          {/* Company Name - Optional */}
          <div>
            <Label htmlFor="company" className="text-gray-700 font-medium flex items-center gap-2">
              <Building className="w-4 h-4" />
              Company Name
            </Label>
            <Input
              id="company"
              value={formData.company}
              onChange={(e) => handleChange('company', e.target.value)}
              className="mt-1"
              placeholder="Your company (optional)"
            />
          </div>

          {/* Designation - Optional */}
          <div>
            <Label htmlFor="designation" className="text-gray-700 font-medium flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Designation
            </Label>
            <Input
              id="designation"
              value={formData.designation}
              onChange={(e) => handleChange('designation', e.target.value)}
              className="mt-1"
              placeholder="Your job title (optional)"
            />
          </div>

          {/* Country - Optional */}
          <div>
            <Label className="text-gray-700 font-medium flex items-center gap-2">
              <Globe className="w-4 h-4" />
              Country
            </Label>
            <Select value={formData.country} onValueChange={(value) => handleChange('country', value)}>
              <SelectTrigger className="mt-1">
                <SelectValue placeholder="Select your country (optional)" />
              </SelectTrigger>
              <SelectContent>
                {countries.map((country) => (
                  <SelectItem key={country} value={country}>{country}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Submit Button */}
          <div className="pt-4">
            <Button
              type="submit"
              disabled={isSubmitting}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-3 text-lg font-semibold rounded-lg shadow-lg"
            >
              {isSubmitting ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                  Processing...
                </>
              ) : (
                `Continue to Payment ($${courseDetails?.price || '0'})`
              )}
            </Button>
          </div>
        </form>

        <div className="text-center mt-4">
          <p className="text-xs text-gray-500">
            🔒 Secure payment powered by Stripe<br />
            You'll be redirected to complete your payment
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
