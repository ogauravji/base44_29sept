
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
    LogIn, 
    Eye,
    EyeOff,
    ArrowRight,
    Lock,
    Mail,
    Gift
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AffiliateLogin() {
    const [formData, setFormData] = useState({
        email: '', // Changed initial email to empty string
        password: '' // Changed initial password to empty string
    });
    const [isLoading, setIsLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');

    // Removed createTestAccount function
    // Removed debugDatabase function

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');

        try {
            const response = await fetch('https://base44.app/api/apps/68947005b6a22444961d3d01/functions/loginAffiliate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                localStorage.setItem('affiliateData', JSON.stringify(data.affiliate));
                window.location.href = createPageUrl('AffiliateDashboard');
            } else {
                setError(data.error || 'Login failed');
            }
        } catch (error) {
            console.error('Login error:', error);
            setError('Login failed. Please check your credentials and try again.');
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
            {/* Hero Section */}
            <section className="relative bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(147,51,234,0.3),transparent)]"></div>
                <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
                    <div className="text-center mb-16">
                        <Badge className="px-6 py-3 text-lg font-bold bg-gradient-to-r from-yellow-400 to-orange-500 text-black border-0 mb-8">
                            <Gift className="w-5 h-5 mr-2" />
                            AFFILIATE PORTAL
                        </Badge>

                        <h1 className="text-4xl md:text-5xl font-bold mb-8 leading-tight">
                            Welcome Back,
                            <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent block mt-2">
                                Partner!
                            </span>
                        </h1>

                        <p className="text-xl text-blue-100 mb-12 max-w-2xl mx-auto leading-relaxed">
                            Access your affiliate dashboard to track earnings, get your unique links, and manage your referrals.
                        </p>
                    </div>
                </div>
            </section>

            {/* Login Form */}
            <section className="py-20 bg-gray-50 flex items-center justify-center">
                <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8 w-full">
                    <Card className="shadow-2xl border-0 rounded-3xl overflow-hidden">
                        <CardContent className="p-8">
                            <div className="text-center mb-8">
                                <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                                    <LogIn className="w-8 h-8 text-white" />
                                </div>
                                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                                    Affiliate Login
                                </h2>
                                <p className="text-gray-600">
                                    Sign in to access your dashboard
                                </p>
                            </div>

                            {/* TEST ACCOUNT BUTTON section removed */}

                            {error && (
                                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-6">
                                    {error}
                                </div>
                            )}

                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div className="space-y-2">
                                    <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                                        <Mail className="w-4 h-4" />
                                        Email Address
                                    </label>
                                    <Input
                                        type="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        placeholder="Enter your email"
                                        required
                                        className="h-12 text-base rounded-xl border-gray-300 focus:border-purple-500 focus:ring-purple-500"
                                    />
                                </div>

                                <div className="space-y-2">
                                    <label className="text-sm font-semibold text-gray-700 flex items-center gap-2">
                                        <Lock className="w-4 h-4" />
                                        Password
                                    </label>
                                    <div className="relative">
                                        <Input
                                            type={showPassword ? "text" : "password"}
                                            name="password"
                                            value={formData.password}
                                            onChange={handleInputChange}
                                            placeholder="Enter your password"
                                            required
                                            className="h-12 text-base rounded-xl border-gray-300 focus:border-purple-500 focus:ring-purple-500 pr-12"
                                        />
                                        <button
                                            type="button"
                                            onClick={() => setShowPassword(!showPassword)}
                                            className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600"
                                        >
                                            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                        </button>
                                    </div>
                                </div>

                                <Button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full h-12 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                                >
                                    {isLoading ? 'Signing In...' : 'Sign In'}
                                    <ArrowRight className="w-5 h-5 ml-2" />
                                </Button>
                            </form>

                            <div className="mt-6 text-center">
                                <Link 
                                    to={createPageUrl('ForgotPassword')}
                                    className="text-sm text-purple-600 hover:text-purple-700 font-medium"
                                >
                                    Forgot your password?
                                </Link>
                            </div>

                            <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                                <p className="text-gray-600 text-sm mb-4">
                                    Don't have an affiliate account?
                                </p>
                                <Link to={createPageUrl('affiliate-program')}>
                                    <Button variant="outline" className="w-full border-2 border-purple-200 text-purple-600 hover:bg-purple-50 font-semibold rounded-xl h-12">
                                        Learn About Our Program
                                    </Button>
                                </Link>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </section>
        </div>
    );
}
