import React, { useState } from "react";

export default function AffiliateDebugPanel() {
    const [results, setResults] = useState(null);
    const [loading, setLoading] = useState(false);
    const [email, setEmail] = useState('');

    const runDebug = async (action) => {
        setLoading(true);
        try {
            const response = await fetch('https://base44.app/api/apps/68947005b6a22444961d3d01/functions/debugAffiliate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email, action })
            });
            
            const data = await response.json();
            setResults(data);
        } catch (error) {
            console.error('Error:', error);
            setResults({ error: error.message });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ padding: '20px', fontFamily: 'monospace' }}>
            <h1>🐛 Affiliate System Debug Panel</h1>
            
            <div style={{ marginBottom: '20px' }}>
                <input
                    type="email"
                    placeholder="Email to check (optional)"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    style={{ padding: '8px', width: '300px', marginRight: '10px' }}
                />
            </div>

            <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginBottom: '20px' }}>
                <button 
                    onClick={() => runDebug('check')}
                    disabled={loading}
                    style={{ padding: '10px 20px', backgroundColor: '#3b82f6', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                    🔍 Check Database
                </button>

                <button 
                    onClick={() => runDebug('test_hash')}
                    disabled={loading}
                    style={{ padding: '10px 20px', backgroundColor: '#10b981', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                    🔐 Test Password Hash
                </button>

                <button 
                    onClick={() => runDebug('create_test')}
                    disabled={loading}
                    style={{ padding: '10px 20px', backgroundColor: '#f59e0b', color: 'white', border: 'none', borderRadius: '4px' }}
                >
                    ➕ Create Test Affiliate
                </button>
            </div>

            {loading && <div style={{ color: '#6b7280' }}>⏳ Loading...</div>}

            {results && (
                <div style={{ marginTop: '20px' }}>
                    <h2>📊 Debug Results:</h2>
                    <pre style={{ 
                        backgroundColor: '#f3f4f6', 
                        padding: '15px', 
                        borderRadius: '8px', 
                        overflow: 'auto',
                        fontSize: '12px',
                        maxHeight: '600px'
                    }}>
                        {JSON.stringify(results, null, 2)}
                    </pre>

                    {results.results?.test_creation?.success && (
                        <div style={{ 
                            marginTop: '15px', 
                            padding: '10px', 
                            backgroundColor: '#d1fae5', 
                            border: '1px solid #10b981', 
                            borderRadius: '4px' 
                        }}>
                            <h3>✅ Test Affiliate Created!</h3>
                            <p><strong>Email:</strong> debug@inc.academy</p>
                            <p><strong>Password:</strong> Gaurav@123456</p>
                            <p>Try logging in with these credentials now!</p>
                        </div>
                    )}
                </div>
            )}

            <div style={{ marginTop: '30px', padding: '15px', backgroundColor: '#fef3c7', border: '1px solid #f59e0b', borderRadius: '8px' }}>
                <h3>🔧 Debug Steps:</h3>
                <ol>
                    <li><strong>Check Database:</strong> See all affiliates and applications</li>
                    <li><strong>Test Password Hash:</strong> Verify hashing is working</li>
                    <li><strong>Create Test Affiliate:</strong> Add debug@inc.academy with known password</li>
                    <li><strong>Try Login:</strong> Go to affiliate login and test with created credentials</li>
                </ol>
            </div>
        </div>
    );
}