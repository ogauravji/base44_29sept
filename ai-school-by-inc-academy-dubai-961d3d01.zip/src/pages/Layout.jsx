

import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import ScrollToTop from "@/components/common/ScrollToTop";
import InquiryFormModal from "@/components/common/InquiryFormModal"; // Added import
import {
  Menu,
  X,
  Mail,
  MessageCircle,
  Linkedin,
  Instagram,
  Brain,
  Rocket,
  Zap,
  Building } from
"lucide-react";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger } from
"@/components/ui/navigation-menu";

// Simplified navigation data
const mainNavLinks = [
{ title: "Consultancy", href: createPageUrl("ai-consultants") },
{ title: "Agency", href: createPageUrl("ai-implementation-agency") }];


const courseComponents = [
{
  title: "3 Hour AI Mastermind",
  href: createPageUrl("ai-skills-mastermind"),
  description: "AI Skills to 10x Your Career in 2025.",
  icon: Zap
},
{
  title: "Level 1: AI Foundation",
  href: createPageUrl("ai-beginners-course"),
  description: "Complete AI Training for Business Professionals.",
  icon: Brain
},
{
  title: "Level 2: AI Accelerator",
  href: createPageUrl("ai-advanced-course"),
  description: "Build Custom AI Systems & Automation.",
  icon: Rocket
},
{
  title: "Corporate AI Training",
  href: createPageUrl("corporate-ai-workshops"),
  description: "Executive Workshops & Team Transformation.",
  icon: Building
}];


const NavigationListItem = React.forwardRef(({ className = "", title, href, icon: Icon, children, ...props }, ref) => {
  return (
    <li>
      <NavigationMenuLink asChild>
        <Link
          to={href}
          ref={ref}
          className={`block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-gray-100 focus:bg-gray-100 ${className}`}
          {...props}>

          <div className="flex items-center gap-3">
             {Icon && <Icon className="h-5 w-5 text-blue-600" />}
             <div className="text-sm font-bold leading-none">{title}</div>
          </div>
          <p className="text-sm leading-snug text-gray-600 ml-8">
            {children}
          </p>
        </Link>
      </NavigationMenuLink>
    </li>);

});
NavigationListItem.displayName = "NavigationListItem";

export default function Layout({ children, currentPageName }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false); // Added state for modal

  const openModal = () => {
    setIsModalOpen(true);
    setMobileMenuOpen(false); // Close mobile menu if open
  };

  return (
    <div className="min-h-screen bg-white font-sans">
      <ScrollToTop />
      
      {/* Inquiry Form Modal */}
      <InquiryFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Book a Discovery Call"
        subtitle="Let's discuss how our AI solutions can transform your business." />


      {/* Simplified styles */}
      <style>{`
        body {
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
          -webkit-font-smoothing: antialiased;
        }
        @media (max-width: 640px) {
          h1 { font-size: 1.5rem !important; }
          h2 { font-size: 1.25rem !important; }
          .text-xl { font-size: 1rem !important; }
          .text-2xl { font-size: 1.25rem !important; }
          .text-3xl { font-size: 1.5rem !important; }
        }
      `}</style>

      {/* Header */}
      <header className="fixed top-0 w-full z-50 bg-white/95 backdrop-blur-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center">
              <img
                src="https://i.imghippo.com/files/Ekk9035HHM.png"
                alt="Inc. Academy Logo"
                className="h-10 w-auto"
                width="200"
                height="40"
                loading="eager" />

            </Link>

            {/* Desktop Navigation */}
            <div className="hidden lg:flex items-center space-x-2">
              <NavigationMenu>
                <NavigationMenuList>
                  <NavigationMenuItem>
                    <NavigationMenuTrigger className="text-gray-700 hover:text-blue-600 font-semibold">
                      Courses
                    </NavigationMenuTrigger>
                    <NavigationMenuContent>
                      <ul className="grid w-[400px] gap-3 p-4 md:w-[500px] md:grid-cols-2">
                        {courseComponents.map((component) =>
                        <NavigationListItem
                          key={component.title}
                          title={component.title}
                          href={component.href}
                          icon={component.icon}>

                            {component.description}
                          </NavigationListItem>
                        )}
                      </ul>
                    </NavigationMenuContent>
                  </NavigationMenuItem>
                  {mainNavLinks.map((item) =>
                  <NavigationMenuItem key={item.title}>
                        <Link to={item.href} className="text-gray-700 px-3 py-2 text-sm font-semibold hover:text-blue-600">
                          {item.title}
                        </Link>
                     </NavigationMenuItem>
                  )}
                </NavigationMenuList>
              </NavigationMenu>
              
              {/* Desktop CTA Button */}
              <Button
                onClick={openModal}
                className="ml-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-2 font-semibold rounded-lg shadow-md transition-all duration-300">

                Book Discovery Call
              </Button>
            </div>

            {/* Mobile Menu Button */}
            <div className="lg:hidden">
              <button
                className="p-2 text-gray-700"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                aria-label="Toggle menu">
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen &&
        <div className="lg:hidden bg-white border-t">
            <div className="px-4 py-4 space-y-2">
              {/* Mobile CTA Button */}
              <div className="pb-4 border-b border-gray-200">
                <Button
                onClick={openModal}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 font-semibold rounded-lg shadow-md transition-all duration-300">

                  Book Discovery Call
                </Button>
              </div>
              
              <div className="px-3 py-2 font-semibold text-gray-500 text-sm">Courses</div>
              {courseComponents.map((item) =>
            <Link
              key={item.title}
              to={item.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block text-gray-700 py-2 px-3 rounded-md hover:bg-gray-100 font-semibold">

                  {item.title}
                </Link>
            )}
              <div className="border-t my-2"></div>
               {mainNavLinks.map((item) =>
            <Link
              key={item.title}
              to={item.href}
              onClick={() => setMobileMenuOpen(false)}
              className="block text-gray-700 py-2 px-3 rounded-md hover:bg-gray-100 font-semibold">

                  {item.title}
                </Link>
            )}
            </div>
          </div>
        }
      </header>

      {/* Main Content */}
      <main className="pt-16">
        {children}
      </main>

      {/* Simplified Footer */}
      <footer className="bg-gray-900 text-gray-300">
        <div className="max-w-7xl mx-auto pt-16 pb-12 px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="space-y-4">
                    <Link to={createPageUrl("Home")}>
                        <img
                  src="https://i.imghippo.com/files/Ekk9035HHM.png"
                  alt="Inc. Academy Logo"
                  className="h-10 bg-white p-1 rounded-md"
                  loading="lazy" />

                    </Link>
                    <p className="text-sm text-gray-400 leading-relaxed">
                        Empowering professionals with AI skills for the future of work.
                    </p>
                </div>

                <div>
                    <h3 className="text-sm font-semibold uppercase text-white mb-4">AI Training</h3>
                    <ul className="space-y-3">
                        {courseComponents.slice(0, 3).map((item) =>
                <li key={item.title}>
                                <Link to={item.href} className="text-gray-400 font-semibold hover:text-white transition-colors">
                                    {item.title}
                                </Link>
                            </li>
                )}
                    </ul>
                </div>

                <div>
                    <h3 className="text-sm font-semibold uppercase text-white mb-4">Company</h3>
                     <ul className="space-y-3">
                        <li><Link to={createPageUrl("about")} className="text-gray-400 font-semibold hover:text-white transition-colors">About Us</Link></li>
                        <li><Link to={createPageUrl("Blog")} className="text-gray-400 font-semibold hover:text-white transition-colors">Blog</Link></li>
                        <li><Link to={createPageUrl("ai-consultants")} className="text-gray-400 font-semibold hover:text-white transition-colors">Consultancy</Link></li>
                        <li><Link to={createPageUrl("affiliate-program")} className="text-gray-400 font-semibold hover:text-white transition-colors">
                            <span className="flex items-center gap-1">
                                Affiliate Program
                                <span className="text-xs bg-green-600 text-white px-1.5 py-0.5 rounded-full">25%</span>
                            </span>
                        </Link></li>
                        <li><Link to={createPageUrl("AffiliateLogin")} className="text-gray-400 font-semibold hover:text-white transition-colors">Affiliate Login</Link></li>
                        <li><Link to={createPageUrl("contact")} className="text-gray-400 font-semibold hover:text-white transition-colors">Contact</Link></li>
                    </ul>
                </div>
                
                <div>
                     <h3 className="text-sm font-semibold uppercase text-white mb-4">Connect</h3>
                     <a href="mailto:hello@inc.academy" className="flex items-center gap-3 mb-4 font-semibold">
                        <Mail className="w-5 h-5 text-gray-500" />
                        <span className="text-gray-400">hello@inc.academy</span>
                    </a>
                     <div className="flex space-x-3">
                         <a
                  href="https://www.linkedin.com/company/incacademydubai/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-blue-600">
                           <Linkedin className="w-5 h-5" />
                         </a>
                         <a
                  href="https://www.instagram.com/incdigitalacademy/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-pink-600">
                           <Instagram className="w-5 h-5" />
                         </a>
                     </div>
                </div>
            </div>

            <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
                <p className="text-sm text-gray-500 font-semibold">
                    © {new Date().getFullYear()} Inc Academy. All Rights Reserved.
                </p>
                <div className="flex gap-6 text-sm mt-4 md:mt-0">
                    <Link to={createPageUrl("Privacy")} className="text-gray-500 hover:text-white font-semibold">Privacy Policy</Link>
                    <Link to={createPageUrl("Terms")} className="text-gray-500 hover:text-white font-semibold">Terms</Link>
                </div>
            </div>
        </div>
      </footer>

      {/* WhatsApp Float */}
      <a
        href="https://wa.me/971524371377"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-4 right-4 w-14 h-14 bg-green-500 hover:bg-green-600 rounded-full flex items-center justify-center shadow-lg z-50">
        <MessageCircle className="w-7 h-7 text-white" />
      </a>
    </div>);

}

