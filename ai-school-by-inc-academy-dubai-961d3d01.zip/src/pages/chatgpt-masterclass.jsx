
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import PrePaymentModal from '@/components/common/PrePaymentModal';
import {
  Brain, CheckCircle2, Star, Users, Clock, Award, Target,
  Zap, BookOpen, MessageCircle, ArrowRight, Mail, Play,
  BrainCircuit, PenSquare, BarChart3, Lightbulb, Rocket,
  Shield, Globe, TrendingUp, Download, Gift, Sparkles,
  Calendar, MapPin, Monitor, Headphones, Eye, UserCheck, Crown, PlayCircle, Briefcase } from
"lucide-react";
import { motion } from "framer-motion";
import { registerFreeCourse } from '@/api/functions';


const agenda = [
{
  icon: BrainCircuit,
  title: "Module 1: ChatGPT Fundamentals",
  description: "Understanding ChatGPT's capabilities and limitations, setting up your ChatGPT workspace, basic prompting techniques, and understanding context and conversation flow."
},
{
  icon: PenSquare,
  title: "Module 2: The Art of Prompt Engineering",
  description: "The CLEAR prompting framework, role-based prompting techniques, context setting and persona creation, advanced prompt structures and formatting."
},
{
  icon: Briefcase,
  title: "Module 3: Business Applications",
  description: "Email writing and communication, meeting summaries and action items, report generation and analysis, customer service and support automation."
},
{
  icon: Lightbulb,
  title: "Module 4: Creative Content Generation",
  description: "Blog posts and article writing, social media content creation, marketing copy and advertising, creative storytelling and brainstorming."
},
{
  icon: BarChart3,
  title: "Module 5: Data Analysis & Research",
  description: "Data interpretation and insights, research assistance and fact-checking, trend analysis and predictions, competitive intelligence gathering."
},
{
  icon: Rocket,
  title: "Module 6: Advanced Techniques & Best Practices",
  description: "Chain-of-thought prompting, multi-step problem solving, error handling and prompt debugging, ethical AI usage and guidelines."
}];


const benefits = [
{ icon: Zap, title: "10x Productivity", description: "Automate routine tasks and focus on high-value work" },
{ icon: Brain, title: "Enhanced Creativity", description: "Break through creative blocks with AI-powered brainstorming" },
{ icon: Target, title: "Precision Results", description: "Get exactly what you need with advanced prompting techniques" },
{ icon: Clock, title: "Time Savings", description: "Reduce hours of work to minutes with smart automation" },
{ icon: TrendingUp, title: "Competitive Edge", description: "Stay ahead with cutting-edge AI skills" },
{ icon: Shield, title: "Error Reduction", description: "Minimize mistakes with AI-assisted quality control" }];


const testimonials = [
{
  quote: "Gaurav's sessions are a game changer. I walked away with AI skills I could apply the same day. This is the best introduction to AI for business I've seen.",
  author: "Sarah M.",
  role: "Marketing Director, GCC"
},
{
  quote: "We automated 40% of our reporting workflow after just one training. The hands-on approach makes it easy to understand and implement.",
  author: "Ahmed K.",
  role: "Founder, E-Com Brand"
},
{
  quote: "Mr Oberoi is one of the top educators. Industries, alumni, and professionals witness his outstanding excellence in the field. I strongly recommend Mr. Oberoi since I know for a fact that he demonstrated expertise.",
  author: "Aisha S.",
  role: "Special Projects, Global University"
},
{
  quote: "Gaurav has this impeccable ability to translate complex topics into simple relatable examples. I strongly recommend.",
  author: "Barkha G.",
  role: "Global Head of Ecommerce, FMCG"
},
{
  quote: "One of the most informative and enjoyable trainings I have attended in a while. Gaurav keeps it light on the mind and on the heart which makes for fun learning. My eyes have been opened to a whole new world by this man.",
  author: "Omar G.",
  role: "Head of Development, Retail"
},
{
  quote: "Gaurav Oberoi One of the professional leaders in the field, I attended him a course of courses that have been able to learn hidden in the past. Capable, leader, expert",
  author: "Meshal A.",
  role: "Government Office, KSA"
}];


const faqData = [
{
  q: "Is this course really free?",
  a: "Yes! This ChatGPT Masterclass is completely free. We believe everyone should have access to essential AI skills."
},
{
  q: "Do I need any prior experience with AI?",
  a: "No prior experience needed! This course starts from the basics and builds up to advanced techniques."
},
{
  q: "How long do I have access to the course?",
  a: "Once you register, you get lifetime access to all course materials and future updates."
},
{
  q: "Will I get a certificate?",
  a: "Yes, you'll receive a certificate of completion after finishing the masterclass."
},
{
  q: "Can I access this on mobile?",
  a: "Absolutely! The course is fully mobile-optimized so you can learn on any device."
},
{
  q: "Are there any hidden costs?",
  a: "None whatsoever. This is our way of giving back to the community and helping everyone succeed with AI."
},
{
  q: "What if I miss the live session?",
  a: "While we encourage live attendance for interaction, registered participants will receive access to the session materials."
},
{
  q: "Can I ask questions during the session?",
  a: "Yes! There will be dedicated Q&A segments where you can ask questions and get real-time answers."
},
{
  q: "What tools do I need to participate?",
  a: "Just a computer or mobile device with internet access. We'll show you how to access ChatGPT during the session."
},
{
  q: "Is this suitable for business teams?",
  a: "Absolutely! Many companies register their entire teams. The techniques work for individuals and organizations."
},
{
  q: "How is this different from other AI courses?",
  a: "This masterclass focuses on practical, immediately applicable ChatGPT techniques. You'll leave with skills you can use right away."
},
{
  q: "Will there be recordings available?",
  a: "Registered participants will receive access to key materials and resources shared during the live session."
}];


const clientLogos = [
{ src: "https://i.imghippo.com/files/AIj7022XwI.png", alt: "Google" },
{ src: "https://i.imghippo.com/files/BtVJ7689eU.png", alt: "TikTok" },
{ src: "https://i.imghippo.com/files/zETQ9249BY.png", alt: "Dubai Tourism" },
{ src: "https://i.imghippo.com/files/LjWL1133fc.png", alt: "Emirates" },
{ src: "https://i.imghippo.com/files/RymB7570vQ.png", alt: "Alshaya" },
{ src: "https://i.imghippo.com/files/IPE5684MnM.png", alt: "Unilever" },
{ src: "https://i.imghippo.com/files/QUIK6243XI.png", alt: "Etihad" },
{ src: "https://i.imghippo.com/files/CBg5407ZEg.png", alt: "Harvard Business School" }];


export default function ChatGPTMasterclass() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [openFaq, setOpenFaq] = useState(null);
  const [isRegistered, setIsRegistered] = useState(false);
  const [registeredEmail, setRegisteredEmail] = useState('');

  const courseDetails = {
    name: "ChatGPT Masterclass - 1 Hour Intensive Training",
    price: 0, // Free course
    type: "free-masterclass"
  };

  const handleFormSubmit = async (userData) => {
    setIsProcessing(true);
    try {
      const registrationData = {
        name: userData.name,
        email: userData.email,
        phone: userData.phone,
        company: userData.company,
        designation: userData.designation,
        country: userData.country,
        courseName: courseDetails.name,
        source: 'chatgpt-masterclass',
        sessionDate: '2024-10-02', // Date in YYYY-MM-DD format
        sessionDateFormatted: 'Wednesday, October 2nd, 2024',
        sessionTime: '3:00 PM - 4:00 PM (GST)',
        sessionFullDetails: 'Wednesday, October 2nd, 2024 at 3:00 PM - 4:00 PM (GST)',
        sessionTimezone: 'GST (Gulf Standard Time)',
        sessionPlatform: 'Zoom Meeting',
        sessionDuration: '1 Hour'
      };

      const response = await registerFreeCourse(registrationData);

      if (response.data.success) {
        setRegisteredEmail(userData.email);
        setIsRegistered(true);
        setIsModalOpen(false);
        setIsProcessing(false);
      } else {
        throw new Error(response.data.error || 'Registration failed');
      }
    } catch (error) {
      console.error('Registration error:', error);
      alert(`Registration failed: ${error.message}. Please try again or contact support.`);
      setIsProcessing(false);
    }
  };

  // Show registration confirmation page
  if (isRegistered) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center px-4 py-8 sm:py-16">
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-2xl mx-auto text-center w-full">

          <Card className="shadow-2xl border-0 bg-white rounded-2xl sm:rounded-3xl overflow-hidden">
            <CardContent className="p-6 sm:p-8 md:p-12">
              <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6 sm:mb-8">
                <CheckCircle2 className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-white" />
              </div>
              
              <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">
                🎉 Registration Confirmed!
              </h1>
              
              <p className="text-base sm:text-lg md:text-xl text-gray-600 mb-6 sm:mb-8 px-2">
                Welcome to the <strong>ChatGPT Masterclass</strong>!<br />
                Your seat is reserved for the live session.
              </p>
              
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 md:p-8 mb-6 sm:mb-8">
                <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-gray-900 mb-3 sm:mb-4">What's Next?</h3>
                <div className="space-y-3 sm:space-y-4 text-left">
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-semibold text-gray-900 text-sm sm:text-base">Check Your Email</p>
                      <p className="text-gray-600 text-sm sm:text-base">We've sent confirmation details to <strong className="break-all">{registeredEmail}</strong></p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-semibold text-gray-900 text-sm sm:text-base">Mark Your Calendar</p>
                      <p className="text-gray-600 text-sm sm:text-base">Wednesday, October 2nd, 2024 at 3:00 PM - 4:00 PM (GST)</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-semibold text-gray-900 text-sm sm:text-base">Zoom Link Coming</p>
                      <p className="text-gray-600 text-sm sm:text-base">You'll receive the meeting link 1 hour before the session</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle2 className="w-5 h-5 sm:w-6 sm:h-6 text-green-500 flex-shrink-0 mt-1" />
                    <div>
                      <p className="font-semibold text-gray-900 text-sm sm:text-base">Bring Your Laptop</p>
                      <p className="text-gray-600 text-sm sm:text-base">We'll have hands-on exercises during the live session</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-yellow-50 to-orange-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 mb-6 sm:mb-8 border-2 border-yellow-200">
                <h4 className="text-base sm:text-lg font-bold text-gray-900 mb-2">🎁 Special Bonus</h4>
                <p className="text-gray-700 text-sm sm:text-base">
                  All attendees will receive our exclusive "50 ChatGPT Prompts for Business" guide during the session!
                </p>
              </div>
              
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center mb-6 sm:mb-8">
                <Button
                  onClick={() => {
                    const event = {
                      title: "ChatGPT Masterclass - Free Training",
                      start: "20241002T110000Z", // 3 PM GST (UTC+4) is 11 AM UTC
                      end: "20241002T120000Z", // 4 PM GST (UTC+4) is 12 AM UTC
                      description: "Free ChatGPT Masterclass with Gaurav Oberoi",
                      location: "Online via Zoom"
                    };
                    const calendarUrl = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.title)}&dates=${event.start}/${event.end}&details=${encodeURIComponent(event.description)}&location=${encodeURIComponent(event.location)}`;
                    window.open(calendarUrl, '_blank');
                  }}
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-semibold px-6 sm:px-8 py-2 sm:py-3 rounded-xl text-sm sm:text-base">

                  <Calendar className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                  Add to Calendar
                </Button>
                
                <Button
                  variant="outline"
                  onClick={() => window.location.reload()}
                  className="border-2 border-gray-300 text-gray-700 hover:bg-gray-50 font-semibold px-6 sm:px-8 py-2 sm:py-3 rounded-xl text-sm sm:text-base">

                  Back to Course Page
                </Button>
              </div>
              
              <div className="text-center">
                <p className="text-xs sm:text-sm text-gray-500">
                  Questions? Email us at <a href="mailto:hello@inc.academy" className="text-blue-600 hover:text-blue-700 font-semibold">hello@inc.academy</a>
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>);

  }

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section with Form */}
      <section className="relative bg-gradient-to-br from-blue-900 via-purple-900 to-indigo-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(59,130,246,0.3),transparent)]"></div>
        <div className="absolute top-10 sm:top-20 left-5 sm:left-10 w-36 h-36 sm:w-72 sm:h-72 bg-blue-400/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 sm:bottom-20 right-5 sm:right-10 w-48 h-48 sm:w-96 sm:h-96 bg-purple-400/10 rounded-full blur-3xl"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 md:py-24">
          <div className="grid lg:grid-cols-2 gap-8 lg:gap-12 items-center">
            {/* Left Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}>

              <Badge className="px-4 sm:px-6 py-2 sm:py-3 text-sm sm:text-lg font-bold bg-gradient-to-r from-green-400 to-emerald-500 text-white border-0 mb-6 sm:mb-8">
                <Gift className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                100% FREE MASTERCLASS
              </Badge>

              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 sm:mb-8 leading-tight">
                ChatGPT
                <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent block mt-2">
                  Masterclass
                </span>
              </h1>

              <p className="text-lg sm:text-xl md:text-2xl text-blue-100 mb-6 sm:mb-8 leading-relaxed">
                Transform your productivity and creativity with the ultimate ChatGPT training.
                Learn practical techniques that will revolutionize how you work.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 sm:gap-6 mb-6 sm:mb-8">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 sm:w-5 sm:h-5 text-green-400" />
                  <span className="font-semibold text-sm sm:text-base">1 Hour Intensive</span>
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5 text-blue-400" />
                  <span className="font-semibold text-sm sm:text-base">Live Interactive</span>
                </div>
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 sm:w-5 sm:h-5 text-purple-400" />
                  <span className="font-semibold text-sm sm:text-base">Certificate Included</span>
                </div>
              </div>
            </motion.div>

            {/* Right Form */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}>

              <Card className="shadow-2xl border-0 bg-white rounded-2xl sm:rounded-3xl overflow-hidden">
                <CardContent className="p-6 sm:p-8 md:p-10">
                  <div className="text-center mb-6 sm:mb-8">
                    <Sparkles className="w-12 h-12 sm:w-16 sm:h-16 text-blue-500 mx-auto mb-3 sm:mb-4" />
                    <h2 className="text-xl sm:text-2xl md:text-3xl font-bold text-gray-900 mb-3 sm:mb-4">
                      Reserve Your Free Seat
                    </h2>
                    <p className="text-gray-600 text-base sm:text-lg mb-4 sm:mb-6">
                      Join thousands transforming their careers with AI
                    </p>

                    {/* Pricing Section */}
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl sm:rounded-2xl p-4 sm:p-6 mb-4 sm:mb-6 border-2 border-green-200">
                      <div className="flex items-center justify-center gap-3 sm:gap-4 mb-2">
                        <span className="text-xl sm:text-2xl text-gray-400 line-through font-bold">$150</span>
                        <span className="text-3xl sm:text-4xl font-black text-green-600">FREE</span>
                      </div>
                      <p className="text-xs sm:text-sm text-green-700 font-semibold">
                        🎉 Limited Time: Completely Free Access
                      </p>
                    </div>
                  </div>

                  <Button
                    onClick={() => setIsModalOpen(true)}
                    size="lg"
                    className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-bold text-base sm:text-lg py-3 sm:py-4 rounded-xl shadow-lg">

                    <Play className="w-5 h-5 sm:w-6 sm:h-6 mr-2" />
                    Get Free Instant Access
                  </Button>

                  <div className="text-center mt-3 sm:mt-4">
                    <p className="text-xs text-gray-500">
                      ✅ No Payment Required • 📧 Instant Email Confirmation
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Pre-payment Modal */}
      <PrePaymentModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSubmit={handleFormSubmit}
        courseDetails={courseDetails}
        isSubmitting={isProcessing} />


      {/* Date & Time Section - Enhanced */}
      <section className="py-16 sm:py-20 bg-gradient-to-br from-red-600 via-pink-600 to-purple-700 text-white relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(255,255,255,0.1),transparent)]"></div>
        <div className="absolute top-0 left-0 w-48 h-48 sm:w-96 sm:h-96 bg-gradient-to-r from-yellow-400/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-0 right-0 w-40 h-40 sm:w-80 sm:h-80 bg-gradient-to-r from-blue-400/20 to-transparent rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="text-center mb-8 sm:mb-12">

            <div className="inline-flex items-center px-4 sm:px-6 py-2 sm:py-3 bg-yellow-400/20 backdrop-blur-sm rounded-full border border-yellow-400/30 mb-4 sm:mb-6">
              <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse mr-3"></div>
              <span className="text-yellow-300 font-bold text-xs sm:text-sm uppercase tracking-wide">Limited Seats Available</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl md:text-6xl font-bold mb-3 sm:mb-4 bg-gradient-to-r from-white to-yellow-200 bg-clip-text text-transparent">
              🔥 Next Live Masterclass
            </h2>
            <p className="text-lg sm:text-xl text-pink-100 max-w-2xl mx-auto leading-relaxed px-4">
              Join hundreds of professionals learning ChatGPT mastery in this exclusive live training session
            </p>
          </motion.div>

          {/* Session Details Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 sm:gap-6 md:gap-8 mb-8 sm:mb-12">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-white/15 backdrop-blur-md rounded-2xl sm:rounded-3xl p-6 sm:p-8 border border-white/20 hover:bg-white/20 transition-all duration-300 group">

              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 group-hover:scale-110 transition-transform duration-300">
                <Calendar className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3 text-yellow-200">Date</h3>
              <p className="text-base sm:text-lg text-white font-semibold">Wednesday</p>
              <p className="text-lg sm:text-xl font-bold text-yellow-300">October 2nd, 2024</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white/15 backdrop-blur-md rounded-2xl sm:rounded-3xl p-6 sm:p-8 border border-white/20 hover:bg-white/20 transition-all duration-300 group">

              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 group-hover:scale-110 transition-transform duration-300">
                <Clock className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3 text-blue-200">Time</h3>
              <p className="text-base sm:text-lg text-white font-semibold">3:00 PM - 4:00 PM</p>
              <p className="text-lg sm:text-xl font-bold text-blue-300">(GST)</p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white/15 backdrop-blur-md rounded-2xl sm:rounded-3xl p-6 sm:p-8 border border-white/20 hover:bg-white/20 transition-all duration-300 group">

              <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-purple-400 to-pink-500 rounded-xl sm:rounded-2xl flex items-center justify-center mx-auto mb-4 sm:mb-6 group-hover:scale-110 transition-transform duration-300">
                <Monitor className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
              </div>
              <h3 className="text-xl sm:text-2xl font-bold mb-2 sm:mb-3 text-purple-200">Platform</h3>
              <p className="text-base sm:text-lg text-white font-semibold">Zoom Meeting</p>
              <p className="text-lg sm:text-xl font-bold text-purple-300">Link via Email</p>
            </motion.div>
          </div>

          {/* Call to Action */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-center">

            <div className="bg-white/10 backdrop-blur-md rounded-xl sm:rounded-2xl p-6 sm:p-8 border border-white/20 max-w-2xl mx-auto">
              <div className="flex items-center justify-center gap-3 mb-4">
                <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse"></div>
                <span className="text-green-300 font-bold text-sm sm:text-base">LIVE SESSION</span>
                <div className="w-4 h-4 bg-green-400 rounded-full animate-pulse"></div>
              </div>
              <p className="text-base sm:text-lg text-white mb-4 sm:mb-6 leading-relaxed px-2">
                <strong>Interactive Q&A • Live Demonstrations • Hands-on Practice</strong><br />
                Get real-time answers to your ChatGPT questions!
              </p>
              <Button
                onClick={() => setIsModalOpen(true)}
                size="lg"
                className="w-full sm:w-auto bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-black font-bold px-8 sm:px-10 py-3 sm:py-4 text-base sm:text-lg rounded-xl sm:rounded-2xl shadow-2xl hover:shadow-yellow-500/25 transition-all duration-300 transform hover:scale-105">

                <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 mr-2" />
                Secure My Free Seat Now!
              </Button>
              <p className="text-xs sm:text-sm text-yellow-200 mt-3 sm:mt-4 font-semibold px-2">⚡ Only 100 seats available for Free

              </p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* What You'll Master in 60 Minutes (Now displaying agenda in vertical format) */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12 sm:mb-16">
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-4 sm:mb-6">ChatGPT Masterclass Curriculum

            </h2>
            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">6 comprehensive modules designed to give you complete ChatGPT mastery

            </p>
          </div>

          <div className="space-y-6 sm:space-y-8">
            {agenda.map((item, index) =>
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}>

                <Card className="border-l-4 border-blue-500 hover:shadow-xl transition-all duration-300 bg-gradient-to-r from-white to-blue-50">
                  <CardContent className="p-6 sm:p-8">
                    <div className="flex items-start gap-4 sm:gap-6">
                      <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-blue-500 to-purple-500 rounded-xl sm:rounded-2xl flex items-center justify-center flex-shrink-0">
                        {React.createElement(item.icon, { className: "w-6 h-6 sm:w-8 sm:h-8 text-white" })}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-900 mb-3 sm:mb-4">{item.title}</h3>
                        <p className="text-base sm:text-lg text-gray-600 leading-relaxed">{item.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* Trainer Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 -translate-x-1/4 -translate-y-1/4 w-96 h-96 bg-blue-50 rounded-full blur-3xl opacity-70"></div>
        <div className="absolute bottom-0 right-0 translate-x-1/4 translate-y-1/4 w-96 h-96 bg-purple-50 rounded-full blur-3xl opacity-70"></div>

        <div className="max-w-7xl mx-auto relative">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-3 text-base font-medium mb-6 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300">
              <Award className="w-5 h-5 mr-2" />
              Your Expert Instructor
            </Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900">Learn from a Proven Industry Leader</h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img
                src="https://i.imghippo.com/files/tfUo2263Io.png"
                alt="Gaurav Oberoi - Expert AI marketing trainer"
                className="w-full h-auto rounded-2xl shadow-2xl" />

              <div className="absolute -top-4 -right-4 bg-yellow-400 text-gray-900 px-4 py-2 rounded-full font-bold text-sm">
                15+ Years Experience
              </div>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">
                Gaurav Oberoi
              </h3>
              <p className="text-xl text-blue-600 font-semibold mb-6">
                Founder & Lead AI Trainer at Inc Academy
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Trained 9,000+ professionals across the GCC</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Former Google Regional Trainer</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Dubai Tourism consultant for Expo 2020</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">TikTok MENA collaborator</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Active investor & startup advisor</span>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-indigo-100">
                <h4 className="text-lg font-bold text-gray-900 mb-3">Why Learn from Gaurav?</h4>
                <p className="text-gray-600 mb-4">
                  "I've been training professionals for over 15 years, and I've never seen a technology
                  as transformative as AI. In this masterclass, I'll share the exact techniques I use
                  to save 3-4 hours every day using ChatGPT."
                </p>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <span className="text-sm text-gray-500">4.9/5 from 9,000+ students</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Logos Section */}
      <section className="bg-white py-16">
        <div className="mx-auto max-w-5xl px-6 lg:px-8">
          <div className="bg-gray-50 rounded-2xl shadow-xl p-8 sm:p-12">
            <h2 className="text-center text-lg font-semibold text-gray-600 mb-8">

            </h2>
            <div className="mx-auto grid max-w-lg grid-cols-4 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:max-w-none lg:grid-cols-8">
              {clientLogos.map((client, index) =>
              <img
                key={index}
                className="col-span-2 max-h-12 w-full object-contain lg:col-span-1 opacity-70 hover:opacity-100 transition-opacity"
                src={client.src}
                alt={client.alt}
                width="158"
                height="48"
                loading="lazy"
                decoding="async" />

              )}
            </div>
          </div>
        </div>
      </section>

      {/* Who This Is For */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Perfect For Every Professional
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">Whether you're a complete beginner or looking to level up your ChatGPT skills, this masterclass meets you where you are.


            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
            { icon: BrainCircuit, title: "Entrepreneurs", desc: "Automate business processes and scale operations" },
            { icon: PenSquare, title: "Content Creators", desc: "Generate engaging content faster and more efficiently" },
            { icon: BarChart3, title: "Marketers", desc: "Create compelling campaigns and analyze market trends" },
            { icon: Lightbulb, title: "Students & Researchers", desc: "Enhance learning and accelerate research projects" },
            { icon: Users, title: "HR Managers", desc: "Streamline recruitment and employee communications" },
            { icon: Globe, title: "Consultants", desc: "Deliver higher value insights to your clients" },
            { icon: Rocket, title: "Startup Founders", desc: "Build and scale with limited resources" },
            { icon: BookOpen, title: "Educators", desc: "Create lesson plans and educational content" }].
            map((audience, index) =>
            <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-r from-indigo-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <audience.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{audience.title}</h3>
                  <p className="text-gray-600 text-sm">{audience.desc}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md::text-5xl font-bold text-gray-900 mb-6">
              What Professionals Say About Our Training
            </h2>
            <p className="text-xl text-gray-600">
              See how this masterclass has transformed careers and businesses
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) =>
            <Card key={index} className="border-0 shadow-xl bg-gradient-to-br from-white to-blue-50">
                <CardContent className="p-8">
                  <div className="flex items-center gap-1 mb-4">
                    {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <p className="text-slate-700 mb-4 italic text-lg leading-relaxed">
                    "{testimonial.quote}"
                  </p>
                  <p className="font-bold text-slate-900">{testimonial.author}</p>
                  <p className="text-sm text-slate-600">{testimonial.role}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-gray-600">
              Everything you need to know about the ChatGPT Masterclass
            </p>
          </div>

          <div className="space-y-4">
            {faqData.map((faq, index) =>
            <Card key={index} className="overflow-hidden">
                <button
                className="w-full text-left p-6 hover:bg-gray-50 transition-colors"
                onClick={() => setOpenFaq(openFaq === index ? null : index)}>

                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-gray-900 pr-4">{faq.q}</h3>
                    <div className="flex-shrink-0">
                      {openFaq === index ?
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-blue-600 font-bold">−</span>
                        </div> :

                    <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                          <span className="text-gray-600 font-bold">+</span>
                        </div>
                    }
                    </div>
                  </div>
                </button>
                {openFaq === index &&
              <div className="px-6 pb-6">
                    <p className="text-gray-600 leading-relaxed">{faq.a}</p>
                  </div>
              }
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Urgency Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-orange-500 to-red-500 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-8">
            ⚡ Don't Miss Out - Limited Seats Available!
          </h2>
          <p className="text-xl mb-8 leading-relaxed">
            This free masterclass fills up fast. Reserve your seat now and join the AI revolution.
          </p>
          <div className="bg-white/20 backdrop-blur-sm rounded-3xl p-8 mb-8">
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-3xl font-bold text-yellow-300">60 Min</div>
                <div className="text-orange-100">Intensive Training</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-green-300">100%</div>
                <div className="text-orange-100">Free Forever</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-pink-300">Live</div>
                <div className="text-orange-100">Interactive Session</div>
              </div>
            </div>
          </div>
          <Button
            onClick={() => setIsModalOpen(true)}
            size="lg"
            className="bg-white text-red-600 hover:bg-gray-100 px-12 py-4 text-xl font-bold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300">

            <Play className="w-6 h-6 mr-2" />
            Register Now - It's FREE!
            <ArrowRight className="w-6 h-6 ml-2" />
          </Button>
        </div>
      </section>
    </div>);

}
