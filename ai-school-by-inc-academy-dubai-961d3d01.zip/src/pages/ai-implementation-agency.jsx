
import React, { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Rocket,
  Target,
  Zap,
  BarChart3,
  Users,
  CheckCircle2,
  ArrowRight,
  Brain,
  TrendingUp,
  MessageSquare,
  PenTool,
  Award,
  Megaphone,
  ShoppingBag,
  Package,
  Building2,
  Building,
  Home,
  Banknote,
  Bot,
  Sparkles,
  Factory,
  HeartPulse,
  BrainCircuit,
  Infinity,
  Clock,
  DollarSign,
  Phone,
  Wrench // Added Wrench icon
} from "lucide-react";
import { motion } from "framer-motion";
import InquiryFormModal from "@/components/common/InquiryFormModal";
// Removed PageSection import as it's being replaced with direct section tags
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

const clientLogos = [
  { src: "https://i.imghippo.com/files/AIj7022XwI.png", alt: "Google" },
  { src: "https://i.imghippo.com/files/BtVJ7689eU.png", alt: "TikTok" },
  { src: "https://i.imghippo.com/files/zETQ9249BY.png", alt: "Dubai Tourism" },
  { src: "https://i.imghippo.com/files/LjWL1133fc.png", alt: "Emirates" },
  { src: "https://i.imghippo.com/files/RymB7570vQ.png", alt: "Alshaya" },
  { src: "https://i.imghippo.com/files/IPE5684MnM.png", alt: "Unilever" },
  { src: "https://i.imghippo.com/files/QUIK6243XI.png", alt: "Etihad" },
  { src: "https://i.imghippo.com/files/CBg5407ZEg.png", alt: "Harvard Business School" }
];

const services = [
{
  icon: Target,
  title: "AI-Powered Funnel Strategy",
  description: "Complete funnel optimization using Generative AI insights and automated testing frameworks that adapt in real-time for AI for executives.",
  features: ["Conversion optimization", "A/B testing automation", "Personalization at scale", "Predictive performance tracking"]
},
{
  icon: PenTool,
  title: "Content Automation Agents",
  description: "Deploy autonomous AI generalist agents that create, optimize, and distribute high-quality content across all your AI for growth marketing channels.",
  features: ["Blog & article generation", "Social media content creation", "Automated email sequences", "Video scriptwriting"]
},
{
  icon: BarChart3,
  title: "Performance Marketing + AI Analytics",
  description: "Data-driven campaigns powered by predictive analytics, automated budget allocation, and creative optimization using AI workflow automation.",
  features: ["Predictive audience targeting", "Automated budget optimization", "AI-driven creative testing", "Performance forecasting"]
},
{
  icon: Brain,
  title: "Custom GPT & AI Agent Development",
  description: "We build tailored AI for business leaders assistants for ads, emails, outreach, and complex customer communication workflows.",
  features: ["Ad copy generation agents", "Automated email responders", "Lead qualification bots", "Customer support assistants"]
},
{
  icon: Users,
  title: "AI-Personalized Retargeting",
  description: "Advanced retargeting campaigns with AI automation-driven personalization and dynamic creative that adapts to user behavior for AI for entrepreneurs.",
  features: ["Dynamic ad creative generation", "Behavioral targeting funnels", "Cross-platform campaigns", "Automated conversion optimization"]
},
{
  icon: TrendingUp,
  title: "Growth Acceleration Programs",
  description: "Comprehensive growth programs combining our proprietary AI for productivity tools with proven marketing strategies for rapid scaling.",
  features: ["AI-driven growth strategy", "Automated channel optimization", "Scalable AI frameworks", "Real-time performance monitoring"]
}];


const differentiators = [
{
  icon: Users,
  title: "Built by Marketers, not Engineers",
  description: "Our AI for CMOs team understands marketing challenges from experience, not theory"
},
{
  icon: Award,
  title: "Deep Expertise in Growth + AI",
  description: "15+ years of growth hacking combined with cutting-edge AI for corporate training implementation"
},
{
  icon: Zap,
  title: "Speed to Deployment",
  description: "Days, not months. We get your AI automation systems up and running fast"
}];


const agentData = {
  "Marketing": {
    icon: Megaphone,
    color: "from-purple-500 to-pink-500",
    bgColor: "bg-gradient-to-r from-purple-50 to-pink-50",
    image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?q=80&w=2939&auto=format&fit=crop",
    agents: [
    {
      title: "Campaign Optimizer Agent",
      description: "Adjusts budgets, creatives, and audience targeting in real-time across platforms using AI for growth marketing.",
      icon: Target
    },
    {
      title: "Customer Persona Generator",
      description: "Builds dynamic personas using CRM, web analytics, and sales data with AI for managers insights.",
      icon: Users
    },
    {
      title: "AI Creative Brief Assistant",
      description: "Converts product or promo goals into AI-ready creative briefs for Generative AI content or ad generation.",
      icon: Sparkles
    },
    {
      title: "Performance Insights Bot",
      description: "Delivers daily summaries of campaign KPIs and trends with executive-level commentary for AI for executives.",
      icon: TrendingUp
    }]
  },
  "E-Commerce & D2C": {
    icon: ShoppingBag,
    color: "from-green-500 to-emerald-500",
    bgColor: "bg-gradient-to-r from-green-50 to-emerald-50",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?q=80&w=2940&auto=format&fit=crop",
    agents: [
    {
      title: "Product Copywriter Agent",
      description: "Writes SEO-friendly product titles, benefits, and specs in brand tone using AI for entrepreneurs automation.",
      icon: Bot
    },
    {
      title: "AI Visual Merchandiser",
      description: "Optimizes product placement on web/app based on behavioral data and AI workflow automation insights.",
      icon: TrendingUp
    },
    {
      title: "Cart Abandonment Rescuer Bot",
      description: "Sends smart, personalized nudges to recover lost sales via WhatsApp/email using AI for productivity.",
      icon: Zap
    },
    {
      title: "Review Summarizer Bot",
      description: "Analyzes customer feedback and auto-generates sentiment-based product insights with AI generalist capabilities.",
      icon: Users
    }]
  },
  "Healthcare": {
    icon: HeartPulse,
    color: "from-red-500 to-orange-500",
    bgColor: "bg-gradient-to-r from-red-50 to-orange-50",
    image: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?q=80&w=2831&auto=format&fit=crop",
    agents: [
    {
      title: "Patient Triage Bot",
      description: "Provides initial assessment and directs patients to the appropriate level of care, reducing wait times using AI automation.",
      icon: Users
    },
    {
      title: "Diagnostic Imaging Analyst",
      description: "Assists radiologists by highlighting potential anomalies in X-rays, MRIs, and CT scans with Generative AI.",
      icon: Brain
    },
    {
      title: "Personalized Treatment Planner",
      description: "Generates customized treatment plan suggestions based on patient data and medical guidelines for AI for managers.",
      icon: PenTool
    },
    {
      title: "Clinical Trial Recruitment Agent",
      description: "Scans patient records to identify and contact eligible candidates for clinical trials automatically using AI for consultants.",
      icon: Zap
    }]
  },
  "B2B & SaaS": {
    icon: Building2,
    color: "from-blue-500 to-indigo-500",
    bgColor: "bg-gradient-to-r from-blue-50 to-indigo-50",
    image: "https://images.unsplash.com/photo-1664575602554-2087b04935a5?q=80&w=2787&auto=format&fit=crop",
    agents: [
    {
      title: "Outbound Sales Agent",
      description: "Crafts hyper-personalized cold emails using ICP data and previous interactions with AI for business leaders intelligence.",
      icon: Target
    },
    {
      title: "Proposal Generator Agent",
      description: "Auto-creates proposals, decks, and pricing sheets customized to client needs using AI workflow automation.",
      icon: Bot
    },
    {
      title: "Client Health Monitor",
      description: "Analyzes usage data and support tickets to identify churn risks with AI for productivity insights.",
      icon: TrendingUp
    },
    {
      title: "B2B Growth Dashboard Bot",
      description: "Combines CRM, ad, and revenue data into a single, daily snapshot for leadership using Generative AI analytics.",
      icon: Sparkles
    }]
  },
  "Real Estate": {
    icon: Home,
    color: "from-cyan-500 to-teal-500",
    bgColor: "bg-gradient-to-r from-cyan-50 to-teal-50",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?q=80&w=2873&auto=format&fit=crop",
    agents: [
    {
      title: "Listing Intelligence Bot",
      description: "Generates SEO listings, ads, and social content for properties using AI for entrepreneurs automation.",
      icon: Bot
    },
    {
      title: "Lead Nurture Bot",
      description: "Engages leads with local property insights, investment guides, and site visit bookings via AI for managers.",
      icon: Users
    },
    {
      title: "ROI Projection Agent",
      description: "Calculates long-term yield, IRR, and price appreciation based on location and property type using AI automation.",
      icon: TrendingUp
    },
    {
      title: "Developer Dashboard Agent",
      description: "Summarizes sales funnel, inquiries, and top-performing agents weekly with Generative AI insights.",
      icon: Sparkles
    }]
  },
  "Finance & Banking": {
    icon: Banknote,
    color: "from-emerald-500 to-green-600",
    bgColor: "bg-gradient-to-r from-emerald-50 to-green-50",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2940&auto=format&fit=crop",
    agents: [
    {
      title: "Credit Risk Analyzer",
      description: "Flags anomalies and potential risk factors in loan applications using historical repayment models with AI for business leaders.",
      icon: Target
    },
    {
      title: "Portfolio Summary Agent",
      description: "Prepares visual performance summaries for clients and advisors using AI for productivity automation.",
      icon: TrendingUp
    },
    {
      title: "AML Compliance Assistant",
      description: "Detects suspicious transaction patterns and compliance breaches using AI workflow automation.",
      icon: Zap
    },
    {
      title: "Chatbot Banker",
      description: "Answers customer FAQs, tracks spending patterns, and nudges users to save/invest with AI generalist capabilities.",
      icon: Bot
    }]
  }
};

function AgentShowcase() {
  const [activeTab, setActiveTab] = useState("Marketing");

  return (
    <div className="w-full">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-3 lg:grid-cols-6 h-auto mb-8 bg-gray-100 rounded-2xl p-2">
          {Object.keys(agentData).map((industry) => {
            const IndustryIcon = agentData[industry].icon;
            return (
              <TabsTrigger
                key={industry}
                value={industry}
                className="text-xs md:text-sm font-medium px-2 py-3 rounded-xl data-[state=active]:bg-white data-[state=active]:shadow-sm transition-all duration-300">

                <div className="flex flex-col items-center gap-2">
                  <IndustryIcon className="w-4 h-4 md:w-5 md:h-5" />
                  <span className="hidden sm:block">{industry}</span>
                  <span className="sm:hidden">{industry.split(' ')[0]}</span>
                </div>
              </TabsTrigger>);
          })}
        </TabsList>

        {Object.entries(agentData).map(([industry, data]) => {
          const DataIcon = data.icon;
          return (
            <TabsContent key={industry} value={industry} className="mt-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className={`rounded-3xl p-6 md:p-8 mb-8 ${data.bgColor} relative overflow-hidden`}>
                
                {/* Background Image */}
                <div className="absolute inset-0 opacity-20">
                  <img 
                    src={data.image}
                    alt={`${industry} AI transformation background`}
                    className="w-full h-full object-cover"
                    loading="lazy"
                    decoding="async"
                  />
                  <div className="absolute inset-0 bg-gradient-to-r from-white/80 to-transparent"></div>
                </div>
                
                {/* Content Overlay */}
                <div className="relative z-10">
                  <div className="flex items-center gap-4 mb-4">
                    <div className={`w-16 h-16 bg-gradient-to-r ${data.color} rounded-2xl flex items-center justify-center shadow-lg`}>
                      <DataIcon className="w-8 h-8 text-white" />
                    </div>
                    <div>
                      <h3 className="text-2xl md:text-3xl font-bold text-gray-900">{industry}</h3>
                      <p className="text-gray-600">AI-Powered Solutions</p>
                    </div>
                  </div>
                </div>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {data.agents.map((agent, index) => {
                  const AgentIcon = agent.icon;
                  return (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}>

                      <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 group h-full bg-white rounded-2xl overflow-hidden">
                        <CardHeader className="pb-4">
                          <div className="flex items-start gap-4">
                            <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-blue-500 to-green-500 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform duration-300">
                              <AgentIcon className="w-6 h-6 text-white" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <CardTitle className="text-lg font-bold text-gray-900 leading-tight group-hover:text-purple-600 transition-colors">
                                {agent.title}
                              </CardTitle>
                            </div>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-gray-600 leading-relaxed text-sm md:text-base">
                            {agent.description}
                          </p>
                          <div className="mt-4 pt-4 border-t border-gray-100">
                            <Badge variant="secondary" className="text-xs font-medium">
                              AI Powered
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>);
                })}
              </div>
            </TabsContent>);
        })}
      </Tabs>
    </div>);
}

export default function AIImplementationAgency() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState({ title: "", subtitle: "" });
  const videoRef = useRef(null);

  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "AI Implementation Agency | Automation & Agents | UAE";
    const description = "Build and deploy AI copilots, agents, and automated workflows. CRM, marketing, analytics, RAG, and integrations with change management and post-launch enablement.";
    const keywords = "AI implementation UAE, AI automation Dubai, AI agents UAE, AI integration Dubai, RAG deployment, AI copilots GCC, marketing automation AI, analytics AI UAE";
    const imageUrl = "https://i.imghippo.com/files/tfUo2263Io.png";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('name', 'keywords', keywords);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);

    // Schema.org structured data
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "AI Implementation Agency",
      "description": description,
      "provider": {
        "@type": "Organization",
        "name": "Inc Academy",
        "url": "https://ai.inc.academy"
      },
      "serviceType": "Technology Implementation",
      "areaServed": ["UAE", "Dubai", "GCC"]
    });
    document.head.appendChild(script);
  }, []);

  const openModal = () => {
    setModalContent({
      title: "Book an AI Implementation Call",
      subtitle: "Let's discuss how our AI agency can build solutions for your business."
    });
    setIsModalOpen(true);
  };
  
  const scrollToShowcase = () => {
    const pricingSection = document.getElementById('pricing-section');
    if (pricingSection) {
      pricingSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <InquiryFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={modalContent.title}
        subtitle={modalContent.subtitle} />


      <div className="min-h-screen bg-white">
        {/* Hero Section */}
        <section className="relative bg-gray-900 text-white overflow-hidden min-h-screen flex items-center">
          {/* Background Video */}
          <video
            ref={videoRef}
            autoPlay
            loop
            muted
            playsInline
            preload="metadata"
            className="absolute z-0 w-auto min-w-full min-h-full max-w-none left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 object-cover"
          >
            <source src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a5ce8dd3c_pexel.mp4" type="video/mp4" />
          </video>
          {/* Overlays */}
          <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-blue-900 to-black opacity-70"></div>
          <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
          
          {/* Content (with padding) */}
          <div className="relative z-10 max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center py-20 md:py-32 px-4 sm:px-6 lg:px-8">
            
            {/* Left Column: Text Content */}
            <div className="text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="mb-6"
              >
                <Badge className="px-6 py-3 text-base font-semibold bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-full shadow-lg">
                  <Wrench className="w-5 h-5 mr-3" />
                  Done-For-You AI Solutions
                </Badge>
              </motion.div>
              
              <motion.h1
                initial={{ opacity: 0, y: 40 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="text-4xl sm:text-5xl md:text-6xl font-bold mb-8 leading-tight"
              >
                <span className="text-white block">AI Implementation</span>
                <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent block mt-2">
                  Agency
                </span>
              </motion.h1>
              
              <motion.p
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.6 }}
                className="text-xl text-gray-300 mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed font-light"
              >
                From AI agents to automated workflows, we design, build, and deploy custom AI solutions that integrate seamlessly into your business.
              </motion.p>
              
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start"
              >
                <Button 
                  size="lg" 
                  className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg group transform hover:scale-105 transition-transform" 
                  onClick={openModal}
                >
                  Get a Custom Quote
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </motion.div>
            </div>

            {/* Right Column: Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.0, delay: 0.4, type: "spring", stiffness: 50 }}
              className="relative hidden lg:block"
            >
              <div className="w-full aspect-square bg-white/5 rounded-3xl shadow-2xl border border-white/10 p-4">
                <img
                  src="https://i.imghippo.com/files/rMT3873HHc.jpeg"
                  alt="AI agency implementing automation solutions for business in Dubai UAE"
                  className="w-full h-full object-cover rounded-2xl"
                  loading="lazy"
                  decoding="async"
                />
              </div>
            </motion.div>
          </div>
        </section>

        {/* Removed the separate Video Section component here */}


        {/* Enhanced Client Logos Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-gray-50 via-blue-50/30 to-purple-50/30 relative overflow-hidden">
          {/* Background decorative elements */}
          <div className="absolute top-10 left-10 w-32 h-32 bg-blue-200/20 rounded-full blur-2xl animate-pulse"></div>
          <div className="absolute bottom-10 right-10 w-40 h-40 bg-purple-200/20 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '2s' }}></div>
          
          <div className="relative max-w-7xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.8 }}
              className="mb-12"
            >
              <Badge className="px-8 py-4 text-lg font-bold bg-gradient-to-r from-blue-100 to-purple-100 text-transparent bg-clip-text border-2 border-blue-200/50 backdrop-blur-sm shadow-lg mb-8 rounded-full hover:shadow-xl transition-all duration-300">
                <Award className="w-6 h-6 mr-3 text-blue-600" />
                <span className="text-gray-700">Trusted by Industry Leaders</span>
              </Badge>
              
              <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold text-gray-900 mb-4">
                Powering Innovation for
                <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent block md:inline md:ml-3">
                  Global Brands
                </span>
              </h3>
              
              <p className="text-lg text-gray-600 max-w-2xl mx-auto leading-relaxed">
                From Fortune 500 companies to innovative startups, leading organizations trust us to implement AI solutions that drive real business transformation.
              </p>
            </motion.div>
            
            {/* Enhanced Logo Grid */}
            <motion.div
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="bg-white/80 backdrop-blur-md rounded-3xl shadow-2xl border border-white/50 p-8 md:p-12"
            >
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-8 md:gap-12 justify-items-center items-center">
                {clientLogos.map((logo, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true, amount: 0.5 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    className="group cursor-pointer transform hover:scale-110 transition-all duration-300"
                  >
                    <div className="bg-white rounded-2xl p-4 shadow-lg group-hover:shadow-xl transition-shadow duration-300 border border-gray-100 group-hover:border-blue-200">
                      <img
                        src={logo.src}
                        alt={`${logo.alt} - AI implementation client`}
                        className="h-10 md:h-12 w-auto mx-auto object-contain filter grayscale group-hover:grayscale-0 transition-all duration-300"
                        loading="lazy"
                        decoding="async"
                      />
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
            
            {/* Stats Row */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.5 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center"
            >
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/40">
                <div className="text-3xl font-bold text-blue-600 mb-2">300+</div>
                <div className="text-gray-600 font-medium">Brands Transformed</div>
              </div>
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/40">
                <div className="text-3xl font-bold text-green-600 mb-2">50+</div>
                <div className="text-gray-600 font-medium">Countries Served</div>
              </div>
              <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/40">
                <div className="text-3xl font-bold text-purple-600 mb-2">98%</div>
                <div className="text-gray-600 font-medium">Client Satisfaction</div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Section Divider */}
        <div className="h-px bg-gradient-to-r from-transparent via-gray-200 to-transparent"></div>

        {/* Services Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-blue-50 text-blue-700 border-0 mb-8 hover:bg-blue-700 hover:text-white transition-all duration-300">
                <Target className="w-5 h-5 mr-2" />
                Our Services
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Complete AI Implementation
                <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Solutions</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                From AI strategy course development to execution, we provide end-to-end AI automation-powered solutions
                that scale your business efficiently
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {services.map((service, index) =>
              <Card key={index} className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 group bg-white p-2">
                  <div className="bg-gray-50 rounded-2xl p-6 h-full">
                    <CardHeader className="pb-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                        <service.icon className="w-8 h-8 text-white" />
                      </div>
                      <CardTitle className="text-xl font-bold text-gray-900 mb-4 group-hover:text-green-600 transition-colors">
                        {service.title}
                      </CardTitle>
                      <p className="text-gray-600 leading-relaxed mb-6">
                        {service.description}
                      </p>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        {service.features.map((feature, featureIndex) =>
                      <div key={featureIndex} className="flex items-center gap-3">
                            <CheckCircle2 className="w-4 h-4 text-green-600 flex-shrink-0" />
                            <span className="text-gray-700 text-sm">{feature}</span>
                          </div>
                      )}
                      </div>
                    </CardContent>
                  </div>
                </Card>
              )}
            </div>
          </div>
        </section>

        {/* AI Disruption Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-red-50 text-red-600 border-0 mb-8 hover:bg-red-600 hover:text-white transition-all duration-300">
                <Zap className="w-5 h-5 mr-2" />
                Industry Revolution
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                AI is Disrupting
                <span className="bg-gradient-to-r from-red-600 to-orange-500 bg-clip-text text-transparent block mt-2">
                  Every Industry
                </span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                From healthcare to finance, retail to manufacturing—no sector is immune to Generative AI transformation.
                The companies that adapt with AI for business leaders frameworks will dominate their markets.
              </p>
            </div>

            {/* Main Content Grid */}
            <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
              {/* Left Column - Hero Image */}
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="relative order-2 lg:order-1">

                <div className="relative z-10">
                  <div className="aspect-[4/3] bg-gradient-to-br from-blue-100 to-green-100 rounded-3xl shadow-2xl overflow-hidden ring-4 ring-white/50">
                    <img
                      src="https://i.imghippo.com/files/OtZg9202lFM.jpeg" // Updated image URL
                      alt="AI robots and business analysts working with data visualization in modern Dubai UAE office, representing AI transformation"
                      className="w-full h-full object-cover"
                      loading="lazy"
                      decoding="async"
                    />

                  </div>
                </div>
                {/* Background decorative elements */}
                <div className="absolute top-8 -right-8 w-24 h-24 md:w-32 md:h-32 bg-blue-200/60 rounded-full blur-3xl animate-pulse"></div>
                <div className="absolute -bottom-8 -left-8 w-32 h-32 md:w-40 md:h-40 bg-green-200/60 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
              </motion.div>

              {/* Right Column - Content */}
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.8 }}
                className="order-1 lg:order-2">

                <h3 className="text-3xl font-bold text-gray-900 mb-6">Companies Using AI are Already Winning</h3>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">40% Faster Decision Making</h4>
                      <p className="text-gray-600">AI workflow automation-powered analytics enable real-time insights and instant strategic adjustments</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-emerald-500 rounded-xl flex items-center justify-center flex-shrink-0">
                      <DollarSign className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">60% Cost Reduction</h4>
                      <p className="text-gray-600">AI automation eliminates manual processes and optimizes resource allocation</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-4">
                    <div className="w-12 h-12 bg-gradient-to-r from-red-500 to-red-600 rounded-xl flex items-center justify-center flex-shrink-0">
                      <Users className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="text-lg font-semibold text-gray-900 mb-2">3x Better Customer Experience</h4>
                      <p className="text-gray-600">Personalized interactions and 24/7 AI support create unmatched customer satisfaction</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>

            {/* Industry Cards Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
              {
                icon: ShoppingBag,
                title: "E-commerce",
                desc: "Hyper-personalized shopping experiences and predictive inventory with AI for entrepreneurs.",
                image: "https://i.imghippo.com/files/aq7784oF.jpg",
                color: "from-blue-500 to-blue-600"
              },
              {
                icon: HeartPulse,
                title: "Healthcare",
                desc: "Accelerated drug discovery and predictive patient diagnostics using AI for productivity.",
                image: "https://i.imghippo.com/files/nku7509uow.jpg",
                color: "from-green-500 to-green-600"
              },
              {
                icon: Banknote,
                title: "Finance",
                desc: "Algorithmic trading, fraud detection, and automated risk assessment with AI for managers.",
                image: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?q=80&w=2940&auto=format&fit=crop",
                color: "from-gray-700 to-gray-900"
              },
              {
                icon: Factory,
                title: "Manufacturing",
                desc: "Predictive maintenance, quality control, and supply chain optimization using Generative AI.",
                image: "https://images.unsplash.com/photo-1567789884554-0b844b597180?q=80&w=2940&auto=format&fit=crop",
                color: "from-blue-600 to-green-600"
              }].
              map((item, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}>

                  <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-300 group text-center h-full rounded-2xl overflow-hidden">
                    <div className="relative">
                      <div className="aspect-[4/3] overflow-hidden">
                        <img
                        src={item.image}
                        alt={`${item.title} industry AI transformation in Dubai UAE - modern technology and automation solutions`}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                        loading="lazy"
                        decoding="async"
                        />

                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                      </div>
                      <div className={`absolute top-4 left-4 w-12 h-12 bg-gradient-to-r ${item.color} rounded-xl flex items-center justify-center shadow-lg`}>
                        <item.icon className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">{item.title}</h3>
                      <p className="text-gray-600 leading-relaxed text-sm">{item.desc}</p>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </div>
          </div>
        </section>

        {/* Why Us Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-blue-50 text-blue-700 border-0 mb-8 rounded-full shadow-sm hover:bg-blue-700 hover:text-white transition-all duration-300">
                <Users className="w-5 h-5 mr-2" />
                Why Choose Us
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Built for
                <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent"> Results</span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                We're not just another agency. We're AI for consultants experts who leverage Generative AI to
                deliver exceptional results for our clients.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {differentiators.map((item, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.3 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}>

                  <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-300 group bg-white/80 backdrop-blur-sm h-full rounded-3xl overflow-hidden">
                    <div className="bg-gray-50 rounded-3xl p-8 h-full">
                      <CardContent className="p-0 text-center h-full flex flex-col">
                        <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg">
                          <item.icon className="w-8 h-8 text-white" />
                        </div>
                        <h3 className="text-xl font-bold text-gray-900 mb-4 group-hover:text-blue-600 transition-colors">
                          {item.title}
                        </h3>
                        <p className="text-gray-600 leading-relaxed flex-grow">{item.description}</p>

                        <div className="mt-6 pt-4 border-t border-gray-100">
                          <div className="w-12 h-1 bg-gradient-to-r from-blue-400 to-green-400 rounded-full mx-auto opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                        </div>
                      </CardContent>
                    </div>
                  </Card>
                </motion.div>
              )}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="mt-16 text-center">

              <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 md:p-12 shadow-xl border border-white/40 max-w-4xl mx-auto">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Award className="w-6 h-6 text-white" />
                </div>
                <blockquote className="text-lg md:text-xl text-gray-700 italic mb-6 leading-relaxed">
                  "The combination of marketing expertise and AI implementation is what sets this team apart. They don't just understand the technology—they understand how to make it work for real business growth."
                </blockquote>
                <div className="text-sm text-gray-500 font-medium">
                  Based on client feedback from 300+ brand transformations
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Explore Industry Solutions - Enhanced */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 to-indigo-50">
          <div className="max-w-7xl mx-auto">
            <div className="bg-white/80 backdrop-blur-lg rounded-3xl p-6 sm:p-8 md:p-12 shadow-2xl border border-white/60">
              <div className="text-center mb-12 md:mb-16">
                <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-indigo-100 text-indigo-700 border border-indigo-200 mb-6 md:mb-8">
                  <Building className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                  Industry-Specific Solutions
                </Badge>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-4 md:mb-6">
                  Explore Industry Solutions
                </h2>
                <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
                  Tailored AI implementations designed for your industry's unique challenges and opportunities.
                </p>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6 lg:gap-8">
                {[
                  "Healthcare", "Finance & Banking", "Real Estate", "E-commerce",
                  "Education", "Manufacturing", "Legal Services", "Hospitality",
                  "Marketing Agencies", "Consulting Firms", "Tech Startups", "Retail"
                ].map((industry, index) => (
                  <Card key={index} className="group transition-all duration-300 bg-white border border-gray-200 shadow-lg hover:shadow-2xl hover:-translate-y-1 rounded-2xl">
                    <CardContent className="p-4 sm:p-5 text-center">
                      <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-xl flex items-center justify-center mx-auto mb-3 sm:mb-4 group-hover:scale-110 transition-transform duration-300">
                        <Building className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
                      </div>
                      <h3 className="text-sm sm:text-base font-bold text-gray-900 leading-tight">
                        {industry}
                      </h3>
                    </CardContent>
                  </Card>
                ))}
              </div>

              <div className="text-center mt-8 md:mt-12">
                <p className="text-base md:text-lg text-gray-600 mb-6 md:mb-8 leading-relaxed">
                  Don't see your industry? We create custom solutions for any sector.
                </p>
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white px-6 md:px-8 py-3 md:py-4 text-base md:text-lg font-semibold rounded-xl shadow-lg group"
                  onClick={openModal}
                >
                  Discuss Your Industry Needs
                  <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Custom AI Agents Section - Enhanced */}
        <section id="pricing-section" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-16">
              <Badge className="px-6 py-3 text-base font-semibold bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 border border-purple-200 mb-8 rounded-full shadow-sm hover:bg-purple-700 hover:text-white hover:border-purple-700 transition-all duration-300">
                <Brain className="w-5 h-5 mr-2" />
                AI-Powered Industry Solutions
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6">
                Custom AI Agents for
                <span className="bg-gradient-to-r from-blue-600 to-green-600 bg-clip-text text-transparent block md:inline md:ml-3">
                  Every Industry
                </span>
              </h2>
              <p className="text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                Discover powerful, industry-specific AI generalist agents designed to automate workflows,
                boost AI for productivity, and transform business operations across sectors.
              </p>
            </div>

            {/* Hero Image Section */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}
              className="relative mb-16">

              <div className="aspect-[16/9] bg-gradient-to-br from-blue-100 to-purple-100 rounded-3xl shadow-2xl overflow-hidden ring-4 ring-white/50 relative">
                <img
                  src="https://images.unsplash.com/photo-1677442136019-21780ecad995?q=80&w=2832&auto=format&fit=crop" // Updated image URL
                  alt="AI transformation across all sectors - diverse industries embracing artificial intelligence automation"
                  className="w-full h-full object-cover"
                  loading="lazy"
                  decoding="async"
                />

                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>

                {/* Floating industry icons */}
                <div className="absolute top-8 left-8 w-16 h-16 bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center shadow-xl animate-float">
                  <Megaphone className="w-8 h-8 text-white" />
                </div>
                <div className="absolute top-8 right-8 w-16 h-16 bg-gradient-to-r from-green-600 to-green-700 rounded-2xl flex items-center justify-center shadow-xl animate-float" style={{ animationDelay: '1s' }}>
                  <ShoppingBag className="w-8 h-8 text-white" />
                </div>
                <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 w-16 h-16 bg-gradient-to-r from-purple-600 to-purple-700 rounded-2xl flex items-center justify-center shadow-xl animate-float" style={{ animationDelay: '2s' }}>
                  <Building2 className="w-8 h-8 text-white" />
                </div>

                {/* Central content overlay */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center text-white max-w-2xl px-8">
                    <h3 className="text-3xl md:text-4xl font-bold mb-4">AI Transformation Across All Sectors</h3>
                    <p className="text-lg text-white/90">From healthcare to finance, our AI for executives agents are revolutionizing how businesses operate and compete.</p>
                  </div>
                </div>
              </div>

              {/* Decorative background elements */}
              <div className="absolute top-12 -left-12 w-32 h-32 bg-blue-200/40 rounded-full blur-3xl"></div>
              <div className="absolute -bottom-12 -right-12 w-40 h-40 bg-purple-200/40 rounded-full blur-3xl"></div>
            </motion.div>

            <div className="relative">
              {/* Background decorative elements - Enhanced */}
              <div className="absolute -top-12 -left-12 w-80 h-80 bg-gradient-to-br from-blue-300/40 to-purple-300/40 rounded-full blur-3xl animate-pulse"></div>
              <div className="absolute -bottom-12 -right-12 w-96 h-96 bg-gradient-to-br from-green-300/40 to-blue-300/40 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '3s' }}></div>
              <div className="absolute top-1/2 left-1/4 w-64 h-64 bg-gradient-to-br from-pink-200/30 to-purple-200/30 rounded-full blur-2xl animate-float"></div>

              {/* Main container with enhanced design */}
              <div className="relative bg-gradient-to-br from-white/90 via-blue-50/80 to-purple-50/90 backdrop-blur-xl rounded-3xl p-8 md:p-12 shadow-2xl border-2 border-white/70 ring-2 ring-purple-200/30 overflow-hidden transform hover:scale-[1.01] transition-transform duration-500">
                {/* Top gradient accent - Enhanced */}
                <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-blue-500 via-purple-500 via-pink-500 to-green-500 rounded-t-3xl"></div>

                {/* Subtle pattern overlay - Enhanced */}
                <div className="absolute inset-0 bg-grid-pattern opacity-[0.03] pointer-events-none"></div>
                
                {/* Floating orbs for visual interest */}
                <div className="absolute top-8 right-8 w-16 h-16 bg-gradient-to-br from-blue-200/50 to-purple-200/50 rounded-full blur-xl animate-float"></div>
                <div className="absolute bottom-8 left-8 w-20 h-20 bg-gradient-to-br from-green-200/50 to-blue-200/50 rounded-full blur-xl animate-float" style={{ animationDelay: '2s' }}></div>

                {/* Content wrapper - Enhanced */}
                <div className="relative z-10">
                  {/* Section header inside container - Enhanced */}
                  <div className="text-center mb-12">
                    <div className="inline-flex items-center gap-3 bg-gradient-to-r from-purple-100/80 to-blue-100/80 backdrop-blur-sm px-8 py-4 rounded-2xl border-2 border-purple-200/70 mb-6 shadow-lg hover:shadow-xl transition-shadow duration-300">
                      <div className="w-10 h-10 bg-gradient-to-r from-purple-500 to-blue-500 rounded-xl flex items-center justify-center shadow-md">
                        <Brain className="w-5 h-5 text-white" />
                      </div>
                      <span className="text-purple-700 font-bold text-lg">Explore Industry Solutions</span>
                    </div>
                    
                    <p className="text-gray-600 max-w-2xl mx-auto text-lg leading-relaxed">
                      Select an industry below to discover specialized AI automation agents tailored for your business sector
                    </p>
                  </div>

                  <AgentShowcase />
                </div>

                {/* Enhanced decorative elements */}
                <div className="absolute bottom-6 left-6 w-24 h-24 bg-gradient-to-br from-blue-100/60 to-transparent rounded-full blur-xl animate-pulse"></div>
                <div className="absolute bottom-6 right-6 w-28 h-28 bg-gradient-to-br from-green-100/60 to-transparent rounded-full blur-xl animate-pulse" style={{ animationDelay: '1s' }}></div>
                <div className="absolute top-6 left-1/2 transform -translate-x-1/2 w-32 h-32 bg-gradient-to-br from-purple-100/40 to-transparent rounded-full blur-2xl animate-float"></div>
              </div>
            </div>

            {/* Call-to-action Box */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="mt-16">

              <div className="bg-gradient-to-r from-blue-600 to-green-600 rounded-3xl p-8 md:p-12 text-white text-center shadow-2xl relative overflow-hidden">
                {/* Background decorative elements */}
                <div className="absolute top-8 right-8 w-24 h-24 bg-white/10 rounded-full blur-2xl"></div>
                <div className="absolute bottom-8 left-8 w-32 h-32 bg-white/10 rounded-full blur-3xl"></div>

                <div className="relative z-10">
                  <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-4 md:mb-6">
                    Ready to Build Your Custom AI Agent?
                  </h3>
                  <p className="text-lg md:text-xl text-blue-100 mb-6 md:mb-8 max-w-3xl mx-auto">
                    Let our AI for business leaders experts create industry-specific AI workflow automation solutions tailored to your business needs and workflows.
                  </p>
                  <Button
                    size="lg"
                    className="bg-white text-blue-600 hover:bg-gray-100 hover:text-blue-700 px-8 md:px-12 py-3 md:py-4 text-base md:text-lg font-bold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group transform hover:scale-105"
                    onClick={openModal}>

                    Start Your AI Transformation
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Enhanced Productivity Section */}
        <section className="bg-gradient-to-br from-teal-50/40 via-blue-50/40 to-white py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}>

              <Badge className="px-6 py-3 text-base font-semibold bg-teal-100 text-teal-700 border-0 mb-8 rounded-full shadow-sm hover:bg-teal-700 hover:text-white transition-all duration-300">
                <TrendingUp className="w-5 h-5 mr-2" />
                Enhanced Productivity
              </Badge>
              <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
                Work Smarter, Not Harder
              </h2>
              <p className="text-xl text-gray-600 mb-8 font-light leading-relaxed">
                Our AI for productivity solutions automate the mundane, liberating your team to focus on what matters most: strategy, creativity, and growth. Experience a new level of operational efficiency.
              </p>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-teal-500 to-cyan-500 text-white rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800">Reclaim 10+ Hours Weekly</h4>
                    <p className="text-gray-600">Automate reporting, data analysis, and content creation to free up valuable time for every team member.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-500 text-white rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg">
                    <Sparkles className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800">5x Creative Output</h4>
                    <p className="text-gray-600">Generate multiple ad creatives, copy variations, and campaign ideas in minutes, not days.</p>
                  </div>
                </div>
              </div>
            </motion.div>
            <motion.div
              className="relative hidden lg:block"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.2 }}>

              <img src="https://i.imghippo.com/files/Okz5149jjM.jpeg" alt="Team collaborating efficiently with AI tools in a modern office, highlighting enhanced productivity" className="relative rounded-2xl shadow-xl"
                loading="lazy" decoding="async"
              />
            </motion.div>
          </div>
        </section>

        {/* Gaurav Oberoi Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <Badge className="px-6 py-3 text-base font-semibold bg-red-50 text-red-600 border-0 mb-4 rounded-full shadow-sm">
                <BrainCircuit className="w-5 h-5 mr-2" />
                Meet Our Founder
              </Badge>
              <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6 leading-tight">
                Gaurav Oberoi
                <span className="block bg-gradient-to-r from-red-600 to-orange-500 bg-clip-text text-transparent mt-2">
                  AI Implementation Expert
                </span>
              </h2>
              <p className="text-xl text-gray-600 mb-8 font-light leading-relaxed">
                With over 15 years of experience in growth marketing and a deep dive into AI for the past 5 years, Gaurav Oberoi leads our team in building cutting-edge AI solutions. His vision is to empower businesses with autonomous agents that drive unprecedented growth and efficiency.
              </p>
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-red-600 flex-shrink-0" />
                  <p className="text-gray-700 font-medium">15+ Years in Growth Marketing</p>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-red-600 flex-shrink-0" />
                  <p className="text-gray-700 font-medium">5+ Years in AI Implementation</p>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-red-600 flex-shrink-0" />
                  <p className="text-gray-700 font-medium">Built 100+ Custom AI Agents</p>
                </div>
              </div>
              <a
                href="https://www.linkedin.com/in/gauravoberoi/"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button
                  size="lg"
                  className="mt-10 bg-gradient-to-r from-red-600 to-orange-600 hover:from-red-700 hover:to-orange-700 text-white px-8 py-4 text-lg font-semibold rounded-xl shadow-lg group transform hover:scale-105 transition-transform"
                >
                  Connect with Gaurav
                  <MessageSquare className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </a>
            </motion.div>
            <motion.div
              className="relative"
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/a54d506d6_Gaurav_SiFi.png"
                alt="Gaurav Oberoi, AI Implementation Expert in Dubai"
                className="rounded-2xl shadow-xl"
                loading="lazy"
                decoding="async"
              />
            </motion.div>
          </div>
        </section>


        {/* Future of AI Section */}
        <section className="relative py-20 px-4 sm:px-6 lg:px-8 bg-gray-900 text-white overflow-hidden">
          {/* Background Effects */}
          <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl animate-float"></div>
          <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }}></div>

          <div className="relative max-w-7xl mx-auto text-center z-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}>

              <Badge className="px-6 py-3 text-base font-semibold bg-white/10 text-cyan-300 border border-white/20 rounded-full backdrop-blur-sm mb-8 hover:bg-white hover:text-gray-900 transition-all duration-300">
                <BrainCircuit className="w-5 h-5 mr-3" />
                The Next Frontier of AI
              </Badge>
              <h2 className="text-4xl sm:text-5xl lg:text-6xl font-bold mb-6">
                The Age of
                <span className="bg-gradient-to-r from-blue-400 to-green-400 bg-clip-text text-transparent block md:inline md:ml-4">
                  Autonomous Agents
                </span>
              </h2>
              <p className="text-xl text-gray-300 max-w-4xl mx-auto font-light leading-relaxed mb-12">
                The next wave of AI isn't just about assisting humans—it's about autonomous systems that manage entire workflows. From AI for growth marketing campaigns to customer service, AI generalist agents will strategize, execute, and optimize with minimal oversight. We build these future-ready systems for you today.
              </p>
            </motion.div>

            <div className="grid md:grid-cols-3 gap-8">
              {[
              { icon: Brain, title: "Predictive Strategy", desc: "AI that anticipates market shifts and formulates proactive strategies." },
              { icon: Zap, title: "Self-Optimizing Systems", desc: "Campaigns that improve themselves based on real-time performance data." },
              { icon: Infinity, title: "End-to-End Automation", desc: "From first touch to final sale, entire customer journeys managed by AI." }].
              map((item, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.4 + index * 0.2 }}
                className="bg-white/5 p-8 rounded-2xl border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-300 group">

                  <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-lg group-hover:scale-110 transition-transform duration-300">
                    <item.icon className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="text-xl font-semibold mb-2 text-white">{item.title}</h4>
                  <p className="text-gray-400">{item.desc}</p>
                </motion.div>
              )}
            </div>
          </div>
        </section>

      {/* Ready to Build Your Custom AI Agent? */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-900 via-blue-900 to-indigo-900 text-white relative overflow-hidden">
        {/* Background Effects */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-green-600/10 rounded-full blur-3xl animate-float" style={{ animationDelay: '3s' }}></div>

        <div className="relative max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8 }}
            className="mb-6 md:mb-8"
          >
            <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-white/10 backdrop-blur-md text-white border border-white/20 rounded-full shadow-lg">
              <Zap className="w-4 h-4 md:w-5 md:h-5 mr-2" />
              Start Your AI Journey
            </Badge>
          </motion.div>

          <motion.h2
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-4 md:mb-6 leading-tight"
          >
            <span className="text-white block">Ready to Build Your</span>
            <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent block mt-2">
              Custom AI Agent?
            </span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-base sm:text-lg md:text-xl text-gray-300 mb-8 md:mb-12 max-w-3xl mx-auto leading-relaxed font-light px-4 sm:px-0"
          >
            Transform your business with custom AI solutions that work around the clock.
            Let's discuss how we can build the perfect AI system for your specific needs.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center px-4 sm:px-0"
          >
            <Button
              size="lg"
              className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-6 md:px-8 py-3 md:py-4 text-base md:text-lg font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 group transform hover:scale-105"
              onClick={openModal}
            >
              Start Your AI Project
              <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="w-full sm:w-auto bg-white/10 backdrop-blur-md text-white border-2 border-white/30 hover:bg-white/20 px-6 md:px-8 py-3 md:py-4 text-base md:text-lg font-semibold rounded-xl group"
              onClick={openModal}
            >
              Schedule Discovery Call
              <Phone className="w-4 h-4 md:w-5 md:h-5 ml-2" />
            </Button>
          </motion.div>
        </div>
      </section>
      </div>
    </>
  );
}
