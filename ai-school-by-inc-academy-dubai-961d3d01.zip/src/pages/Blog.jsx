
import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { BlogPost } from "@/api/entities";
import { User } from "@/api/entities"; // Added User import
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar, User as UserIcon, BookOpen, Search, Filter } from "lucide-react"; // Renamed User to UserIcon to avoid conflict
import { motion } from "framer-motion";

export default function Blog() {
    const [blogPosts, setBlogPosts] = useState([]);
    const [filteredPosts, setFilteredPosts] = useState([]);
    const [loading, setLoading] = useState(true);
    const [selectedCategory, setSelectedCategory] = useState("All");
    const [searchQuery, setSearchQuery] = useState("");
    const [user, setUser] = useState(null); // Added user state

    const categories = ["All", "AI Training", "Industry Insights", "Company News", "Case Studies", "Tips & Tricks"];

    useEffect(() => {
        document.title = "AI Marketing Blog | Latest Insights & Updates - Inc. Academy Dubai";
        const metaDesc = document.querySelector('meta[name="description"]') || document.createElement('meta');
        metaDesc.name = "description";
        metaDesc.content = "Stay updated with the latest AI marketing insights, industry trends, and expert tips from Inc Academy Dubai. Your source for AI transformation knowledge in the UAE.";
        if (!document.querySelector('meta[name="description"]')) {
            document.head.appendChild(metaDesc);
        }
    }, []);

    useEffect(() => {
        loadBlogPosts();
        checkUser(); // Call checkUser here
    }, []);

    useEffect(() => {
        let filtered = blogPosts;

        if (selectedCategory !== "All") {
            filtered = filtered.filter(post => post.category === selectedCategory);
        }

        if (searchQuery.trim()) {
            filtered = filtered.filter(post => 
                post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
                (post.tags && post.tags.toLowerCase().includes(searchQuery.toLowerCase()))
            );
        }

        setFilteredPosts(filtered);
    }, [blogPosts, selectedCategory, searchQuery]);

    const loadBlogPosts = async () => {
        try {
            const posts = await BlogPost.filter({ published: true }, '-created_date', 50);
            setBlogPosts(posts);
        } catch (error) {
            console.error('Error loading blog posts:', error);
        } finally {
            setLoading(false);
        }
    };

    // Added checkUser function
    const checkUser = async () => {
        try {
            const currentUser = await User.me();
            setUser(currentUser);
        } catch (error) {
            // User not logged in or error fetching user
            setUser(null);
        }
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    };

    const featuredPosts = filteredPosts.filter(post => post.featured).slice(0, 2);
    const regularPosts = filteredPosts.filter(post => !post.featured);

    return (
        <div className="min-h-screen bg-white">
            {/* Hero Section */}
            <section className="bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 text-white py-20 md:py-32 px-4 sm:px-6 lg:px-8">
                <div className="max-w-7xl mx-auto text-center">
                    <motion.div
                        initial={{ opacity: 0, y: 30 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.8 }}
                        className="mb-8"
                    >
                        <Badge className="px-6 py-3 text-base font-semibold bg-white/10 backdrop-blur-sm text-white border border-white/20 mb-6">
                            <BookOpen className="w-5 h-5 mr-2" />
                            Knowledge Hub
                        </Badge>
                        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 leading-tight">
                            <span className="text-white block">AI Marketing</span>
                            <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent block mt-2">
                                Blog & Insights
                            </span>
                        </h1>
                        <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
                            Stay ahead of the AI revolution with expert insights, industry trends, and practical guides
                            from Dubai's leading AI marketing academy.
                        </p>
                    </motion.div>
                </div>
            </section>

            {/* Search and Filter Section */}
            <section className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-50">
                <div className="max-w-7xl mx-auto">
                    <div className="flex flex-col lg:flex-row gap-6 items-center justify-between mb-8">
                        {/* Search Bar */}
                        <div className="relative flex-1 max-w-md">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="text"
                                placeholder="Search articles..."
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                            />
                        </div>

                        {/* Category Filter */}
                        <div className="flex items-center gap-2 flex-wrap">
                            <Filter className="w-5 h-5 text-gray-500" />
                            {categories.map((category) => (
                                <Button
                                    key={category}
                                    variant={selectedCategory === category ? "default" : "outline"}
                                    size="sm"
                                    onClick={() => setSelectedCategory(category)}
                                    className="rounded-full"
                                >
                                    {category}
                                </Button>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* Blog Content */}
            <section className="py-16 px-4 sm:px-6 lg:px-8">
                <div className="max-w-7xl mx-auto">
                    {/* Header with conditional Create Post Button */}
                    <div className="mb-8 flex justify-between items-center">
                        <h2 className="text-2xl font-bold text-gray-900">Latest Articles</h2>
                        {user && user.role === 'admin' && ( // Conditional rendering for the button
                            <Link to={createPageUrl("CreateBlogPost")}>
                                <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                                    + Create Post
                                </Button>
                            </Link>
                        )}
                    </div>

                    {loading ? (
                        <div className="text-center py-20">
                            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                            <p className="mt-4 text-gray-600">Loading articles...</p>
                        </div>
                    ) : filteredPosts.length === 0 ? (
                        <div className="text-center py-20">
                            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                            <h3 className="text-2xl font-bold text-gray-900 mb-2">No Articles Found</h3>
                            <p className="text-gray-600 mb-8">
                                {searchQuery || selectedCategory !== "All"
                                    ? "Try adjusting your search or filter criteria."
                                    : "Be the first to publish an article!"
                                }
                            </p>
                            {(searchQuery || selectedCategory !== "All") && (
                                <Button
                                    onClick={() => {
                                        setSearchQuery("");
                                        setSelectedCategory("All");
                                    }}
                                    className="bg-blue-600 hover:bg-blue-700 text-white"
                                >
                                    Clear Filters
                                </Button>
                            )}
                        </div>
                    ) : (
                        <div className="space-y-16">
                            {/* Featured Posts */}
                            {featuredPosts.length > 0 && (
                                <div>
                                    <h2 className="text-3xl font-bold text-gray-900 mb-8">Featured Articles</h2>
                                    <div className="grid md:grid-cols-2 gap-8">
                                        {featuredPosts.map((post, index) => (
                                            <motion.article
                                                key={post.id}
                                                initial={{ opacity: 0, y: 30 }}
                                                whileInView={{ opacity: 1, y: 0 }}
                                                viewport={{ once: true }}
                                                transition={{ duration: 0.6, delay: index * 0.1 }}
                                            >
                                                <Link to={createPageUrl("BlogPost", { slug: post.slug })}>
                                                    <Card className="overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300 group cursor-pointer">
                                                        <div className="aspect-[16/9] overflow-hidden">
                                                            <img
                                                                src={post.image}
                                                                alt={post.title}
                                                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                                            />
                                                        </div>
                                                        <CardContent className="p-6">
                                                            <div className="flex items-center gap-4 mb-4">
                                                                <Badge variant="secondary">{post.category}</Badge>
                                                                <div className="flex items-center gap-2 text-gray-500 text-sm">
                                                                    <Calendar className="w-4 h-4" />
                                                                    {formatDate(post.created_date)}
                                                                </div>
                                                            </div>
                                                            <h3 className="text-2xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                                                                {post.title}
                                                            </h3>
                                                            <p className="text-gray-600 mb-4 leading-relaxed">
                                                                {post.excerpt}
                                                            </p>
                                                            <div className="flex items-center text-blue-600 font-semibold group-hover:gap-3 transition-all duration-300">
                                                                <span>Read More</span>
                                                                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                                                            </div>
                                                        </CardContent>
                                                    </Card>
                                                </Link>
                                            </motion.article>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Regular Posts */}
                            {regularPosts.length > 0 && (
                                <div>
                                    <h2 className="text-3xl font-bold text-gray-900 mb-8">Latest Articles</h2>
                                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                                        {regularPosts.map((post, index) => (
                                            <motion.article
                                                key={post.id}
                                                initial={{ opacity: 0, y: 30 }}
                                                whileInView={{ opacity: 1, y: 0 }}
                                                viewport={{ once: true }}
                                                transition={{ duration: 0.6, delay: index * 0.1 }}
                                            >
                                                <Link to={createPageUrl("BlogPost", { slug: post.slug })}>
                                                    <Card className="h-full overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer">
                                                        <div className="aspect-[16/9] overflow-hidden">
                                                            <img
                                                                src={post.image}
                                                                alt={post.title}
                                                                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                                                            />
                                                        </div>
                                                        <CardContent className="p-6 flex flex-col h-full">
                                                            <div className="flex items-center gap-4 mb-4">
                                                                <Badge variant="outline">{post.category}</Badge>
                                                                <div className="flex items-center gap-2 text-gray-500 text-sm">
                                                                    <Calendar className="w-4 h-4" />
                                                                    {formatDate(post.created_date)}
                                                                </div>
                                                            </div>
                                                            <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-600 transition-colors">
                                                                {post.title}
                                                            </h3>
                                                            <p className="text-gray-600 mb-4 leading-relaxed flex-grow">
                                                                {post.excerpt}
                                                            </p>
                                                            <div className="flex items-center text-blue-600 font-semibold group-hover:gap-3 transition-all duration-300 mt-auto">
                                                                <span>Read More</span>
                                                                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                                                            </div>
                                                        </CardContent>
                                                    </Card>
                                                </Link>
                                            </motion.article>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    )}
                </div>
            </section>

            {/* Newsletter Section */}
            <section className="bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 text-white py-16 px-8 rounded-3xl">
                <div className="max-w-2xl mx-auto text-center">
                    <h3 className="text-3xl font-bold mb-4">Stay Ahead of the AI Curve</h3>
                    <p className="text-blue-100 mb-8">
                        Get weekly insights on AI trends, practical tips, and exclusive resources delivered to your inbox.
                    </p>

                    <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
                        <input
                            type="email"
                            placeholder="Enter your email address"
                            className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-white"
                        />
                        <Button className="bg-white text-blue-600 hover:bg-gray-100 px-6 py-3 font-semibold rounded-lg">
                            <ArrowRight className="w-4 h-4 mr-2" />
                            Subscribe Now
                        </Button>
                    </div>
                </div>
            </section>
        </div>
    );
}
