
import React, { useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Eye, Lock, UserCheck, Mail, Phone } from "lucide-react";

export default function Privacy() {
  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "Privacy Policy | AI Marketing Training Dubai UAE - Inc. Academy Data Protection";
    const description = "Privacy policy for Inc. Academy AI marketing training in Dubai UAE. Learn how we protect your personal data and ensure GDPR compliance for our ChatGPT courses and consultancy services in UAE.";
    const imageUrl = "https://static.wixstatic.com/media/ad9f8f_569c63b1629540f2b143e3c3085Bdfd4~mv2.png/v1/fill/w_476,h_92,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Inc_Academy_Logo_Transparent_edited.png";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);
  }, []);

  return (
    <div className="min-h-screen bg-white py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="px-6 py-3 text-base font-semibold bg-blue-50 text-blue-600 border-0 mb-8">
            <Shield className="w-5 h-5 mr-2" />
            Data Protection & Privacy
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            Privacy Policy
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Last updated: January 2025
          </p>
        </div>

        {/* Content */}
        <div className="space-y-8">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Eye className="w-6 h-6 text-blue-600" />
                Information We Collect
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                At Inc Academy, we collect information that you provide directly to us, such as when you:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• Register for our courses or workshops</li>
                <li>• Request information about our services</li>
                <li>• Subscribe to our newsletter</li>
                <li>• Contact us for support or inquiries</li>
                <li>• Participate in surveys or feedback forms</li>
              </ul>
              <p className="text-gray-600 leading-relaxed mt-4">
                This information may include your name, email address, phone number, company information, 
                and any other details you choose to provide.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Lock className="w-6 h-6 text-blue-600" />
                How We Use Your Information
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                We use the information we collect to:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• Provide, maintain, and improve our services</li>
                <li>• Process registrations and deliver training programs</li>
                <li>• Send you course materials, updates, and important notifications</li>
                <li>• Respond to your inquiries and provide customer support</li>
                <li>• Send marketing communications (with your consent)</li>
                <li>• Analyze usage patterns to enhance user experience</li>
                <li>• Comply with legal obligations</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <UserCheck className="w-6 h-6 text-blue-600" />
                Information Sharing
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                We do not sell, trade, or rent your personal information to third parties. We may share 
                your information in the following circumstances:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• With trusted service providers who assist in delivering our services</li>
                <li>• When required by law or to protect our legal rights</li>
                <li>• In connection with a business transfer or acquisition</li>
                <li>• With your explicit consent</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Shield className="w-6 h-6 text-blue-600" />
                Data Security
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                We implement appropriate security measures to protect your personal information against 
                unauthorized access, alteration, disclosure, or destruction. These measures include:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• Encryption of sensitive data in transit and at rest</li>
                <li>• Regular security assessments and updates</li>
                <li>• Access controls and authentication measures</li>
                <li>• Secure hosting and data storage practices</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Eye className="w-6 h-6 text-blue-600" />
                Your Rights
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                You have the following rights regarding your personal information:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• Access: Request copies of your personal information</li>
                <li>• Rectification: Request correction of inaccurate information</li>
                <li>• Erasure: Request deletion of your personal information</li>
                <li>• Restriction: Request limitation of processing</li>
                <li>• Portability: Request transfer of your data</li>
                <li>• Objection: Object to processing of your personal information</li>
              </ul>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card className="border-0 shadow-lg bg-gradient-to-r from-blue-50 to-purple-50">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Contact Us</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-6">
                If you have any questions about this Privacy Policy or wish to exercise your rights, 
                please contact us:
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <div className="flex items-center gap-2 text-gray-700">
                  <Mail className="w-5 h-5 text-blue-600" />
                  <span>hello@inc.academy</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <Phone className="w-5 h-5 text-blue-600" />
                  <span>+971 52 437 1377</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
