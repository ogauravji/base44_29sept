
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import PaymentButton from '@/components/common/PaymentButton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Target, CheckCircle2, TrendingUp, Briefcase, Rocket, Users, Award, Star, ArrowRight,
  BrainCircuit, AlertTriangle, DollarSign, Shield, BookOpen, UserCheck, BarChart3,
  PenSquare, Building, Eye, Zap, Crown, Brain, Globe, Clock, Calendar, Monitor,
  MessageCircle, GitBranch, ChevronDown, ChevronUp, Flame, Code, Database, Settings,
  Package, Percent, Download, Mail, UserMinus, UserPlus, SlidersHorizontal
} from "lucide-react";
import { motion } from "framer-motion";
import { createPageUrl } from '@/utils';
import BookingSection from "../components/landing/BookingSection";

const CountdownTimer = ({ targetDate = "2025-10-21T00:00:00" }) => {
  const [timeLeft, setTimeLeft] = useState({
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0
  });

  useEffect(() => {
    const timer = setInterval(() => {
      const difference = new Date(targetDate) - new Date();
      if (difference > 0) {
        setTimeLeft({
          days: Math.floor(difference / (1000 * 60 * 60 * 24)),
          hours: Math.floor(difference % (1000 * 60 * 60 * 24) / (1000 * 60 * 60)),
          minutes: Math.floor(difference % (1000 * 60 * 60) / (1000 * 60)),
          seconds: Math.floor(difference % (1000 * 60) / 1000)
        });
      } else {
        setTimeLeft({ days: 0, hours: 0, minutes: 0, seconds: 0 });
        clearInterval(timer);
      }
    }, 1000);
    return () => clearInterval(timer);
  }, [targetDate]);

  return (
    <div className="flex gap-2 sm:gap-4 justify-center">
      {Object.entries(timeLeft).map(([unit, value]) =>
        <div key={unit} className="bg-white/20 backdrop-blur-sm rounded-lg p-2 sm:p-4 text-center min-w-12 sm:min-w-16">
          <div className="text-lg sm:text-2xl font-bold text-white">{value.toString().padStart(2, '0')}</div>
          <div className="text-xs text-purple-200 uppercase">{unit}</div>
        </div>
      )}
    </div>);
};


const whoShouldAttend = [
  { icon: Crown, title: "L1 Graduates & AI Power-Users", description: "Take your foundational skills to the next level of practical application and become a true AI generalist." },
  { icon: Rocket, title: "Founders & Tech Leaders", description: "Learn to build and deploy custom AI solutions and AI workflow automation without a team of developers. An essential AI for entrepreneurs course." },
  { icon: Briefcase, title: "Product & Project Managers", description: "Integrate Generative AI capabilities into your products and internal workflows. A key AI for managers program." },
  { icon: TrendingUp, title: "Senior Marketers & Analysts", description: "Move beyond using tools to building custom AI-powered marketing and data systems. Ideal for AI for CMOs and growth marketing leaders." },
  { icon: Brain, title: "Innovators & Business Leaders", description: "Anyone in a leadership role who wants to stop just using AI and start building with it. A perfect AI for executives course." },
  { icon: UserCheck, title: "Aspiring AI Consultants", description: "Gain the deep, practical knowledge required to consult on AI strategy and automation. The ultimate AI for consultants program." }];


const modules = [
  { icon: GitBranch, level: 'Advanced', title: "Advanced Prompt Chaining & Multi-Model Workflows", description: "Orchestrate multiple AI models to perform complex tasks and create sophisticated automation chains." },
  { icon: Code, level: 'Advanced', title: "AI API Integrations (OpenAI, Claude, etc.)", description: "Connect AI capabilities to any application using APIs, webhooks, and custom integrations." },
  { icon: Zap, level: 'Advanced', title: "Building No-Code AI Agents (Make, Zapier, Langflow)", description: "Use platforms like Make, Zapier, and Langflow to create autonomous agents that work 24/7." },
  { icon: SlidersHorizontal, level: 'Advanced', title: "Advanced Automation for Marketing, Sales, HR", description: "Build full-funnel automation systems that handle lead qualification, customer support, and operations." },
  { icon: Building, level: 'Advanced', title: "Custom GPTs for Internal Business Functions", description: "Develop and deploy specialized AI assistants tailored to your team's specific needs and workflows." },
  { icon: Rocket, level: 'Advanced', title: "Full Capstone Project: Deploy Live AI Agent", description: "Deploy a real AI Agent for a live business use case from conception to production deployment." }];


const testimonials = [
  { quote: "Level 2 is where the magic really happens. I went from using AI tools to building my own automated lead nurturing system. The capstone project was invaluable.", author: "Youssef Hassan", role: "Head of Growth, FinTech" },
  { quote: "This course demystified APIs and automation for me. I can now confidently build and deploy AI agents that save my company thousands of dollars a month in manual work.", author: "Priya Sharma", role: "Product Manager, E-commerce" },
  { quote: "The AI for consultants module was a game-changer. I've been able to offer high-ticket AI workflow automation services to my clients, completely transforming my business.", author: "David Chen", role: "Management Consultant" },
  { quote: "As a tech leader, this AI for executives course gave me the framework to guide my development team. We are now building, not just buying, AI solutions.", author: "Fatima Al-Mansoori", role: "Chief Technology Officer" }];


const industryFacts = [
  { stat: "83%", description: "of companies say AI is a top strategic priority", source: "MIT Sloan Management Review" },
  { stat: "2x", description: "Faster project delivery for teams using AI automation", source: "Deloitte" },
  { stat: "$100k+", description: "Average salary for AI specialists and automation experts", source: "Glassdoor" },
  { stat: "90%", description: "of business leaders believe AI will provide a competitive edge", source: "Forbes" }];


const bonusItems = [
  { icon: BookOpen, title: "200+ Premium AI Prompts", value: "$200", description: "Advanced prompts for complex problem-solving and agent instructions." },
  { icon: Users, title: "1-on-1 Mentoring Session", value: "$500", description: "A private session with the trainer to review your capstone project." },
  { icon: Settings, title: "10 AI Agent Templates", value: "$400", description: "Pre-built templates for sales, support, and operations agents." },
  { icon: Percent, title: "Advanced Tool Discounts", value: "$400", description: "Exclusive access and discounts for premium AI platforms." }];


const clientLogos = [
  { src: "https://i.imghippo.com/files/AIj7022XwI.png", alt: "Google" },
  { src: "https://i.imghippo.com/files/BtVJ7689eU.png", alt: "TikTok" },
  { src: "https://i.imghippo.com/files/zETQ9249BY.png", alt: "Dubai Tourism" },
  { src: "https://i.imghippo.com/files/LjWL1133fc.png", alt: "Emirates" },
  { src: "https://i.imghippo.com/files/RymB7570vQ.png", alt: "Alshaya" },
  { src: "https://i.imghippo.com/files/IPE5684MnM.png", alt: "Unilever" },
  { src: "https://i.imghippo.com/files/QUIK6243XI.png", alt: "Etihad" },
  { src: "https://i.imghippo.com/files/CBg5407ZEg.png", alt: "Harvard Business School" }];


const aiToolLogos = [
  { name: 'OpenAI', src: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/251b996ee_Screenshot2025-08-11at10426PM.png' },
  { name: 'LangChain', src: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/986f72b03_Screenshot2025-08-11at10437PM.png' },
  { name: 'Make.com', src: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fecdb0dbe_Screenshot2025-08-11at10451PM.png' },
  { name: 'Zapier', src: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/f4572d914_Screenshot2025-08-11at10505PM.png' },
  { name: 'Anthropic', src: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/1022df36d_Screenshot2025-08-11at10517PM.png' },
  { name: 'Claude', src: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fcfef5267_Screenshot2025-08-11at10526PM.png' }];


const faqsData = {
  'Course Details': [
    {
      q: "What is the main difference between Level 1 and Level 2?",
      a: "Level 1 focuses on *using* existing Generative AI tools for productivity. You'll master prompting and content creation. This Level 2 AI in business course is about *building* with AI. You'll learn to connect APIs, create AI workflow automation, and build custom AI agents without writing code. It's the step from AI user to AI architect."
    },
    {
      q: "Is Level 1 a mandatory prerequisite for this course?",
      a: "While not mandatory, our Level 1 AI strategy course is highly recommended. Level 2 assumes you have a solid understanding of fundamental AI concepts and prompting. We offer a quick assessment to see if you can join Level 2 directly."
    }],

  'Technical & Projects': [
    {
      q: "Do I need to write code for Level 2?",
      a: "Absolutely not. This is a no-code program focusing on AI automation. We use visual development platforms like Make, Zapier, and Langflow. You'll learn to work with APIs through user-friendly interfaces, without writing a single line of code."
    },
    {
      q: "What kind of projects will we build?",
      a: "You'll build several mini-projects, including an automated content pipeline, a customer support agent, and a sales outreach system. The final capstone project involves building a custom AI agent tailored to your own business needs, showcasing your skills in AI for productivity."
    }],

  'Logistics & Support': [
    {
      q: "How will I join the session?",
      a: "You’ll receive a Zoom link by email 24 hours before the session. All our AI for executives training is live and interactive."
    },
    {
      q: "What if I am unable to attend a live session?",
      a: "You can reschedule to a future cohort if you notify us at least 48 hours in advance. Our AI for managers course is dynamic and relies on live participation."
    },
    {
      q: "Do you provide recordings of the sessions?",
      a: "No, we do not provide recordings. Our methodology emphasizes live, hands-on learning and real-time interaction to ensure the highest quality educational experience for our AI in business course."
    },
    {
      q: "Is there ongoing support after the course?",
      a: "Yes! You get lifetime access to our private graduate community for ongoing Q&A, networking, and to stay updated on the latest in Generative AI."
    },
    {
      q: "Can I retake the course?",
      a: "Yes, graduates can re-attend the same course for 25% discount within 12 months, subject to availability. This allows you to refresh your skills in the fast-evolving field of AI."
    }],

  'Outcomes & Policies': [
    {
      q: "Will I get a certificate upon completion?",
      a: "Yes, upon successful completion, you will receive a Certificate of Completion from Inc. Academy, validating your new skills in AI workflow automation and strategy."
    },
    {
      q: "Do you offer job placement or internships?",
      a: "We do not offer direct job placement. However, this AI strategy course provides you with highly in-demand skills that significantly strengthen your professional profile for new opportunities."
    },
    {
      q: "What's the refund policy?",
      a: "All sales are final, and we do not offer refunds. We are confident in the immense value of our program. You may, however, transfer your seat or reschedule to a future date with advance notice."
    }]

};

const courseFeatures = [
  "30 hours of advanced, expert-led AI training",
  "Lifetime access to custom AI agent building tools",
  "1-on-1 capstone project mentorship",
  "Certificate of Advanced AI Mastery"
];

export default function AIAdvancedCourse() {
  const [openFAQ, setOpenFAQ] = useState(0);
  const [activeFAQCategory, setActiveFAQCategory] = useState('Course Details');
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  // Removed selectedBatch state as per the outline

  // Set timer to 6 days from now - not used in new booking section, but kept if CountdownTimer component is used elsewhere
  const sixDaysFromNow = new Date();
  sixDaysFromNow.setDate(sixDaysFromNow.getDate() + 6);

  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "Advanced Generative AI Course | Dubai | Inc Academy";
    const description = "Build real AI capability: prompt engineering, agents, RAG, fine-tuning, evals, and governance. For power users and teams scaling enterprise-grade AI in the region.";
    const keywords = "advanced AI course Dubai, generative AI training UAE, AI agents workshop, RAG training Dubai, LLM fine-tuning UAE, AI evals, AI governance UAE, enterprise AI course GCC";
    const imageUrl = "https://i.imghippo.com/files/tfUo2263Io.png";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('name', 'keywords', keywords);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);

    // Schema.org structured data
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Course",
      "name": "Advanced Generative AI Course",
      "description": description,
      "provider": {
        "@type": "Organization",
        "name": "Inc Academy",
        "url": "https://ai.inc.academy"
      },
      "courseMode": "blended",
      "educationalLevel": "advanced",
      "teaches": ["prompt engineering", "AI agents", "RAG", "fine-tuning", "AI governance"]
    });
    document.head.appendChild(script);
  }, []);

  const scrollToForm = () => {
    document.getElementById('booking-section').scrollIntoView({ behavior: 'smooth' });
  };

  const handleLeadSubmit = (e) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  return (
    <div className="bg-white text-gray-800">
      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-grid-slate-100/[0.05] [mask-image:linear-gradient(to_bottom,white_5%,transparent_95%)]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center py-20 sm:py-32">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="z-10 text-center lg:text-left">

              <Badge className="mb-6 bg-indigo-500 text-white px-4 py-2 text-sm font-semibold hover:bg-indigo-600 transition-colors">
                Level 2: AI Skills Accelerator
              </Badge>
              <h1 className="text-4xl sm:text-6xl font-bold mb-6 tracking-tight">
                Go Beyond Using AI. Start Building With It.
              </h1>
              <p className="text-lg sm:text-xl text-indigo-200 max-w-2xl mx-auto lg:mx-0 mb-8">A 30-hour advanced Generative AI Skills Accelerator program for professionals ready to design, build, and deploy custom AI agents and AI workflow automation.

              </p>
              <div className="flex justify-center lg:justify-start">
                <Button onClick={scrollToForm} size="lg" className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-xl shadow-lg group text-lg">
                  Enroll Now & Save
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="hidden lg:flex justify-center">
              <div className="relative w-full max-w-lg">
                <div className="absolute -inset-4 bg-gradient-to-r from-indigo-600 to-sky-600 rounded-full blur-3xl opacity-50 animate-pulse"></div>
                <img
                  src="https://i.imghippo.com/files/aFCG2460DMo.jpeg"
                  alt="AI agent robot working with tablet - representing advanced AI automation"
                  className="relative rounded-2xl shadow-2xl w-full h-auto" />

              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Urgency Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">The New Competitive Edge is Building, Not Just Using</h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              While others are still mastering basic prompts, you will be deploying automated systems that create sustainable business value with this AI in business course.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {industryFacts.map((fact, index) =>
              <Card key={index} className="text-center border-indigo-200 bg-white">
                <CardContent className="p-6">
                  <div className="text-3xl font-bold text-indigo-600 mb-2">{fact.stat}</div>
                  <p className="text-gray-700 text-sm mb-2">{fact.description}</p>
                  <p className="text-xs text-gray-500">{fact.source}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Before & After Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">From AI User to AI Architect</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">This AI Accelerator course is designed to transform your relationship with technology—from a passive consumer to an active creator of value.

            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 items-stretch">
            <Card className="p-8 border-red-200 bg-white">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <UserMinus className="w-6 h-6 text-red-600" />
                </div>
                <h3 className="text-2xl font-bold text-red-800">Before This Course</h3>
              </div>
              <ul className="space-y-3 text-gray-600">
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-red-400 mt-1 shrink-0" /><span>Limited by off-the-shelf AI tools.</span></li>
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-red-400 mt-1 shrink-0" /><span>Manually performing repetitive tasks.</span></li>
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-red-400 mt-1 shrink-0" /><span>Struggling to connect different systems.</span></li>
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-red-400 mt-1 shrink-0" /><span>Reacting to business needs with generic solutions.</span></li>
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-red-400 mt-1 shrink-0" /><span>Following AI trends rather than setting them.</span></li>
              </ul>
            </Card>
            <Card className="p-8 border-green-200 bg-gradient-to-br from-green-50 to-white">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <UserPlus className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-green-800">After This Course</h3>
              </div>
              <ul className="space-y-3 text-gray-700">
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Building custom AI workflow automation.</span></li>
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Designing autonomous AI agents.</span></li>
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Integrating any app with APIs.</span></li>
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Proactively solving problems with AI systems.</span></li>
                <li className="flex gap-3"><CheckCircle2 className="w-5 h-5 text-green-500 mt-1 shrink-0" /><span>Leading AI strategy and implementation.</span></li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Enhanced Modules Section */}
      <section id="modules" className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">Advanced Curriculum: From Theory to Deployment</h2>
            <p className="text-xl text-gray-600 max-w-4xl mx-auto">
              This project-based curriculum ensures you gain practical, real-world skills in building and managing AI systems for maximum AI for productivity gains.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {modules.map((module, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}>

                <Card className="h-full hover:shadow-xl transition-all duration-300 group border-2 relative border-indigo-200">
                  <div className="p-8">
                    <div className="w-12 h-12 bg-indigo-100 rounded-xl flex items-center justify-center mb-4">
                      <module.icon className="w-6 h-6 text-indigo-600" />
                    </div>
                    <Badge className="absolute top-4 right-4 font-bold bg-red-100 text-red-800">Advanced</Badge>
                    <h3 className="text-xl font-bold text-gray-900 mb-2">{module.title}</h3>
                    <p className="text-gray-600 leading-relaxed">{module.description}</p>
                  </div>
                </Card>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* Who Should Attend */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">Who is the Accelerator For?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">This AI for business leaders program is for those who are ready to transition from AI user to AI builder and implement high-impact AI workflow automation.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {whoShouldAttend.map((audience, index) =>
              <Card key={index} className="border-gray-200 hover:border-indigo-300 transition-all duration-300 hover:shadow-lg">
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-sky-600 rounded-xl flex items-center justify-center mb-4">
                    <audience.icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{audience.title}</h3>
                  <p className="text-gray-600">{audience.description}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Trainer Section - Updated */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
        <div className="absolute top-0 left-0 -translate-x-1/4 -translate-y-1/4 w-96 h-96 bg-indigo-50 rounded-full blur-3xl opacity-70"></div>
        <div className="absolute bottom-0 right-0 translate-x-1/4 translateY-1/4 w-96 h-96 bg-sky-50 rounded-full blur-3xl opacity-70"></div>

        <div className="max-w-7xl mx-auto relative">
          <div className="text-center mb-16">
            <Badge className="bg-indigo-100 text-indigo-800 px-6 py-3 text-base font-medium mb-6 hover:bg-indigo-600 hover:text-white transition-all duration-300">
              <Award className="w-5 h-5 mr-2" />
              Your Expert Instructor
            </Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900">Learn from a Proven Industry Leader</h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img
                src="https://i.imghippo.com/files/tfUo2263Io.png"
                alt="Gaurav Oberoi - Expert AI marketing trainer"
                className="w-full h-auto rounded-2xl shadow-2xl" />

              <div className="absolute -top-4 -right-4 bg-yellow-400 text-gray-900 px-4 py-2 rounded-full font-bold text-sm">
                15+ Years Experience
              </div>
            </div>

            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-4">
                Gaurav Oberoi
              </h3>
              <p className="text-xl text-indigo-600 font-semibold mb-6">
                Founder & Lead AI Trainer at Inc Academy
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Trained 9,000+ professionals across the GCC</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Former Google Regional Trainer</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Dubai Tourism consultant for Expo 2020</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">TikTok MENA collaborator</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-6 h-6 text-green-500" />
                  <span className="text-gray-700">Active investor & startup advisor</span>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-indigo-100">
                <h4 className="text-lg font-bold text-gray-900 mb-3">Why Learn from Gaurav?</h4>
                <p className="text-gray-600 mb-4">
                  "In Level 2, we move beyond the 'what' and 'why' of AI into the 'how'. My goal is to empower you with the practical skills to build robust AI systems that solve your unique business challenges. This is where you become a true AI architect."
                </p>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <span className="text-sm text-gray-500">4.9/5</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Logos Section */}
      <section className="bg-white pt-0 pb-16 sm:pb-20 -mt-12 md:-mt-16 relative z-10">
        <div className="mx-auto max-w-5xl px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-xl p-8 sm:p-12">
            <h2 className="text-center text-lg font-semibold text-gray-600 mb-8">
              Trusted by Professionals From Leading Global Brands
            </h2>
            <div className="mx-auto grid max-w-lg grid-cols-4 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:max-w-none lg:grid-cols-8">
              {clientLogos.map((client, index) =>
                <img
                  key={index}
                  className="col-span-2 max-h-12 w-full object-contain lg:col-span-1 opacity-70 hover:opacity-100 transition-opacity"
                  src={client.src}
                  alt={client.alt}
                  width="158"
                  height="48"
                  loading="lazy"
                  decoding="async" />
              )}
            </div>
          </div>
        </div>
      </section>

      {/* AI Tools Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Hands-On With Industry-Standard Tools</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">We focus on practical application, teaching you to build with the same no-code platforms and APIs used by top tech companies.</p>
          </div>
          <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-8">
            {aiToolLogos.map((tool) =>
              <div key={tool.name} className="px-6 py-3 bg-white rounded-lg shadow-md border border-gray-200 hover:shadow-lg transition-all">
                <span className="text-lg font-semibold text-gray-800">{tool.name}</span>
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Bonus Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-yellow-100 text-yellow-800 px-6 py-3 text-base font-semibold mb-6 hover:bg-yellow-500 hover:text-white transition-all duration-300">
              <Award className="w-5 h-5 mr-2" />
              Accelerator Bonus Pack
            </Badge>
            <h2 className="text-3xl sm:text-5xl font-bold text-gray-900 mb-6">
              Get $1,500 Worth of Advanced Resources
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Enroll today and get exclusive access to our toolkit for AI builders.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
            {bonusItems.map((bonus, index) =>
              <Card key={index} className="text-center border-yellow-200 hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="w-16 h-16 bg-yellow-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <bonus.icon className="w-8 h-8 text-yellow-600" />
                  </div>
                  <h4 className="font-bold text-lg mb-2">{bonus.title}</h4>
                  <div className="text-2xl font-bold text-yellow-600 mb-2">{bonus.value}</div>
                  <p className="text-gray-600 text-sm">{bonus.description}</p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Booking & Details Section - UPDATED WITHOUT TABS */}
      <BookingSection
        courseType="ai-accelerator"
        courseName="Level 2: AI Skills Accelerator"
        price={3000}
        nextBatchDate="Starts 15th of Next Month"
        duration="6 Weeks"
        seatsLeft={8}
        features={courseFeatures}
      />

      {/* Bundle Offer Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-3 text-lg font-bold mb-6 shadow-sm hover:bg-blue-600 hover:text-white transition-all duration-300">
              <Package className="w-6 h-6 mr-2" />
              COMPLETE AI MASTERY BUNDLE
            </Badge>
            <h2 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
              The Ultimate AI Learning Journey
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get all three courses together - from introduction to advanced implementation - and save over 50%.
            </p>
          </div>

          <Card className="overflow-hidden shadow-2xl border-2 border-indigo-500" id="bundle-offer">
            <div className="grid lg:grid-cols-2">
              <div className="p-8 md:p-12 bg-white">
                <h3 className="text-3xl font-bold text-gray-900 mb-6">Complete Bundle Includes:</h3>
                <ul className="space-y-4 text-gray-700">
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold">3 Hour AI Mastermind</h4>
                      <p className="text-sm text-gray-600">Fast-track AI introduction and career positioning</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold">Level 1: AI Skills Foundation</h4>
                      <p className="text-sm text-gray-600">15-Hour Comprehensive Training</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold">Level 2: AI Skills Accelerator</h4>
                      <p className="text-sm text-gray-600">30-Hour Advanced System Building</p>
                    </div>
                  </li>
                  <li className="flex items-start gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-500 mt-1 flex-shrink-0" />
                    <div>
                      <h4 className="font-semibold">All Bonuses & Community Access</h4>
                      <p className="text-sm text-gray-600">Lifetime support and exclusive resources.</p>
                    </div>
                  </li>
                </ul>
              </div>
              <div className="p-8 md:p-12 bg-gradient-to-br from-indigo-600 to-sky-600 text-white flex flex-col items-center justify-center text-center">
                <h3 className="text-2xl font-bold mb-4">Total Individual Value: <span className="line-through opacity-80">$5700</span></h3>
                <p className="text-6xl font-extrabold text-yellow-300 mb-2">$3700</p>
                <Badge className="bg-yellow-400 text-gray-900 text-lg font-bold px-4 py-2 mb-8">
                  Save Over $2,000!
                </Badge>
                <PaymentButton
                  courseType="complete-bundle"
                  courseName="Complete AI Mastery Bundle"
                  price={3700}
                  className="bg-white hover:bg-gray-200 text-indigo-600 hover:text-indigo-700 px-12 py-6 rounded-xl shadow-2xl font-bold text-xl transform hover:scale-105 transition-all duration-300">

                  Get Complete Bundle
                  <ArrowRight className="w-6 h-6 ml-3" />
                </PaymentButton>
              </div>
            </div>
          </Card>
        </div>
      </section>


      {/* Testimonials */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-5xl font-bold mb-6">Success Stories</h2>
            <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
              {testimonials.map((testimonial, index) =>
                <Card key={index} className="bg-gray-50 border-gray-200">
                  <CardContent className="p-6">
                    <div className="flex mb-3">
                      {[...Array(5)].map((_, i) => <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />)}
                    </div>
                    <p className="text-gray-600 mb-4 italic">"{testimonial.quote}"</p>
                    <p className="font-bold">{testimonial.author}</p>
                    <p className="text-sm text-gray-500">{testimonial.role}</p>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">Frequently Asked Questions</h2>
            <p className="text-lg sm:text-xl text-gray-600 max-w-3xl mx-auto">Your questions about the AI Skills Accelerator, answered.</p>
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {Object.keys(faqsData).map((category) =>
              <Button
                key={category}
                variant={activeFAQCategory === category ? 'default' : 'outline'}
                onClick={() => {
                  setActiveFAQCategory(category);
                  setOpenFAQ(-1); // Close any open FAQ when category changes
                }}
                className={`rounded-full transition-all duration-300 ${activeFAQCategory === category ? 'bg-indigo-600 text-white hover:bg-indigo-700 border-indigo-600' : 'bg-white text-gray-800 border-gray-300 hover:bg-gray-100'}`}>

                {category}
              </Button>
            )}
          </div>

          <div className="space-y-4">
            {faqsData[activeFAQCategory].map((faq, index) =>
              <Card key={index} className="rounded-xl shadow-sm border-gray-200 overflow-hidden">
                <button
                  className="w-full text-left p-6 hover:bg-gray-50 transition-colors duration-200"
                  onClick={() => setOpenFAQ(openFAQ === index ? -1 : index)}>

                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold text-lg text-gray-900 pr-4">{faq.q}</h3>
                    <div className="flex-shrink-0 bg-gray-100 rounded-full w-8 h-8 flex items-center justify-center">
                      {openFAQ === index ?
                        <ChevronUp className="w-5 h-5 text-indigo-600" /> :
                        <ChevronDown className="w-5 h-5 text-gray-500" />
                      }
                    </div>
                  </div>
                </button>
                {openFAQ === index &&
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-6 pb-6">

                    <p className="text-gray-600 leading-relaxed border-l-2 border-indigo-500 pl-4">{faq.a}</p>
                  </motion.div>
                }
              </Card>
            )}
          </div>
        </div>
      </section>

      {/* Consultancy CTA Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center bg-gradient-to-br from-blue-50 to-purple-50 p-8 sm:p-12 rounded-3xl">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-6">Need Help with Implementation?</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
            Our expert consultants can work with your team to design and deploy custom AI solutions tailored to your specific business needs.
          </p>
          <Button asChild size="lg" className="w-full sm:w-auto bg-slate-800 hover:bg-slate-700 text-white px-6 py-4 text-base sm:px-8 sm:text-lg rounded-xl shadow-lg transition-transform duration-300 hover:scale-105">
            <a href={createPageUrl("Consultancy")}>Explore Consultancy Services</a>
          </Button>
        </div>
      </section>

      {/* Free Download Section */}
      <section className="py-16 sm:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-600 to-indigo-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <div className="bg-white/10 backdrop-blur-sm rounded-3xl p-8 sm:p-12 border border-white/20">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-400 rounded-2xl w-20 h-20 flex items-center justify-center mx-auto mb-8 shadow-lg">
              <Download className="w-10 h-10 text-gray-900" />
            </div>

            <h2 className="text-3xl sm:text-4xl font-bold mb-6">
              Get Your Free AI Marketing Toolkit
            </h2>

            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto leading-relaxed">
              Download "25 High-Converting AI Prompts" - the same templates our graduates use to transform their productivity and results.
            </p>

            {!isSubmitted ?
              <form onSubmit={handleLeadSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto mb-8">
                <input
                  type="email"
                  placeholder="Enter your business email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  className="flex-1 px-4 py-3 rounded-lg text-gray-900 placeholder:text-gray-500 focus:outline-none focus:ring-2 focus:ring-yellow-400" />

                <Button
                  type="submit"
                  className="bg-yellow-400 hover:bg-yellow-300 text-gray-900 px-8 py-3 font-bold whitespace-nowrap rounded-lg">

                  <Download className="w-4 h-4 mr-2" />
                  Get Free Kit
                </Button>
              </form> :

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="flex items-center justify-center gap-3 text-green-300 mb-8 bg-green-600/20 p-6 rounded-xl border border-green-400/30">

                <CheckCircle2 className="w-6 h-6" />
                <span className="text-lg font-semibold">Check your email for the download link!</span>
              </motion.div>
            }
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="bg-slate-100 text-white px-4 py-20 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto text-center">
          <Badge className="bg-indigo-500 text-white mb-6 px-4 py-2">Your AI Transformation Begins Now</Badge>
          <h2 className="text-slate-700 mb-6 font-bold sm:text-5xl">Ready to Build the Future?</h2>
          <p className="text-slate-600 mb-10 mx-auto text-xl max-w-3xl">Stop just using AI tools—start building with them. The skills you gain in this advanced AI strategy course will make you an indispensable AI architect.

          </p>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="bg-white/5 border-gray-700 text-left p-8 rounded-2xl">
              <h3 className="text-slate-950 mb-4 font-bold">Level 2: AI Skills Accelerator</h3>
              <p className="text-stone-600 mb-6">30-hour advanced program to build and deploy custom AI agents and automation.</p>
              <div className="mb-6">
                <p className="text-rose-500 font-bold">$3000</p>
                <p className="text-green-400 font-semibold">Save $700 with Early Bird Pricing</p>
              </div>
              <Button onClick={scrollToForm} size="lg" className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg text-lg">
                Enroll in Level 2 & Save
              </Button>
            </Card>
            <Card className="bg-rose-700 text-left p-8 border shadow-sm border-indigo-500/50 rounded-2xl ring-2 ring-indigo-500">
              <h3 className="text-2xl font-bold mb-4">Complete AI Mastery Bundle</h3>
              <p className="text-gray-300 mb-6">All 3 courses (Mastermind, L1, L2) for complete AI mastery. Best value!</p>
              <div className="mb-6">
                <p className="text-3xl font-bold text-yellow-300">$3700 <span className="text-lg text-gray-400 line-through ml-2">$5700</span></p>
                <p className="text-yellow-300 font-semibold">Save Over $2000!</p>
              </div>
              <Button onClick={() => { document.getElementById('bundle-offer').scrollIntoView({ behavior: 'smooth' }); }} size="lg" className="w-full bg-yellow-400 hover:bg-yellow-500 text-gray-900 font-bold rounded-lg text-lg">
                Get The Bundle
              </Button>
            </Card>
          </div>
        </div>
      </section>
    </div>);

}
