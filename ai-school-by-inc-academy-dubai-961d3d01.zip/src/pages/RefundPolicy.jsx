import React from 'react';
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, FileText } from "lucide-react";

export default function RefundPolicy() {
  React.useEffect(() => {
    document.title = "Refund Policy | Inc. Academy";
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-16">
          <Badge className="px-6 py-3 text-base font-semibold bg-blue-100 text-blue-700 border-blue-200 mb-8">
            <Shield className="w-5 h-5 mr-2" />
            Our Policy
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            Refund Policy
          </h1>
          <p className="text-xl text-gray-600">
            Last updated: August 2024
          </p>
        </div>

        <Card className="border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center gap-3 text-2xl text-gray-800">
              <FileText className="w-6 h-6 text-blue-600" />
              Terms of Service
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-lg max-w-none text-gray-700">
            <p>
              You acknowledge that we are under no obligation to refund any fees and applicable charges paid by you, in full or partially, under no circumstances, including for modifying and extending the duration of the Service, change in the commencement date of the Service, your failure to attend or participate in the Service, modification of the structure or content of the Service.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}