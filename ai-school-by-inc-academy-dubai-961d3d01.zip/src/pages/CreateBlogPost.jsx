
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { BlogPost } from "@/api/entities";
import { User } from "@/api/entities";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Save, Eye, Upload } from "lucide-react";
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";

export default function CreateBlogPost() {
    const navigate = useNavigate();
    const [user, setUser] = useState(null);
    const [formData, setFormData] = useState({
        title: "",
        content: "",
        image: "",
        excerpt: "",
        slug: "",
        category: "AI Training",
        tags: "",
        published: true,
        featured: false
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [previewMode, setPreviewMode] = useState(false);

    const categories = ["AI Training", "Industry Insights", "Company News", "Case Studies", "Tips & Tricks"];

    useEffect(() => {
        const checkAuth = async () => {
            try {
                const currentUser = await User.me();
                if (currentUser.role !== 'admin') {
                    navigate(createPageUrl("Home"));
                    return;
                }
                setUser(currentUser);
            } catch (error) {
                navigate(createPageUrl("Home"));
            }
        };
        checkAuth();
    }, [navigate]);

    useEffect(() => {
        // Auto-generate slug from title
        if (formData.title) {
            const slug = formData.title
                .toLowerCase()
                .replace(/[^a-z0-9]+/g, '-')
                .replace(/^-+|-+$/g, '');
            setFormData(prev => ({ ...prev, slug }));
        }
    }, [formData.title]);

    const handleInputChange = (field, value) => {
        setFormData(prev => ({ ...prev, [field]: value }));
    };

    const generateExcerpt = () => {
        if (formData.content) {
            // Remove HTML tags and get first 150 characters
            const plainText = formData.content.replace(/<[^>]*>/g, '');
            const excerpt = plainText.substring(0, 150) + (plainText.length > 150 ? '...' : '');
            setFormData(prev => ({ ...prev, excerpt }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (isSubmitting) return;

        // Validation
        if (!formData.title || !formData.content || !formData.image || !formData.excerpt) {
            alert('Please fill in all required fields');
            return;
        }

        setIsSubmitting(true);

        try {
            await BlogPost.create(formData);
            alert('Blog post created successfully!');
            navigate(createPageUrl("Blog"));
        } catch (error) {
            console.error('Error creating blog post:', error);
            alert('Error creating blog post. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    // Rich text editor modules
    const quillModules = {
        toolbar: [
            [{ 'header': [1, 2, 3, false] }],
            ['bold', 'italic', 'underline', 'strike'],
            [{ 'list': 'ordered'}, { 'list': 'bullet' }],
            [{ 'script': 'sub'}, { 'script': 'super' }],
            [{ 'indent': '-1'}, { 'indent': '+1' }],
            ['blockquote', 'code-block'],
            [{ 'color': [] }, { 'background': [] }],
            [{ 'align': [] }],
            ['link', 'image'],
            ['clean']
        ],
    };

    if (!user) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto">
                {/* Header */}
                <div className="mb-8">
                    <Link to={createPageUrl("Blog")} className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-4">
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to Blog
                    </Link>
                    <h1 className="text-3xl font-bold text-gray-900">Create New Blog Post</h1>
                    <p className="text-gray-600 mt-2">Share your insights with the AI community</p>
                </div>

                {!previewMode ? (
                    /* Edit Mode */
                    <form onSubmit={handleSubmit} className="space-y-8">
                        {/* Basic Info */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Basic Information</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Title *
                                    </label>
                                    <input
                                        type="text"
                                        value={formData.title}
                                        onChange={(e) => handleInputChange('title', e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        placeholder="Enter blog post title"
                                        required
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        URL Slug
                                    </label>
                                    <input
                                        type="text"
                                        value={formData.slug}
                                        onChange={(e) => handleInputChange('slug', e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        placeholder="url-friendly-slug"
                                    />
                                    <p className="text-xs text-gray-500 mt-1">Auto-generated from title. Edit if needed.</p>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Featured Image URL *
                                    </label>
                                    <input
                                        type="url"
                                        value={formData.image}
                                        onChange={(e) => handleInputChange('image', e.target.value)}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        placeholder="https://example.com/image.jpg"
                                        required
                                    />
                                    {formData.image && (
                                        <div className="mt-2">
                                            <img 
                                                src={formData.image} 
                                                alt="Preview" 
                                                className="w-32 h-20 object-cover rounded border"
                                                onError={(e) => e.target.style.display = 'none'}
                                            />
                                        </div>
                                    )}
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-2">
                                            Category
                                        </label>
                                        <select
                                            value={formData.category}
                                            onChange={(e) => handleInputChange('category', e.target.value)}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        >
                                            {categories.map(cat => (
                                                <option key={cat} value={cat}>{cat}</option>
                                            ))}
                                        </select>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-2">
                                            Tags
                                        </label>
                                        <input
                                            type="text"
                                            value={formData.tags}
                                            onChange={(e) => handleInputChange('tags', e.target.value)}
                                            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                            placeholder="AI, ChatGPT, Marketing (comma-separated)"
                                        />
                                    </div>
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Excerpt *
                                    </label>
                                    <div className="flex gap-2 mb-2">
                                        <Button 
                                            type="button" 
                                            variant="outline" 
                                            size="sm" 
                                            onClick={generateExcerpt}
                                            className="text-xs"
                                        >
                                            Auto-generate from content
                                        </Button>
                                    </div>
                                    <textarea
                                        value={formData.excerpt}
                                        onChange={(e) => handleInputChange('excerpt', e.target.value)}
                                        rows={3}
                                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                                        placeholder="Brief summary of the blog post"
                                        required
                                    />
                                </div>
                            </CardContent>
                        </Card>

                        {/* Content Editor */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Content *</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="bg-white rounded-lg border" style={{ minHeight: '400px' }}>
                                    <ReactQuill
                                        value={formData.content}
                                        onChange={(content) => handleInputChange('content', content)}
                                        modules={quillModules}
                                        placeholder="Write your blog post content here..."
                                        style={{ height: '350px', marginBottom: '50px' }}
                                    />
                                </div>
                            </CardContent>
                        </Card>

                        {/* Settings */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Publication Settings</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                                <div className="flex items-center gap-4">
                                    <label className="flex items-center gap-2">
                                        <input
                                            type="checkbox"
                                            checked={formData.published}
                                            onChange={(e) => handleInputChange('published', e.target.checked)}
                                            className="rounded border-gray-300"
                                        />
                                        <span className="text-sm font-medium">Published</span>
                                    </label>

                                    <label className="flex items-center gap-2">
                                        <input
                                            type="checkbox"
                                            checked={formData.featured}
                                            onChange={(e) => handleInputChange('featured', e.target.checked)}
                                            className="rounded border-gray-300"
                                        />
                                        <span className="text-sm font-medium">Featured</span>
                                    </label>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Actions */}
                        <div className="flex flex-col sm:flex-row gap-4 justify-between">
                            <Button 
                                type="button" 
                                variant="outline" 
                                onClick={() => setPreviewMode(true)}
                                className="flex items-center gap-2"
                            >
                                <Eye className="w-4 h-4" />
                                Preview
                            </Button>

                            <div className="flex gap-4">
                                <Button 
                                    type="button" 
                                    variant="outline"
                                    onClick={() => navigate(createPageUrl("Blog"))}
                                >
                                    Cancel
                                </Button>
                                
                                <Button 
                                    type="submit" 
                                    disabled={isSubmitting}
                                    className="flex items-center gap-2"
                                >
                                    {isSubmitting ? (
                                        <>
                                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                                            Creating...
                                        </>
                                    ) : (
                                        <>
                                            <Save className="w-4 h-4" />
                                            Create Post
                                        </>
                                    )}
                                </Button>
                            </div>
                        </div>
                    </form>
                ) : (
                    /* Preview Mode */
                    <div>
                        <div className="mb-6 flex items-center justify-between">
                            <h2 className="text-2xl font-bold">Preview</h2>
                            <Button onClick={() => setPreviewMode(false)} variant="outline">
                                <ArrowLeft className="w-4 h-4 mr-2" />
                                Back to Edit
                            </Button>
                        </div>

                        <Card className="overflow-hidden">
                            <div className="aspect-[16/9] overflow-hidden">
                                <img
                                    src={formData.image}
                                    alt={formData.title}
                                    className="w-full h-full object-cover"
                                />
                            </div>
                            <CardContent className="p-8">
                                <div className="flex items-center gap-4 mb-4">
                                    <Badge variant="secondary">{formData.category}</Badge>
                                    {formData.featured && <Badge variant="default">Featured</Badge>}
                                    <span className="text-sm text-gray-500">
                                        {new Date().toLocaleDateString()}
                                    </span>
                                </div>
                                
                                <h1 className="text-4xl font-bold text-gray-900 mb-4">{formData.title}</h1>
                                <p className="text-xl text-gray-600 mb-8 leading-relaxed">{formData.excerpt}</p>
                                
                                <div 
                                    className="prose prose-lg max-w-none"
                                    dangerouslySetInnerHTML={{ __html: formData.content }}
                                />
                                
                                {formData.tags && (
                                    <div className="mt-8 pt-4 border-t">
                                        <div className="flex flex-wrap gap-2">
                                            {formData.tags.split(',').map((tag, index) => (
                                                <Badge key={index} variant="outline">
                                                    {tag.trim()}
                                                </Badge>
                                            ))}
                                        </div>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </div>
                )}
            </div>
        </div>
    );
}
