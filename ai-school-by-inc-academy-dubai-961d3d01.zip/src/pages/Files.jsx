
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import {
  Upload,
  File,
  Image,
  Trash2,
  Copy,
  Search,
  FolderOpen,
  Download,
  Eye,
  AlertCircle,
  CheckCircle2
} from "lucide-react";
import { UploadFile } from "@/api/integrations";

// Move mockFiles outside component to avoid dependency issues
const mockFiles = [
  {
    id: 1,
    name: "Inc_Academy_Logo_Transparent.png",
    type: "image/png",
    size: "45 KB",
    url: "https://static.wixstatic.com/media/ad9f8f_569c63b1629540f2b143e3c3085Bdfd4~mv2.png/v1/fill/w_476,h_92,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Inc_Academy_Logo_Transparent_edited.png",
    uploadedAt: "2024-01-15T10:30:00Z",
    usedIn: ["Header", "Footer", "Meta Tags"]
  },
  {
    id: 2,
    name: "Gaurav_Profile.png",
    type: "image/png", 
    size: "120 KB",
    url: "https://gauravoberoi.me/Go_Image%20copy.jpeg", // Updated URL
    uploadedAt: "2024-01-15T09:20:00Z",
    usedIn: ["About Page", "Course Pages"]
  },
  {
    id: 3,
    name: "AI_Revolution_Hero.jpeg",
    type: "image/jpeg",
    size: "89 KB", 
    url: "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/dbd194a74_TheAIRevolution.jpeg",
    uploadedAt: "2024-01-15T08:45:00Z",
    usedIn: ["Home Page Hero", "Course Pages"]
  }
];

export default function FilesManagement() {
  const [files, setFiles] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    setFiles(mockFiles);
  }, []);

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;

    setIsUploading(true);
    setUploadStatus(null);

    try {
      const response = await UploadFile({ file });
      
      const newFile = {
        id: Date.now(),
        name: file.name,
        type: file.type,
        size: formatFileSize(file.size),
        url: response.file_url,
        uploadedAt: new Date().toISOString(),
        usedIn: []
      };

      setFiles(prev => [newFile, ...prev]);
      setUploadStatus({ type: 'success', message: 'File uploaded successfully!' });
      
    } catch (error) {
      setUploadStatus({ type: 'error', message: 'Upload failed. Please try again.' });
    } finally {
      setIsUploading(false);
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const copyToClipboard = (url) => {
    navigator.clipboard.writeText(url);
    setUploadStatus({ type: 'success', message: 'URL copied to clipboard!' });
    setTimeout(() => setUploadStatus(null), 3000);
  };

  const getFileIcon = (type) => {
    if (type.startsWith('image/')) return <Image className="w-5 h-5" />;
    return <File className="w-5 h-5" />;
  };

  const filteredFiles = files.filter(file =>
    file.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <FolderOpen className="w-8 h-8 text-blue-600" />
              File Management
            </h1>
            <Badge className="px-4 py-2 bg-blue-100 text-blue-800">
              {files.length} Files
            </Badge>
          </div>
          <p className="text-gray-600">
            Upload, manage, and organize your website assets. Get direct URLs for use in your site.
          </p>
        </div>

        {/* Upload Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5" />
              Upload New File
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Upload your files
              </h3>
              <p className="text-gray-600 mb-4">
                Drag and drop files here, or click to select files
              </p>
              <input
                type="file"
                onChange={handleFileUpload}
                disabled={isUploading}
                className="hidden"
                id="file-upload"
                accept="image/*,.pdf,.doc,.docx"
              />
              <label htmlFor="file-upload">
                <Button 
                  className="cursor-pointer"
                  disabled={isUploading}
                  asChild
                >
                  <span>
                    {isUploading ? 'Uploading...' : 'Choose File'}
                  </span>
                </Button>
              </label>
            </div>
            
            {uploadStatus && (
              <div className={`mt-4 p-4 rounded-lg flex items-center gap-2 ${
                uploadStatus.type === 'success' 
                  ? 'bg-green-100 text-green-800' 
                  : 'bg-red-100 text-red-800'
              }`}>
                {uploadStatus.type === 'success' ? 
                  <CheckCircle2 className="w-5 h-5" /> : 
                  <AlertCircle className="w-5 h-5" />
                }
                {uploadStatus.message}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Files Table */}
        <Card className="mb-6">
          <CardHeader className="flex flex-row justify-between items-center space-y-0 pb-2">
            <CardTitle>Uploaded Files</CardTitle>
            <div className="relative w-full max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
              <Input
                type="search"
                placeholder="Search files..."
                className="pl-9"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent className="p-0"> {/* Adjusted padding */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left text-gray-500">
                <thead className="text-xs text-gray-700 uppercase bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 min-w-[250px]">File</th>
                    <th scope="col" className="px-6 py-3">Used In</th>
                    <th scope="col" className="px-6 py-3">Uploaded</th>
                    <th scope="col" className="px-6 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredFiles.length > 0 ? (
                    filteredFiles.map((file) => (
                      <tr key={file.id} className="bg-white border-b hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-4">
                            {file.type.startsWith("image/") ? (
                              <img
                                src={file.url}
                                alt={file.name}
                                className="w-16 h-10 object-cover rounded-md bg-gray-100 border"
                                onError={(e) => {
                                  e.target.onerror = null; 
                                  e.target.src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='12' r='10'/%3E%3Cline x1='12' y1='8' x2='12' y2='12'/%3E%3Cline x1='12' y1='16' x2='12.01' y2='16'/%3E%3C/svg%3E";
                                  e.target.className="p-2 w-16 h-10 text-red-400 bg-red-50 border-red-200 rounded-md";
                                }}
                              />
                            ) : (
                              <div className="w-16 h-10 flex items-center justify-center bg-gray-100 rounded-md border">
                                {getFileIcon(file.type)}
                              </div>
                            )}
                            <div>
                              <div className="font-medium text-gray-900">{file.name}</div>
                              <div className="text-gray-500">{file.size}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-1">
                            {file.usedIn.map((item, index) => (
                              <Badge key={index} variant="secondary" className="whitespace-nowrap">{item}</Badge>
                            ))}
                          </div>
                        </td>
                        <td className="px-6 py-4 text-gray-600">
                          {new Date(file.uploadedAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <Button variant="ghost" size="icon" onClick={() => copyToClipboard(file.url)} title="Copy URL">
                              <Copy className="w-4 h-4" />
                            </Button>
                            <a href={file.url} target="_blank" rel="noopener noreferrer">
                              <Button variant="ghost" size="icon" title="View File">
                                <Eye className="w-4 h-4" />
                              </Button>
                            </a>
                            <Button variant="ghost" size="icon" className="text-red-500 hover:text-red-700" title="Delete File">
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="4" className="text-center py-8 text-gray-500">
                        <FolderOpen className="w-10 h-10 text-gray-400 mx-auto mb-2" />
                        <h3 className="text-lg font-semibold text-gray-900 mb-1">
                          No files found
                        </h3>
                        <p className="text-sm">
                          {searchTerm ? 'Try adjusting your search terms.' : 'Upload your first file to get started.'}
                        </p>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
