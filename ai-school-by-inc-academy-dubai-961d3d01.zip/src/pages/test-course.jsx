import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, DollarSign, Zap } from "lucide-react";
import PaymentButton from "../components/common/PaymentButton";

export default function TestCourse() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <Badge className="mb-4 bg-red-100 text-red-700 border-red-200">
            <Zap className="w-4 h-4 mr-2" />
            TEST COURSE - $1 ONLY
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            AI Testing Course
            <span className="text-blue-600 block mt-2">System Integration Test</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            This is a test course for $1 to verify the payment system, webhooks, and enrollment process.
            Not for public use.
          </p>
        </div>

        {/* Pricing Card */}
        <div className="max-w-md mx-auto">
          <Card className="border-2 border-blue-200 shadow-xl">
            <CardHeader className="text-center bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-t-lg">
              <CardTitle className="text-2xl font-bold flex items-center justify-center gap-2">
                <DollarSign className="w-6 h-6" />
                Test Course
              </CardTitle>
              <div className="text-4xl font-bold mt-2">$1</div>
              <p className="text-blue-100">One-time payment</p>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-3 mb-6">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">Payment system testing</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">Webhook verification</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">Email notifications</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">Database enrollment</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">Pre-payment form testing</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-green-500" />
                  <span className="text-gray-700">Account dashboard access</span>
                </div>
              </div>

              <PaymentButton
                courseType="test-course"
                courseName="Test Course - System Verification"
                price="1"
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white py-3 text-lg font-semibold rounded-lg shadow-lg"
              >
                Pay $1 - Test Complete Flow
              </PaymentButton>

              <div className="mt-4 text-center">
                <p className="text-xs text-gray-500">
                  🔒 Secure payment powered by Stripe<br />
                  This is a test transaction for system verification
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Warning Notice */}
        <div className="mt-8 max-w-2xl mx-auto">
          <Card className="bg-yellow-50 border-yellow-200">
            <CardContent className="p-4 text-center">
              <p className="text-yellow-800 font-medium">
                ⚠️ This is a test course for system verification only
              </p>
              <p className="text-yellow-700 text-sm mt-1">
                Complete flow test: Form → Stripe → Account Dashboard
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Flow Explanation */}
        <div className="mt-8 max-w-3xl mx-auto">
          <Card className="bg-blue-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-lg text-blue-900">Test Flow Steps:</CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="list-decimal list-inside space-y-2 text-blue-800">
                <li>Click "Pay $1" button above</li>
                <li>Fill out the pre-payment form with your details</li>
                <li>Get redirected to Stripe checkout</li>
                <li>Complete the $1 test payment</li>
                <li>Get redirected to your account dashboard</li>
                <li>View your enrolled test course</li>
                <li>Check your email for confirmation</li>
              </ol>
              <p className="text-blue-700 text-sm mt-4">
                This tests the complete enrollment flow including form collection, payment processing, 
                webhook handling, database storage, email notifications, and account access.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}