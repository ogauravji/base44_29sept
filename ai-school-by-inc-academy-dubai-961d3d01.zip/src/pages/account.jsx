import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  User, 
  Mail, 
  Phone, 
  Building, 
  Briefcase, 
  Globe,
  BookOpen, 
  CheckCircle2, 
  Clock,
  AlertCircle,
  Eye,
  EyeOff
} from "lucide-react";
import { Enrollment } from "@/api/entities";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AccountPage() {
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [showLogin, setShowLogin] = useState(true);
  const [enrollments, setEnrollments] = useState([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [userInfo, setUserInfo] = useState(null);

  // Check for URL parameters and pending enrollment
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const enrolled = urlParams.get('enrolled');
    const paymentStatus = urlParams.get('payment');

    if (enrolled === 'true') {
      setMessage({ type: 'success', text: 'Payment successful! Your enrollment has been confirmed.' });
    } else if (paymentStatus === 'cancelled') {
      setMessage({ type: 'error', text: 'Payment was cancelled. You can try again anytime.' });
    }

    // Check if user data is stored from previous session
    const storedUser = localStorage.getItem('userAccount');
    if (storedUser) {
      try {
        const userData = JSON.parse(storedUser);
        setUserInfo(userData);
        setEmail(userData.email);
        setPhone(userData.phone);
        setIsLoggedIn(true);
        loadEnrollments(userData.email, userData.phone);
      } catch (error) {
        console.error('Failed to load stored user data:', error);
      }
    }
  }, []);

  const loadEnrollments = async (userEmail, userPhone) => {
    setLoading(true);
    try {
      // Try to find enrollments by email or phone
      const emailEnrollments = await Enrollment.filter({ user_email: userEmail });
      const phoneEnrollments = await Enrollment.filter({ phone_number: userPhone });
      
      // Combine and deduplicate enrollments
      const allEnrollments = [...emailEnrollments, ...phoneEnrollments];
      const uniqueEnrollments = allEnrollments.filter((enrollment, index, self) => 
        index === self.findIndex(e => e.stripe_session_id === enrollment.stripe_session_id)
      );
      
      setEnrollments(uniqueEnrollments);
    } catch (error) {
      console.error('Failed to load enrollments:', error);
      setMessage({ type: 'error', text: 'Failed to load your courses. Please try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    if (!email.trim() || !phone.trim()) {
      setMessage({ type: 'error', text: 'Please enter both email and phone number.' });
      return;
    }

    setLoading(true);
    try {
      await loadEnrollments(email.trim(), phone.trim());
      
      // Store user info
      const userData = { email: email.trim(), phone: phone.trim() };
      localStorage.setItem('userAccount', JSON.stringify(userData));
      setUserInfo(userData);
      setIsLoggedIn(true);
      setMessage({ type: 'success', text: 'Logged in successfully!' });
    } catch (error) {
      setMessage({ type: 'error', text: 'Login failed. Please check your details and try again.' });
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('userAccount');
    localStorage.removeItem('pendingEnrollment');
    setIsLoggedIn(false);
    setUserInfo(null);
    setEnrollments([]);
    setEmail("");
    setPhone("");
    setMessage("");
  };

  const getCourseDetails = (courseType) => {
    const courses = {
      'mastermind-session': { 
        name: '3 Hour AI Mastermind', 
        description: 'AI Skills to 10x Your Career in 2025',
        color: 'bg-yellow-100 text-yellow-800'
      },
      'online-cohort': { 
        name: 'Level 1: AI Foundation', 
        description: 'Complete AI Training for Business Professionals',
        color: 'bg-blue-100 text-blue-800'
      },
      'ai-accelerator': { 
        name: 'Level 2: AI Accelerator', 
        description: 'Build Custom AI Systems & Automation',
        color: 'bg-purple-100 text-purple-800'
      },
      'complete-bundle': { 
        name: 'Complete AI Mastery Bundle', 
        description: 'All courses included with bonus content',
        color: 'bg-green-100 text-green-800'
      },
      'test-course': { 
        name: 'Test Course', 
        description: 'System verification course',
        color: 'bg-gray-100 text-gray-800'
      }
    };
    return courses[courseType] || { name: courseType, description: 'Course details', color: 'bg-gray-100 text-gray-800' };
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Access Your Account</h1>
            <p className="text-gray-600">Enter your details to view your enrolled courses</p>
          </div>

          {message && (
            <Alert className={`mb-6 ${message.type === 'error' ? 'border-red-200 bg-red-50' : 'border-green-200 bg-green-50'}`}>
              <AlertCircle className={`h-4 w-4 ${message.type === 'error' ? 'text-red-600' : 'text-green-600'}`} />
              <AlertDescription className={message.type === 'error' ? 'text-red-800' : 'text-green-800'}>
                {message.text}
              </AlertDescription>
            </Alert>
          )}

          <Card className="shadow-xl">
            <CardHeader>
              <CardTitle className="text-center flex items-center justify-center gap-2">
                <User className="w-5 h-5" />
                Login to Your Account
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label htmlFor="email" className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email Address
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your.email@company.com"
                    className="mt-1"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="phone" className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Phone Number
                  </Label>
                  <Input
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+971 50 123 4567"
                    className="mt-1"
                    required
                  />
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
                >
                  {loading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Logging in...
                    </>
                  ) : (
                    'Access My Courses'
                  )}
                </Button>
              </form>

              <div className="text-center mt-6 text-sm text-gray-600">
                <p>Use the same email and phone number you provided during enrollment.</p>
                <p className="mt-2">Need help? <a href="https://wa.me/971524371377" target="_blank" className="text-blue-600 hover:underline">Contact support</a></p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">My Learning Dashboard</h1>
            <p className="text-gray-600">Welcome back! Here are your enrolled courses.</p>
          </div>
          <Button variant="outline" onClick={handleLogout}>
            Logout
          </Button>
        </div>

        {message && (
          <Alert className={`mb-6 ${message.type === 'error' ? 'border-red-200 bg-red-50' : 'border-green-200 bg-green-50'}`}>
            <AlertCircle className={`h-4 w-4 ${message.type === 'error' ? 'text-red-600' : 'text-green-600'}`} />
            <AlertDescription className={message.type === 'error' ? 'text-red-800' : 'text-green-800'}>
              {message.text}
            </AlertDescription>
          </Alert>
        )}

        {/* User Info Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              Account Information
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-gray-500" />
                <span>{userInfo?.email}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-gray-500" />
                <span>{userInfo?.phone}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Enrollments */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-gray-900">My Courses</h2>
          
          {loading ? (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading your courses...</p>
              </CardContent>
            </Card>
          ) : enrollments.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center">
                <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No courses found</h3>
                <p className="text-gray-600 mb-4">You haven't enrolled in any courses yet.</p>
                <Link to={createPageUrl("ai-courses")}>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Browse Courses
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6">
              {enrollments.map((enrollment) => {
                const course = getCourseDetails(enrollment.course_type);
                const isCompleted = enrollment.payment_status === 'completed';
                
                return (
                  <Card key={enrollment.id} className="shadow-lg">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="flex items-center gap-2">
                            <BookOpen className="w-5 h-5" />
                            {course.name}
                          </CardTitle>
                          <p className="text-gray-600 mt-1">{course.description}</p>
                        </div>
                        <Badge className={course.color}>
                          {isCompleted ? (
                            <>
                              <CheckCircle2 className="w-3 h-3 mr-1" />
                              Enrolled
                            </>
                          ) : (
                            <>
                              <Clock className="w-3 h-3 mr-1" />
                              Pending
                            </>
                          )}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <p className="text-gray-500">Amount Paid</p>
                          <p className="font-semibold">
                            ${(enrollment.amount_paid / 100).toFixed(2)} {enrollment.currency?.toUpperCase()}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-500">Enrolled Date</p>
                          <p className="font-semibold">
                            {new Date(enrollment.created_date).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-500">Payment Status</p>
                          <p className={`font-semibold ${isCompleted ? 'text-green-600' : 'text-yellow-600'}`}>
                            {enrollment.payment_status}
                          </p>
                        </div>
                        <div>
                          <p className="text-gray-500">Customer Support</p>
                          <a 
                            href="https://wa.me/971524371377" 
                            target="_blank" 
                            className="text-blue-600 hover:underline"
                          >
                            WhatsApp Support
                          </a>
                        </div>
                      </div>

                      {isCompleted && (
                        <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                          <p className="text-green-800 font-medium">
                            🎉 Enrollment confirmed! Our team will contact you within 24 hours with course details and next steps.
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}