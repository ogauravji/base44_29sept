
import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { BlogPost as BlogPostEntity } from "@/api/entities";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Calendar, User, Share2, Facebook, Twitter, Linkedin } from "lucide-react";
import { createPageUrl } from "@/utils";

export default function BlogPost() {
    const { slug } = useParams();
    const [blogPost, setBlogPost] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const loadBlogPost = async () => {
            try {
                const posts = await BlogPostEntity.filter({ slug, published: true });
                if (posts.length === 0) {
                    setError('Blog post not found');
                    return;
                }
                
                const post = posts[0];
                setBlogPost(post);
                
                // Update page meta
                document.title = `${post.title} | Inc Academy Blog`;
                const metaDesc = document.querySelector('meta[name="description"]') || document.createElement('meta');
                metaDesc.name = "description";
                metaDesc.content = post.excerpt;
                if (!document.querySelector('meta[name="description"]')) {
                    document.head.appendChild(metaDesc);
                }
            } catch (error) {
                console.error('Error loading blog post:', error);
                setError('Error loading blog post');
            } finally {
                setLoading(false);
            }
        };
        
        loadBlogPost();
    }, [slug]);

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    };

    const shareUrl = encodeURIComponent(window.location.href);
    const shareTitle = encodeURIComponent(blogPost?.title || '');

    if (loading) {
        return (
            <div className="min-h-screen bg-white flex items-center justify-center">
                <div className="text-center">
                    <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
                    <p className="text-gray-600">Loading article...</p>
                </div>
            </div>
        );
    }

    if (error || !blogPost) {
        return (
            <div className="min-h-screen bg-white flex items-center justify-center">
                <div className="text-center">
                    <h1 className="text-4xl font-bold text-gray-900 mb-4">404</h1>
                    <p className="text-xl text-gray-600 mb-8">{error || 'Blog post not found'}</p>
                    <Link to={createPageUrl("Blog")}>
                        <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                            <ArrowLeft className="w-4 h-4 mr-2" />
                            Back to Blog
                        </Button>
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <article className="min-h-screen bg-white">
            {/* Hero Section */}
            <section className="relative py-16 px-4 sm:px-6 lg:px-8">
                <div className="max-w-4xl mx-auto">
                    <Link to={createPageUrl("Blog")} className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-8">
                        <ArrowLeft className="w-4 h-4 mr-2" />
                        Back to Blog
                    </Link>

                    <div className="text-center mb-8">
                        <div className="flex items-center justify-center gap-4 mb-6">
                            <Badge variant="secondary">{blogPost.category}</Badge>
                            {blogPost.featured && <Badge>Featured</Badge>}
                            <div className="flex items-center gap-2 text-gray-500">
                                <Calendar className="w-4 h-4" />
                                {formatDate(blogPost.created_date)}
                            </div>
                        </div>
                        
                        <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-6 leading-tight">
                            {blogPost.title}
                        </h1>
                        
                        <p className="text-xl text-gray-600 leading-relaxed max-w-3xl mx-auto">
                            {blogPost.excerpt}
                        </p>
                    </div>

                    {/* Featured Image */}
                    <div className="aspect-[16/9] rounded-2xl overflow-hidden mb-12 shadow-xl">
                        <img
                            src={blogPost.image}
                            alt={blogPost.title}
                            className="w-full h-full object-cover"
                        />
                    </div>
                </div>
            </section>

            {/* Content */}
            <section className="pb-16 px-4 sm:px-6 lg:px-8">
                <div className="max-w-4xl mx-auto">
                    <div className="grid lg:grid-cols-4 gap-8">
                        {/* Share Sidebar */}
                        <div className="lg:col-span-1 order-2 lg:order-1">
                            <div className="sticky top-8">
                                <h3 className="text-sm font-semibold text-gray-900 mb-4">Share Article</h3>
                                <div className="space-y-3">
                                    <a
                                        href={`https://twitter.com/intent/tweet?text=${shareTitle}&url=${shareUrl}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
                                    >
                                        <Twitter className="w-5 h-5 text-blue-400" />
                                        <span className="text-sm text-gray-700">Twitter</span>
                                    </a>
                                    
                                    <a
                                        href={`https://www.linkedin.com/sharing/share-offsite/?url=${shareUrl}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
                                    >
                                        <Linkedin className="w-5 h-5 text-blue-600" />
                                        <span className="text-sm text-gray-700">LinkedIn</span>
                                    </a>
                                    
                                    <a
                                        href={`https://www.facebook.com/sharer/sharer.php?u=${shareUrl}`}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors"
                                    >
                                        <Facebook className="w-5 h-5 text-blue-800" />
                                        <span className="text-sm text-gray-700">Facebook</span>
                                    </a>
                                </div>
                            </div>
                        </div>

                        {/* Main Content */}
                        <div className="lg:col-span-3 order-1 lg:order-2">
                            <div 
                                className="prose prose-lg prose-blue max-w-none"
                                dangerouslySetInnerHTML={{ __html: blogPost.content }}
                                style={{
                                    lineHeight: '1.8',
                                }}
                            />
                            
                            {/* Tags */}
                            {blogPost.tags && (
                                <div className="mt-12 pt-8 border-t border-gray-200">
                                    <h3 className="text-lg font-semibold text-gray-900 mb-4">Tags</h3>
                                    <div className="flex flex-wrap gap-2">
                                        {blogPost.tags.split(',').map((tag, index) => (
                                            <Badge key={index} variant="outline" className="text-sm">
                                                {tag.trim()}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </section>

            {/* Newsletter CTA */}
            <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-purple-600">
                <div className="max-w-2xl mx-auto text-center text-white">
                    <h3 className="text-2xl md:text-3xl font-bold mb-4">
                        Want More AI Insights?
                    </h3>
                    <p className="text-blue-100 mb-8 text-lg">
                        Subscribe to our newsletter for weekly AI marketing tips and industry updates
                    </p>
                    <Link to={createPageUrl("Blog")}>
                        <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 font-semibold">
                            Subscribe to Newsletter
                        </Button>
                    </Link>
                </div>
            </section>
        </article>
    );
}
