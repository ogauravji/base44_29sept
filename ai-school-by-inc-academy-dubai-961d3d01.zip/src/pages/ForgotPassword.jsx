
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Mail, ArrowLeft, CheckCircle } from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function ForgotPassword() {
    const [email, setEmail] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSubmitted, setIsSubmitted] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);
        setError('');

        try {
            const response = await fetch('https://base44.app/api/apps/68947005b6a22444961d3d01/functions/requestPasswordResetSimple', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email })
            });

            const data = await response.json();
            
            if (data.success) {
                setIsSubmitted(true);
            } else {
                setError(data.error || 'Failed to send reset email');
            }
        } catch (error) {
            console.error('Password reset error:', error);
            setError('Network error. Please try again.');
        } finally {
            setIsSubmitting(false);
        }
    };

    if (isSubmitted) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50 flex items-center justify-center p-4">
                <Card className="w-full max-w-md shadow-2xl border-0 rounded-3xl overflow-hidden">
                    <CardContent className="p-8 text-center">
                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                            <CheckCircle className="w-8 h-8 text-green-600" />
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-4">Check Your Email</h2>
                        <p className="text-gray-600 mb-8">
                            We've sent password reset instructions to <strong>{email}</strong>.
                            Check your inbox and click the reset link.
                        </p>
                        
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
                            <h3 className="font-semibold text-blue-800 mb-2">What's next?</h3>
                            <ul className="text-sm text-blue-700 text-left space-y-1">
                                <li>• Check your email (including spam folder)</li>
                                <li>• Click the "Reset Password" button</li>
                                <li>• Create a new secure password</li>
                                <li>• Log in with your new password</li>
                            </ul>
                        </div>

                        <Link to={createPageUrl('AffiliateLogin')}>
                            <Button variant="outline" className="w-full">
                                <ArrowLeft className="w-4 h-4 mr-2" />
                                Back to Login
                            </Button>
                        </Link>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
            {/* Header */}
            <div className="bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white py-16">
                <div className="max-w-4xl mx-auto px-4 text-center">
                    <h1 className="text-4xl md:text-5xl font-bold mb-4">
                        Forgot Your Password?
                    </h1>
                    <p className="text-xl text-blue-100">
                        No worries! We'll help you reset it.
                    </p>
                </div>
            </div>

            {/* Form */}
            <div className="flex items-center justify-center py-16 px-4">
                <Card className="w-full max-w-md shadow-2xl border-0 rounded-3xl overflow-hidden">
                    <CardHeader className="text-center pb-6">
                        <div className="w-16 h-16 bg-purple-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
                            <Mail className="w-8 h-8 text-purple-600" />
                        </div>
                        <CardTitle className="text-2xl font-bold text-gray-900">
                            Reset Password
                        </CardTitle>
                        <p className="text-gray-600">
                            Enter your email address and we'll send you a link to reset your password.
                        </p>
                    </CardHeader>

                    <CardContent className="p-8 pt-0">
                        {error && (
                            <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-6">
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleSubmit} className="space-y-6">
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-2">
                                    Email Address
                                </label>
                                <Input
                                    type="email"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                    className="h-12"
                                    placeholder="Enter your email address"
                                    disabled={isSubmitting}
                                />
                            </div>

                            <Button
                                type="submit"
                                disabled={isSubmitting || !email}
                                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-3 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                            >
                                {isSubmitting ? 'Sending...' : 'Send Reset Link'}
                            </Button>
                        </form>

                        <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                            <p className="text-gray-600 mb-4">
                                Remember your password?
                            </p>
                            <Link to={createPageUrl('AffiliateLogin')}>
                                <Button variant="outline" className="w-full">
                                    <ArrowLeft className="w-4 h-4 mr-2" />
                                    Back to Login
                                </Button>
                            </Link>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
