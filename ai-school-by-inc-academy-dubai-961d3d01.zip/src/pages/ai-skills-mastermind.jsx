
import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import PaymentButton from '@/components/common/PaymentButton';
import StripePaymentLinkButton from '@/components/common/StripePaymentLinkButton';
import BookingSection from "../components/landing/BookingSection"; // Added import
import {
  Calendar, Clock, Monitor, Target, CheckCircle2, TrendingUp, Briefcase, Rocket, Users, Award, Star, ArrowRight,
  BrainCircuit, AlertTriangle, DollarSign, Shield, BookOpen, UserCheck, BarChart3, PenSquare, Building, Eye, Zap,
  Crown, Brain, Globe, MessageCircle, Sparkles, Lightbulb, ChevronUp, ChevronDown, Code, Settings, Languages,
  Timer, Coffee, PlayCircle, Gift, Mail, X
} from
  "lucide-react";
import { motion } from "framer-motion";

const StickyCTA = ({ courseType, price }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 800) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener('scroll', toggleVisibility);
    return () => window.removeEventListener('scroll', toggleVisibility);
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200 shadow-lg p-4">
      <div className="max-w-md mx-auto">
        <PaymentButton
          courseType={courseType}
          courseName="3 Hour AI Mastermind"
          price={price}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white py-4 text-lg font-bold rounded-xl shadow-lg">
          Reserve My Seat – ${price}
        </PaymentButton>
      </div>
    </div>);
};

const clientLogos = [
  { src: "https://i.imghippo.com/files/AIj7022XwI.png", alt: "Google" },
  { src: "https://i.imghippo.com/files/BtVJ7689eU.png", alt: "TikTok" },
  { src: "https://i.imghippo.com/files/zETQ9249BY.png", alt: "Dubai Tourism" },
  { src: "https://i.imghippo.com/files/LjWL1133fc.png", alt: "Emirates" },
  { src: "https://i.imghippo.com/files/RymB7570vQ.png", alt: "Alshaya" },
  { src: "https://i.imghippo.com/files/IPE5684MnM.png", alt: "Unilever" },
  { src: "https://i.imghippo.com/files/QUIK6243XI.png", alt: "Etihad" },
  { src: "https://i.imghippo.com/files/CBg5407ZEg.png", alt: "Harvard Business School" }];


const extendedClientLogos = [
  { src: "https://i.imghippo.com/files/AIj7022XwI.png", alt: "Google" },
  { src: "https://i.imghippo.com/files/BtVJ7689eU.png", alt: "TikTok" },
  { src: "https://i.imghippo.com/files/zETQ9249BY.png", alt: "Dubai Tourism" },
  { src: "https://i.imghippo.com/files/LjWL1133fc.png", alt: "Emirates" },
  { src: "https://i.imghippo.com/files/RymB7570vQ.png", alt: "Alshaya" },
  { src: "https://i.imghippo.com/files/IPE5684MnM.png", alt: "Unilever" },
  { src: "https://i.imghippo.com/files/dTP1846OjI.png", alt: "Costa" },
  { src: "https://i.imghippo.com/files/VvM5469Vlk.png", alt: "Benefit San Francisco" },
  { src: "https://i.imghippo.com/files/LjWL1133fc.png", alt: "Emirates" },
  { src: "https://i.imghippo.com/files/jzNj8266As.png", alt: "Dabur" },
  { src: "https://i.imghippo.com/files/gXgl2743rNE.jpg", alt: "Omega" },
  { src: "https://i.imghippo.com/files/AOfh2966ai.png", alt: "Louis Vuitton" },
  { src: "https://i.imghippo.com/files/lQOb6907.png", alt: "L'Occitane" },
  { src: "https://i.imghippo.com/files/SW6271PSQ.png", alt: "Marriott International" },
  { src: "https://i.imghippo.com/files/kdg3153Rvs.png", alt: "Mediclinic" },
  { src: "https://i.imghippo.com/files/DhMp4148JnA.png", alt: "PepsiCo" },
  { src: "https://i.imghippo.com/files/ZK2223nTY.png", alt: "Tiffany & Co" },
  { src: "https://i.imghippo.com/files/JJ2372rkU.png", alt: "Dubai Police" },
  { src: "https://i.imghippo.com/files/uSu3907oa.png", alt: "Saudi" },
  { src: "https://i.imghippo.com/files/gxlF3416rog.png", alt: "Bentley" },
  { src: "https://i.imghippo.com/files/acD3507lU.png", alt: "Samsung" },
  { src: "https://i.imghippo.com/files/Oto7651q.png", alt: "Land Rover Jaguar" },
  { src: "https://i.imghippo.com/files/uxF2602Oo.png", alt: "McDonald's" },
  { src: "https://i.imghippo.com/files/XX8732wJ.png", alt: "Fly Dubai" }];


const painPoints = [
  {
    icon: Clock,
    title: "Struggling to keep up with AI changes?",
    description: "New AI tools launch daily. Feel overwhelmed by the pace?",
    image: "https://i.imghippo.com/files/VT2668B.png"
  },
  {
    icon: Timer,
    title: "Spending hours on tasks AI can do in minutes?",
    description: "Manual work eating your time while competitors automate?",
    image: "https://i.imghippo.com/files/YOlI8472Ug.webp"
  },
  {
    icon: Target,
    title: "Unsure how to apply AI in YOUR industry?",
    description: "Generic advice doesn't fit your specific business needs?",
    image: "https://i.imghippo.com/files/WGx2240ZBE.png"
  }];


const agenda = [
  { icon: BrainCircuit, title: "Module 1: Mastering ChatGPT and 15+ AI Tools", description: "Learn the magic prompt formula to unlock ChatGPT's full power and discover 15+ AI tools that supercharge productivity across business and personal workflows." },
  { icon: BarChart3, title: "Module 2: Data Analysis Made Simple with AI", description: "Transform raw data into insights using ChatGPT's advanced analysis features. Decode market trends, competitor moves, and consumer behavior without coding or complex statistics." },
  { icon: PenSquare, title: "Module 3: AI for High-Impact Content Creation", description: "Automate repetitive tasks like social posts and email campaigns while personalizing content for your audience. Spot trending topics and deliver timely, engaging content at scale." },
  { icon: Eye, title: "Module 4: Present Smarter with AI-Powered Slides", description: "Turn data into compelling presentations with AI. Create visuals, narratives, and real-time analytics that make your message clear, persuasive, and memorable." },
  { icon: UserCheck, title: "Module 5: Get hired faster with AI", description: "Use AI to fast-track your career. Discover tailored job opportunities, optimize your resume and applications, and get guidance for upskilling and advancement." },
  { icon: BookOpen, title: "Module 6: 10x Faster Reading and Research with AI", description: "Leverage AI's multimodal capabilities to summarize long documents, analyze visuals and charts, and integrate APIs into workflows for instant, actionable insights." },
  { icon: Crown, title: "Module 7: Build Personal Brand with AI", description: "Build a consistent and authentic brand presence online. Automate engagement, publish thought-leadership content, and amplify your expertise with AI." },
  { icon: PlayCircle, title: "Module 8: Exploring AI's Audio and Video Power", description: "Create professional-grade videos, voiceovers, and localized campaigns using advanced AI platforms. Scale global storytelling with audio-visual AI innovation." },
  { icon: Rocket, title: "Module 9: The AI Roadmap for Your Future", description: "Connect all the modules into a practical roadmap. Learn how to apply AI skills in sequence to build long-term career impact, drive business growth, and stay ahead of industry shifts." }
];


const targetAudience = [
  { icon: Crown, title: "C-Level Executives", subtitle: "Make AI-Powered Strategic Decisions", description: "CEOs, CMOs, and senior leaders who need to understand AI's strategic impact on business transformation" },
  { icon: Briefcase, title: "Marketing Professionals", subtitle: "Automate Content & Campaigns with AI", description: "Marketing managers, specialists, and directors looking to leverage AI tools for campaign optimization" },
  { icon: TrendingUp, title: "Business Owners", subtitle: "Save 10+ Hours/Week with AI Workflows", description: "Entrepreneurs and SME owners wanting to automate and scale their operations efficiently" },
  { icon: Users, title: "HR & Operations", subtitle: "Streamline Processes with AI Automation", description: "HR managers and operations professionals seeking efficiency through intelligent automation" },
  { icon: Target, title: "Consultants & Freelancers", subtitle: "Offer AI-Enhanced Services to Clients", description: "Independent professionals who want to differentiate with AI-powered solutions" },
  { icon: Building, title: "Sales Teams", subtitle: "Generate More Leads with AI Insights", description: "Sales professionals looking to use AI for lead generation and customer intelligence" }];


const faqsData = {
  'General & Logistics': [
    {
      q: "If I miss this, can I join the next one?",
      a: "Yes. Register again for the next scheduled cohort. Dates and times are on the landing page. We also send reminders on WhatsApp and email."
    },
    {
      q: "When does the workshop start?",
      a: "See the date and time at the top of the page."
    },
    {
      q: "Is this a live session?",
      a: "Yes. Live instructor-led online. Expect interaction, polls, quizzes, and practical exercises. You leave with a clear roadmap."
    },
    {
      q: "I paid but did not get an email.",
      a: "Email hello@inc.academy. Support replies within 12 hours."
    },
    {
      q: "What makes this different from other AI courses?",
      a: "This 3-hour intensive focuses on practical AI for productivity and career transformation. You'll learn Generative AI tools and AI workflow automation techniques that you can implement immediately as an AI generalist."
    }
  ],

  'Session Details': [
    {
      q: "Can I ask questions to the mentor during the session?",
      a: "Yes. There is a dedicated live Q&A segment for real-time questions and interaction."
    },
    {
      q: "Why can't I watch it anytime I want?",
      a: "On-demand courses have low completion rates. Our live, time-boxed format with polls, quizzes, and chat drives accountability and completion. Internal experiments increased completion from 2–3% to about 90%. Commit to the window and finish."
    },
    {
      q: "Can I record the session for personal use?",
      a: "No. Inc Academy owns the content. Recording is prohibited and may lead to legal action. Best practice: take notes or create a mind map and share insights with the community."
    },
    {
      q: "Will I get recordings of the sessions?",
      a: "No. Sessions are time-gated by design to reduce procrastination and drive action. Attend live and complete within the window."
    },
    {
      q: "Is this suitable for beginners?",
      a: "Absolutely! This AI strategy course is designed for professionals with no AI background. Perfect for executives, managers, and business leaders who want to understand AI for business applications."
    }
  ],

  'Pricing & Bonuses': [
    {
      q: "Why is the price so low?",
      a: "We optimize for scale. Mentors are top 1% talent with limited time. The format lets many learners access elite instruction at a low per-person cost."
    },
    {
      q: "When do I receive the bonuses?",
      a: "During the live sessions."
    },
    {
      q: "Do you have an affiliate program?",
      a: "Yes. It is available only to workshop participants."
    },
    {
      q: "What's your refund policy?",
      a: "We do not offer refunds. However, we understand that plans can change. If you're unable to attend, you can transfer your seat to a colleague or reschedule to a future session with at least 24 hours' notice."
    },
    {
      q: "Can I transfer my enrollment?",
      a: "Yes, you can transfer your seat to another person or reschedule to a future cohort with at least 24 hours notice."
    }
  ],

  'Outcomes & Certificates': [
    {
      q: "Will I make a lot of money after this workshop?",
      a: "No guarantees. The workshop streamlines AI strategy so you can generate leads, build a personal brand, or access better opportunities."
    },
    {
      q: "Do I get a certificate?",
      a: "Yes. Issued on completion."
    },
    {
      q: "What outcomes can I expect immediately?",
      a: "You'll leave with 5+ working AI tools, proven prompting frameworks, and practical AI automation strategies you can implement in your work right away."
    },
    {
      q: "How does this prepare me for advanced AI training?",
      a: "This mastermind is the perfect introduction to our comprehensive AI for corporate training programs, giving you the foundation for Level 1 and Level 2 courses."
    }
  ]
};

const testimonials = [
  {
    quote: "Gaurav's sessions are a game changer. I walked away with AI skills I could apply the same day. This is the best introduction to AI for business I've seen.",
    author: "Sarah M.",
    role: "Marketing Director, GCC"
  },
  {
    quote: "We automated 40% of our reporting workflow after just one training. The hands-on approach makes it easy to understand and implement.",
    author: "Ahmed K.",
    role: "Founder, E-Com Brand"
  },
  {
    quote: "Mr Oberoi is one of the top educators. Industries, alumni, and professionals witness his outstanding excellence in the field. I strongly recommend Mr. Oberoi since I know for a fact that he demonstrated expertise.",
    author: "Aisha S.",
    role: "Special Projects, Global University"
  },
  {
    quote: "Gaurav has this impeccable ability to translate complex topics into simple relatable examples. I strongly recommend.",
    author: "Barkha G.",
    role: "Global Head of Ecommerce, FMCG"
  },
  {
    quote: "One of the most informative and enjoyable trainings I have attended in a while. Gaurav keeps it light on the mind and on the heart which makes for fun learning. My eyes have been opened to a whole new world by this man.",
    author: "Omar G.",
    role: "Head of Development, Retail"
  },
  {
    quote: "Gaurav Oberoi One of the professional leaders in the field, I attended him a course of courses that have been able to learn hidden in the past. Capable, leader, expert",
    author: "Meshal A.",
    role: "Government Office, KSA"
  }];

const courseFeatures = [
  "3 Hours of Intensive, Hands-On AI Training",
  "$100 Bonus AI Toolkit & Prompt Library",
  "Official Certificate of Completion",
  "Lifetime Access to AI Professionals Community",
];

export default function AISkillsMastermind() {
  const [activeFAQCategory, setActiveFAQCategory] = useState('General & Logistics');
  const [openFAQ, setOpenFAQ] = useState(0);
  const offerEndDate = new Date();
  offerEndDate.setDate(offerEndDate.getDate() + 6); // Set for 6 days from now for countdown

  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "AI Skills Mastermind for Leaders | Dubai & GCC";
    const description = "Cohort for founders and business heads to operationalize AI. Weekly sprints, playbooks, and accountability to deploy automations, agents, and KPIs across functions.";
    const keywords = "AI mastermind Dubai, AI leadership cohort UAE, AI for executives GCC, AI adoption program Dubai, AI sprints, AI playbooks, AI transformation UAE, AI accountability group";
    const imageUrl = "https://i.imghippo.com/files/tfUo2263Io.png";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('name', 'keywords', keywords);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);

    // Schema.org structured data
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Course",
      "name": "AI Skills Mastermind for Leaders",
      "description": description,
      "provider": {
        "@type": "Organization",
        "name": "Inc Academy",
        "url": "https://ai.inc.academy"
      },
      "courseMode": "online",
      "educationalLevel": "advanced"
    });
    document.head.appendChild(script);

    return () => {
      // Clean up Schema.org script on unmount if necessary, though not strictly required for SPA changes
      // script.remove();
    };
  }, []);

  // Removed scrollToBooking as it's no longer used for the new BookingSection component

  return (
    <div className="min-h-screen bg-white overflow-x-hidden font-inter">
      <StickyCTA courseType="mastermind-session" price={99} />

      {/* Hero Section */}
      <section className="relative bg-slate-900 text-white overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-[#1E40AF] to-slate-900"></div>
        <div className="absolute inset-0 bg-black/20"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="text-center lg:text-left">

              <div className="flex flex-wrap gap-2 sm:gap-3 justify-center lg:justify-start mb-6">
                <Badge className="bg-blue-600 text-white px-3 py-1 text-sm font-bold hover:bg-blue-700 transition-colors">
                  Professional Training
                </Badge>
                <Badge className="bg-white/20 text-white px-3 py-1 text-sm font-semibold border border-white/30 hover:bg-white hover:text-slate-900 transition-all">
                  Limited Seats
                </Badge>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-4 leading-tight text-white">
                AI Skills to 10x Your Career in 2025
              </h1>
              <p className="text-xl sm:text-2xl text-slate-200 mb-6 font-medium">
                3 Hours AI Mastermind: Saturday October 4th, 2025
              </p>

              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 sm:p-6 mb-8 border border-white/20">
                <div className="grid sm:grid-cols-3 gap-4 mb-6 justify-items-center">
                  <div className="flex items-center gap-2 text-green-300">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                    <span className="text-sm font-medium">Live Online Training</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-300">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                    <span className="text-sm font-medium">Hands-On AI Tools</span>
                  </div>
                  <div className="flex items-center gap-2 text-green-300">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                    <span className="text-sm font-medium">$100 Bonus Pack Included</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3 sm:gap-4 mb-4">
                  <span className="text-2xl sm:text-3xl text-slate-400 line-through">$250</span>
                  <span className="text-4xl sm:text-5xl font-black text-white">$99</span>
                  <Badge className="bg-red-500 text-white font-bold text-sm px-3 py-1 animate-pulse">Limited Time Offer</Badge>
                </div>
                <p className="text-sm text-slate-300">One-time investment in your AI future</p>
              </div>

              <PaymentButton
                courseType="mastermind-session"
                courseName="3 Hour AI Mastermind"
                price={99}
                size="lg"
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-xl font-bold rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300">
                Reserve Your Seat - $99
              </PaymentButton>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative">

              <img
                src="https://i.imghippo.com/files/Unq7422Q.png"
                alt="AI Skills Mastermind - Transform your career with AI"
                className="rounded-2xl shadow-2xl w-full" />

            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-8 sm:py-12 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8">
            <p className="text-lg font-semibold text-slate-600 mb-6">
              Trusted by professionals from leading organizations
            </p>
          </div>
          <div className="bg-white rounded-2xl shadow-lg p-6 sm:p-8">
            <div className="grid grid-cols-4 md:grid-cols-8 gap-6 sm:gap-8 items-center justify-items-center">
              {clientLogos.map((client, index) =>
                <img
                  key={index}
                  src={client.src}
                  alt={client.alt}
                  className="max-h-8 sm:max-h-12 w-auto opacity-60 hover:opacity-100 transition-opacity grayscale hover:grayscale-0" />

              )}
            </div>
          </div>
        </div>
      </section>

      {/* Pain Points Section - Enhanced */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-blue-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-3 text-base font-semibold mb-6 hover:bg-blue-600 hover:text-white transition-colors">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Common Pain Points
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 mb-6">
              Does This Sound Like You?
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {painPoints.map((point, index) =>
              <Card key={index} className="border-2 border-blue-200 bg-white shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300">
                <div className="relative h-48 overflow-hidden">
                  <img
                    src={point.image}
                    alt={point.title}
                    className="w-full h-full object-cover object-top" />

                  <div className="absolute inset-0 bg-gradient-to-t from-blue-800/80 to-transparent"></div>
                  <div className="absolute bottom-4 left-4">
                    <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
                      {React.createElement(point.icon, { className: "w-6 h-6 text-blue-600" })}
                    </div>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold text-slate-900 mb-3">
                    {point.title}
                  </h3>
                  <p className="text-slate-600 leading-relaxed">
                    {point.description}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="text-center">
            <PaymentButton
              courseType="mastermind-session"
              courseName="3 Hour AI Mastermind"
              price={99}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg mb-2">
              Reserve My Seat — $99
            </PaymentButton>
            <p className="text-sm text-blue-600 font-semibold">Limited seats — filling fast</p>
          </div>
        </div>
      </section>

      {/* Special Introductory Offer Section - Enhanced */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-10 right-10 w-96 h-96 bg-gradient-to-r from-blue-500/20 to-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-10 left-10 w-80 h-80 bg-gradient-to-r from-yellow-500/20 to-red-500/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }}></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-gradient-to-r from-green-500/10 to-blue-500/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '4s' }}></div>
        </div>

        {/* Grid Pattern Overlay (add to your global CSS if bg-grid-pattern is custom) */}
        {/* For demonstration, defining a simple pattern here if not already defined globally */}
        <style jsx>{`
          .bg-grid-pattern {
            background-image: linear-gradient(to right, rgba(255,255,255,0.05) 1px, transparent 1px),
                              linear-gradient(to bottom, rgba(255,255,255,0.05) 1px, transparent 1px);
            background-size: 20px 20px;
          }
        `}</style>
        <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>

        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-12">
            {/* Animated Badge */}
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center">
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-slate-900 px-8 py-4 text-lg font-bold mb-8 hover:from-yellow-300 hover:to-orange-400 transition-all duration-300 animate-bounce shadow-2xl border-0">
                <DollarSign className="w-6 h-6 mr-3" />
                🔥 LIMITED TIME: 60% OFF
              </Badge>
            </motion.div>

            {/* Main Heading */}
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black mb-8 leading-tight">
              <span className="block text-white mb-4">Special Introductory</span>
              <span className="bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 bg-clip-text text-transparent animate-pulse">
                Offer
              </span>
            </motion.h2>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-xl md:text-2xl text-blue-100 mb-12 max-w-4xl mx-auto leading-relaxed">
              Transform your career with professional AI training that delivers <span className="text-yellow-400 font-bold">real results</span>
            </motion.p>
          </div>

          {/* Offer Cards Grid */}
          <div className="grid lg:grid-cols-2 gap-8 mb-16">
            {/* Before Card */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative">
              <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10 h-full">
                <div className="text-center mb-8">
                  <div className="w-20 h-20 bg-gradient-to-r from-red-500 to-red-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                    <span className="text-3xl font-black text-white line-through">$250</span>
                  </div>
                  <h3 className="text-2xl font-bold text-red-400 mb-2">Regular Price</h3>
                  <p className="text-red-200">What others charge for basic AI courses</p>
                </div>

                <div className="space-y-4">
                  {[
                    "Generic AI overview",
                    "No hands-on practice",
                    "Limited industry focus",
                    "No take-home resources",
                    "Basic certificate only"].
                    map((item, index) =>
                      <div key={index} className="flex items-center gap-3 opacity-60">
                        <div className="w-6 h-6 bg-red-500/20 rounded-full flex items-center justify-center">
                          <X className="w-4 h-4 text-red-400" />
                        </div>
                        <span className="text-gray-300">{item}</span>
                      </div>
                    )}
                </div>
              </div>
            </motion.div>

            {/* After Card */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative">
              <div className="bg-gradient-to-br from-blue-600/20 via-green-600/20 to-yellow-600/20 backdrop-blur-sm rounded-3xl p-8 border-2 border-yellow-400/50 h-full shadow-2xl">
                {/* Premium Badge */}
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-gradient-to-r from-yellow-400 to-orange-400 text-slate-900 px-6 py-2 font-bold text-sm animate-pulse shadow-lg">
                    🚀 Sign Up Now
                  </Badge>
                </div>

                <div className="text-center mb-8 mt-4">
                  <div className="relative">
                    <div className="w-32 h-32 bg-gradient-to-r from-blue-500 via-green-500 to-yellow-500 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-2xl">
                      <span className="text-5xl font-black text-white">$99</span>
                    </div>
                    <div className="absolute -top-2 -right-2 w-12 h-12 bg-gradient-to-r from-red-500 to-red-600 rounded-full flex items-center justify-center animate-bounce">
                      <span className="text-white font-bold text-xs">60%</span>
                    </div>
                  </div>
                  <h3 className="text-3xl font-bold text-yellow-400 mb-2">Your Investment</h3>
                  <p className="text-green-200 font-semibold">Professional AI Training + $100 Bonus Pack</p>
                </div>

                <div className="space-y-4">
                  {[
                    "3 Hours Intensive AI Training",
                    "Hands-On AI Tools Setup",
                    "Industry-Specific Applications",
                    "$100 AI Toolkit & Prompts",
                    "Certificate of Completion",
                    "Lifetime Community Access"].
                    map((item, index) =>
                      <div key={index} className="flex items-center gap-3">
                        <div className="w-6 h-6 bg-gradient-to-r from-green-400 to-blue-400 rounded-full flex items-center justify-center">
                          <CheckCircle2 className="w-4 h-4 text-white" />
                        </div>
                        <span className="text-white font-medium">{item}</span>
                      </div>
                    )}
                </div>
              </div>
            </motion.div>
          </div>

          {/* Value Proposition Section */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="bg-gradient-to-r from-yellow-400/10 via-orange-400/10 to-red-400/10 rounded-3xl p-8 md:p-12 backdrop-blur-sm border border-yellow-400/20 mb-12">
            <div className="grid md:grid-cols-2 gap-8 items-center">
              <div>
                <h3 className="text-3xl md:text-4xl font-bold mb-6 text-white">Why This VALUE is Unbeatable

                </h3>
                <p className="text-blue-100 text-lg mb-6 leading-relaxed">
                  We genuinely want to help professionals secure their careers in the AI age.
                  This discounted price allows us to reach more people who need these skills.
                  It's our way of contributing to the community.
                </p>
                <div className="bg-white/10 rounded-2xl p-6 backdrop-blur-sm">
                  <p className="text-yellow-300 font-bold text-xl mb-2">🎯 Your ROI:</p>
                  <p className="text-white">Save 10+ hours weekly + 35% salary increase potential = secure career and business</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-6 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/10">
                  <div className="text-4xl font-bold text-yellow-400 mb-2">$100</div>
                  <div className="text-white text-sm">Bonus Pack Value</div>
                </div>
                <div className="text-center p-6 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/10">
                  <div className="text-4xl font-bold text-green-400 mb-2">3</div>
                  <div className="text-white text-sm">Hours Training</div>
                </div>
                <div className="text-center p-6 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/10">
                  <div className="text-4xl font-bold text-blue-400 mb-2">∞</div>
                  <div className="text-white text-sm">Community Access</div>
                </div>
                <div className="text-center p-6 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/10">
                  <div className="text-4xl font-bold text-purple-400 mb-2">1</div>
                  <div className="text-white text-sm">Expert Trainer</div>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Final CTA */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="text-center">
            <div className="mb-8">
              <div className="inline-flex items-center gap-4 bg-white/10 backdrop-blur-sm rounded-full px-8 py-4 border border-white/20 mb-6">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="text-green-300 font-semibold">Limited Seats Available</span>
                </div>
                <div className="w-px h-6 bg-white/20"></div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-yellow-400 rounded-full animate-pulse"></div>
                  <span className="text-yellow-300 font-semibold">Filling Fast</span>
                </div>
              </div>
            </div>

            <PaymentButton
              courseType="mastermind-session"
              courseName="3 Hour AI Mastermind"
              price={99}
              className="bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 hover:from-yellow-300 hover:via-orange-400 hover:to-red-400 text-slate-900 px-6 sm:px-12 py-4 sm:py-6 text-lg sm:text-2xl font-black rounded-2xl shadow-2xl transform hover:scale-105 transition-all duration-300 animate-pulse border-4 border-white/20 w-full sm:w-auto">
              🚀 Secure Your Seat - Only $99
            </PaymentButton>

            <p className="mt-6 text-blue-200 font-medium">
              ✅ Secure Payment • 🔄 Flexible Rescheduling • 💬 Instant Support
            </p>
          </motion.div>
        </div>
      </section>

      {/* Trainer Profile Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-blue-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-3 text-base font-semibold mb-6 hover:bg-blue-600 hover:text-white transition-colors">
              <Award className="w-5 h-5 mr-2" />
              Your Expert Trainer
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 mb-6">
              Learn from the Best in the Business
            </h2>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative order-2 lg:order-1">
              <img
                src="https://i.imghippo.com/files/tfUo2263Io.png"
                alt="Gaurav Oberoi - Expert AI marketing trainer"
                className="w-full h-auto rounded-2xl shadow-2xl" />

              <div className="relative text-center mt-4 sm:absolute sm:-top-4 sm:-right-4 sm:mt-0">
                <div className="inline-block bg-blue-600 text-white px-4 py-2 rounded-full font-bold text-sm">
                  15+ Years Experience
                </div>
              </div>
            </div>

            <div className="order-1 lg:order-2">
              <h3 className="text-3xl font-black text-slate-900 mb-4">
                Gaurav Oberoi
              </h3>
              <p className="text-xl text-blue-600 font-semibold mb-6">
                Founder & Lead AI Trainer at Inc Academy
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  <span className="text-slate-700 font-medium">Trained 9,000+ professionals, including executives from Fortune 500 companies</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  <span className="text-slate-700 font-medium">Former Google Regional Trainer</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  <span className="text-slate-700 font-medium">Dubai Tourism consultant for Expo 2020</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  <span className="text-slate-700 font-medium">TikTok MENA collaborator</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 flex-shrink-0" />
                  <span className="text-slate-700 font-medium">Active investor & startup advisor</span>
                </div>
              </div>

              <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-blue-100 mb-8">
                <h4 className="text-lg font-bold text-slate-900 mb-3">Why Learn from Gaurav?</h4>
                <p className="text-slate-600 mb-4 leading-relaxed">
                  "I've been training professionals for over 15 years, and I've never seen a technology
                  as transformative as AI. But here's the thing - it's not about the technology itself.
                  It's about how you apply it to solve real business problems. That's what I'll teach you."
                </p>
                <div className="flex items-center gap-2">
                  <div className="flex">
                    {Array.from({ length: 5 }).map((_, i) =>
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    )}
                  </div>
                  <span className="text-sm text-slate-500 font-medium">4.9/5</span>
                </div>
              </div>

              <PaymentButton
                courseType="mastermind-session"
                courseName="3 Hour AI Mastermind"
                price={99}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-xl font-bold rounded-xl shadow-lg">
                Learn from Gaurav - $99
              </PaymentButton>
            </div>
          </div>
        </div>
      </section>

      {/* Extended Client Logos Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <p className="text-lg font-semibold text-slate-600 mb-6">
            </p>
          </div>
          <div className="bg-gradient-to-br from-slate-50 to-blue-50 rounded-2xl shadow-lg p-6 sm:p-8 border border-slate-200">
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4 sm:gap-6 items-center justify-items-center">
              {extendedClientLogos.map((client, index) =>
                <div key={index} className="group">
                  <img
                    src={client.src}
                    alt={client.alt}
                    className="max-h-8 sm:max-h-12 w-auto opacity-60 hover:opacity-100 transition-all duration-300 grayscale hover:grayscale-0 group-hover:scale-110"
                    loading="lazy"
                    decoding="async" />

                </div>
              )}
            </div>
            <div className="text-center mt-6">
              <p className="text-sm text-slate-500">
                And hundreds more Fortune 500 companies, government organizations, and industry leaders across the Middle East
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-2xl sm:text-3xl font-black text-white mb-6">
            Ready to Transform Your Career?
          </h3>
          <p className="text-lg text-white mb-6 font-medium">
            Join professionals who are already leading with AI
          </p>
          <PaymentButton
            courseType="mastermind-session"
            courseName="3 Hour AI Mastermind"
            price={99}
            className="bg-white hover:bg-gray-100 text-blue-600 px-10 py-4 text-xl font-bold rounded-xl shadow-lg">
            Reserve My Seat Now — $99
          </PaymentButton>
        </div>
      </section>

      {/* Target Audience Section - Enhanced */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-3 text-base font-semibold mb-6 hover:bg-blue-600 hover:text-white transition-colors">
              <Target className="w-5 h-5 mr-2" />
              Perfect For You If...
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 mb-6">
              Who Should Attend This AI Mastermind?
            </h2>
            <p className="text-xl text-slate-600 max-w-4xl mx-auto leading-relaxed">
              This intensive AI for business leaders session is designed for professionals who want to stay ahead of the AI curve through practical Generative AI training.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {targetAudience.map((audience, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}>

                <Card className="border-2 border-blue-200 hover:border-blue-400 transition-all duration-300 hover:shadow-xl h-full bg-gradient-to-br from-white to-blue-50">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-4">
                      {React.createElement(audience.icon, { className: "w-6 h-6 text-white" })}
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 mb-2">{audience.title}</h3>
                    <p className="text-blue-600 font-semibold mb-3 text-sm">{audience.subtitle}</p>
                    <p className="text-slate-600 leading-relaxed text-sm">{audience.description}</p>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          <div className="text-center">
            <PaymentButton
              courseType="mastermind-session"
              courseName="3 Hour AI Mastermind"
              price={99}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg">

              Join Your Peers for $99
            </PaymentButton>
          </div>
        </div>
      </section>

      {/* New Booking Section */}
      <BookingSection
        courseType="mastermind-session"
        courseName="3 Hour AI Mastermind"
        price={99}
        nextBatchDate="Saturday October 4th, 2025"
        duration="3 Hours"
        seatsLeft={10} // Keeping placeholder value
        features={courseFeatures}
        targetDate={offerEndDate.toISOString()}
      />

      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-slate-100 text-slate-800 px-6 py-3 text-base font-semibold mb-6 hover:bg-slate-600 hover:text-white hover:border-slate-600 transition-colors">
              <BookOpen className="w-5 h-5 mr-2" />
              Your 3-Hour Agenda
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 mb-6">
              From Novice to Navigator: Your AI Fast-Track
            </h2>
            <p className="text-xl text-slate-600 max-w-4xl mx-auto leading-relaxed">
              This is a hands-on, no-fluff session designed to give you foundational AI for executives skills and AI workflow automation you can apply immediately.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {agenda.map((item, index) =>
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}>

                <Card className="h-full border-2 border-slate-200 hover:border-slate-400 transition-all duration-300 hover:shadow-xl bg-gradient-to-br from-white to-slate-50">
                  <CardContent className="p-6">
                    <div className="flex items-start gap-4">
                      <div className="w-12 h-12 bg-gradient-to-br from-slate-600 to-slate-800 rounded-xl flex items-center justify-center">
                        {React.createElement(item.icon, { className: "w-6 h-6 text-white" })}
                      </div>
                      <div className="flex-1">
                        <h3 className="text-lg sm:text-xl font-bold text-slate-900 mb-2">{item.title}</h3>
                        <p className="text-slate-600 leading-relaxed">{item.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )}
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 border-2 border-blue-200 mb-12">
            <div className="text-center">
              <Badge className="bg-blue-600 text-white px-4 py-2 text-base font-bold mb-6">
                <Gift className="w-5 h-5 mr-2" />
                EXCLUSIVE BONUS
              </Badge>
              <h3 className="text-2xl font-bold text-slate-900 mb-4">
                This is your first step into mastering AI for business
              </h3>
              <p className="text-lg text-slate-700 mb-6 leading-relaxed">
                We'll also give you a roadmap to advanced skills and show you exactly how to progress from AI beginner to AI specialist through our comprehensive training programs.
              </p>
              <div className="grid sm:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="font-bold text-slate-900 mb-2">100+ Premium AI Prompts</h4>
                  <p className="text-sm text-slate-600">Ready-to-use prompts for every business scenario</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Rocket className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="font-bold text-slate-900 mb-2">AI Tools Checklist</h4>
                  <p className="text-sm text-slate-600">Comprehensive guide to the best AI tools for your role</p>
                </div>
                <div className="text-center">
                  <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                    <Target className="w-8 h-8 text-white" />
                  </div>
                  <h4 className="font-bold text-slate-900 mb-2">Career Roadmap</h4>
                  <p className="text-sm text-slate-600">Step-by-step plan to become an AI expert in your industry</p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center">
            <PaymentButton
              courseType="mastermind-session"
              courseName="3 Hour AI Mastermind"
              price={99}
              className="bg-slate-900 hover:bg-slate-800 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg">
              Get Full Training - $99
            </PaymentButton>
          </div>
        </div>
      </section>

      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-blue-600">
        <div className="max-w-4xl mx-auto text-center">
          <h3 className="text-2xl sm:text-3xl font-black text-white mb-6">
            Ready to Lead with AI?
          </h3>
          <p className="text-lg text-white mb-6 font-medium">
            Professional AI training for serious business growth
          </p>
          <PaymentButton
            courseType="mastermind-session"
            courseName="3 Hour AI Mastermind"
            price={99}
            className="bg-white hover:bg-gray-100 text-blue-600 px-10 py-4 text-xl font-bold rounded-xl shadow-lg">

            Reserve My Seat Now — $99
          </PaymentButton>
        </div>
      </section>

      {/* Updated What Happens After Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-blue-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="bg-blue-100 text-blue-800 px-6 py-3 text-base font-semibold mb-6 hover:bg-blue-600 hover:text-white transition-colors">
              <CheckCircle2 className="w-5 h-5 mr-2" />
              Simple Process
            </Badge>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-slate-900 mb-6">
              What Happens After I Sign Up?
            </h2>
            <p className="text-xl text-slate-600 leading-relaxed">
              We've made it super simple - here's exactly what to expect
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            <Card className="text-center border-2 border-blue-200 bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl font-black text-white">1</span>
                </div>
                <div className="bg-blue-100 rounded-full px-3 py-1 text-xs font-bold text-blue-800 mb-4 inline-block">
                  INSTANT CONFIRMATION
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">Choose Your Session & Pay</h3>
                <p className="text-slate-600 leading-relaxed">
                  Select your preferred date during checkout (no account required). Get instant confirmation email with your session details.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-2 border-blue-200 bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl font-black text-white">2</span>
                </div>
                <div className="bg-blue-100 rounded-full px-3 py-1 text-xs font-bold text-blue-800 mb-4 inline-block">
                  ZOOM LINK + BONUSES
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">Get Your Access Details</h3>
                <p className="text-slate-600 leading-relaxed">
                  Receive your Zoom link 24 hours before your session plus immediate access to your $100 AI Starter Bonus Pack.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center border-2 border-blue-200 bg-white shadow-lg">
              <CardContent className="p-8">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
                  <span className="text-2xl font-black text-white">3</span>
                </div>
                <div className="bg-blue-100 rounded-full px-3 py-1 text-xs font-bold text-blue-800 mb-4 inline-block">
                  LIVE TRAINING
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-4">Transform Your Career</h3>
                <p className="text-slate-600 leading-relaxed">
                  Join your live session, master hands-on AI skills, and walk away with everything you need to 10x your productivity.
                </p>
              </CardContent>
            </Card>
          </div>

          <div className="bg-white rounded-2xl p-8 border-2 border-blue-200 text-center">
            <div className="flex items-center justify-center gap-3 mb-6">
              <Shield className="w-8 h-8 text-blue-600" />
              <h3 className="text-2xl font-bold text-slate-900">Flexible Rescheduling Policy</h3>
            </div>
            <p className="text-lg text-slate-600 mb-6 leading-relaxed">
              Life happens! If you can't make your selected session, you can easily reschedule to the next available date with 24 hours' notice. No hassle, no extra fees.
            </p>
            <PaymentButton
              courseType="mastermind-session"
              courseName="3 Hour AI Mastermind"
              price={99}
              className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 text-xl font-bold rounded-xl shadow-lg">

              Start My AI Journey - $99
            </PaymentButton>
          </div>
        </div>
      </section>

      {/* Witty Objection Handler Section */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-3xl mx-auto text-center">
          <Card className="bg-slate-900 text-white rounded-2xl shadow-2xl p-8 md:p-12 border-4 border-blue-600">
            <CardContent>
              <h3 className="text-2xl sm:text-3xl font-bold mb-4">Professional AI Training</h3>
              <p className="text-lg text-slate-300 leading-relaxed mb-6">
                This is a professional investment in your career development and business growth.
              </p>
              <p className="text-xl font-semibold text-white leading-relaxed mb-8">
                Join business leaders who are already transforming their operations with AI on <span className="text-blue-400 font-bold">Saturday October 4th, 2025</span>.
              </p>
              <p className="text-2xl font-bold text-blue-400">Your career transformation starts here. 🚀</p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* AI Amplification Section - New */}
      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white">
        <div className="max-w-6xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative">
              <img
                src="https://i.imghippo.com/files/WGx2240ZBE.png"
                alt="Human-AI collaboration representing exponential capability growth"
                className="rounded-2xl shadow-2xl w-full" />
              <div className="absolute inset-0 bg-gradient-to-t from-blue-900/30 to-transparent rounded-2xl"></div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-center lg:text-left">
              <Badge className="bg-blue-400/20 text-blue-300 px-6 py-3 text-base font-semibold mb-6 border border-blue-400/30">
                <Rocket className="w-5 h-5 mr-2" />
                Exponential Growth
              </Badge>
              <h3 className="text-3xl sm:text-4xl font-bold mb-6 leading-tight">
                "People who are using AI to amplify their skills to achieve more, to reach higher, to do better...these are people who will exponentially get more capable over time."
              </h3>
              <p className="text-xl text-blue-100 mb-8 leading-relaxed">
                Join the ranks of professionals who aren't just keeping up with AI - they're leading the transformation.
              </p>
              <PaymentButton
                courseType="mastermind-session"
                courseName="3 Hour AI Mastermind"
                price={99}
                className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg font-bold rounded-xl shadow-lg">
                Start My AI Journey - $99
              </PaymentButton>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mb-6">
              What Professionals Say About Our Training
            </h2>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {testimonials.map((testimonial, index) =>
              <Card key={index} className="border-0 shadow-xl bg-gradient-to-br from-white to-blue-50">
                <CardContent className="p-8">
                  <div className="flex items-center gap-1 mb-4">
                    {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="w-5 h-5 fill-yellow-400 text-yellow-400" />)}
                  </div>
                  <p className="text-slate-700 mb-4 italic text-lg leading-relaxed">
                    "{testimonial.quote}"
                  </p>
                  <p className="font-bold text-slate-900">{testimonial.author}</p>
                  <p className="text-sm text-slate-600">{testimonial.role}</p>
                </CardContent>
              </Card>
            )}
          </div>
          <div className="text-center">
            <PaymentButton
              courseType="mastermind-session"
              courseName="3 Hour AI Mastermind"
              price={99}
              className="bg-slate-900 hover:bg-slate-800 text-white px-4 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-bold rounded-xl shadow-lg w-full sm:w-auto">
              Join Successful Professionals - $99
            </PaymentButton>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <Badge className="px-6 py-3 text-base font-semibold bg-slate-100 text-slate-700 border border-slate-200 mb-6 hover:bg-slate-600 hover:text-white hover:border-slate-600 transition-colors">
              <Lightbulb className="w-5 h-5 mr-2" />
              Frequently Asked Questions
            </Badge>
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 mb-6">
              Everything You Need to Know
            </h2>
            <p className="text-xl text-slate-600">Get answers about our AI for executives mastermind course.</p>
          </div>

          <div className="flex flex-wrap justify-center gap-2 mb-8">
            {Object.keys(faqsData).map((category) =>
              <Button
                key={category}
                variant={activeFAQCategory === category ? 'default' : 'outline'}
                onClick={() => {
                  setActiveFAQCategory(category);
                  setOpenFAQ(0);
                }}
                className={`rounded-full transition-all duration-300 ${activeFAQCategory === category ?
                  'bg-slate-900 text-white hover:bg-slate-800 border-slate-900' :
                  'bg-white text-slate-800 border-slate-300 hover:bg-slate-100'}`
                }>

                {category}
              </Button>
            )}
          </div>

          <div className="space-y-4">
            {faqsData[activeFAQCategory].map((faq, index) =>
              <Card key={index} className="rounded-xl shadow-sm border-slate-200 overflow-hidden">
                <button
                  className="w-full text-left p-6 hover:bg-slate-50 transition-colors duration-200"
                  onClick={() => setOpenFAQ(openFAQ === index ? -1 : index)}>

                  <div className="flex justify-between items-center">
                    <h3 className="font-bold text-lg text-slate-900 pr-4">{faq.q}</h3>
                    <div className="flex-shrink-0 bg-slate-100 rounded-full w-8 h-8 flex items-center justify-center">
                      {openFAQ === index ?
                        <ChevronUp className="w-5 h-5 text-slate-900" /> :
                        <ChevronDown className="w-5 h-5 text-slate-600" />
                      }
                    </div>
                  </div>
                </button>
                {openFAQ === index &&
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="px-6 pb-6">

                    <p className="text-slate-600 leading-relaxed border-l-2 border-slate-900 pl-4">{faq.a}</p>
                  </motion.div>
                }
              </Card>
            )}
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-slate-900 via-indigo-900 to-purple-900 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black mb-8">
            Your AI Journey Starts Here
          </h2>
          <p className="text-xl text-slate-200 mb-12 leading-relaxed">
            Join the AI revolution on <span className="font-bold text-blue-400">Saturday October 4th, 2025</span>. Master the skills that will define the next decade of business success.
          </p>

          <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 mb-8 border border-white/20">
            <div className="grid sm:grid-cols-3 gap-6 text-center mb-8">
              <div>
                <div className="text-3xl font-black text-blue-400 mb-2">$99</div>
                <div className="text-slate-300">Discounted Price</div>
              </div>
              <div>
                <div className="text-3xl font-black text-blue-400 mb-2">3hrs</div>
                <div className="text-slate-300">Live Training</div>
              </div>
              <div>
                <div className="text-3xl font-black text-blue-400 mb-2">$100</div>
                <div className="text-slate-300">Bonus Pack</div>
              </div>
            </div>

            <PaymentButton
              courseType="mastermind-session"
              courseName="3 Hour AI Mastermind"
              price={99}
              className="bg-blue-600 hover:bg-blue-700 text-white px-6 sm:px-12 py-4 sm:py-5 text-lg sm:text-2xl font-black rounded-xl shadow-2xl transform hover:scale-105 transition-all duration-300 w-full sm:w-auto">
              Reserve My Seat for $99
            </PaymentButton>
          </div>

          <div className="text-center space-y-4">
            <p className="text-sm text-slate-400">
              Transfer or Reschedule Policy • Secure Payment • All Major Cards
            </p>
            <p className="text-sm font-semibold text-blue-400">
              Limited spots available - Secure your seat today!
            </p>
          </div>
        </div>
      </section>

      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-slate-800 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">
            Still Have Questions?
          </h2>
          <p className="text-lg text-slate-300 mb-8 leading-relaxed">
            Our team is here to help. Reach out for more details about the curriculum, group bookings, or private corporate sessions.
          </p>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-2 border-white hover:bg-white hover:text-slate-900 px-8 py-3 text-lg font-bold inline-flex items-center justify-center gap-2 rounded-xl"
            onClick={() => window.open('https://wa.me/971524371377', '_blank')}>

            <MessageCircle className="w-5 h-5 mr-2" />
            Chat with Us on WhatsApp
          </Button>
        </div>
      </section>
    </div>);

}
