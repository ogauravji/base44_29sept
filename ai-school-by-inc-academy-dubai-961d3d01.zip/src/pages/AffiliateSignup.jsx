
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
    UserPlus, 
    Eye,
    EyeOff,
    ArrowRight,
    CheckCircle2,
    Gift
} from "lucide-react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";

export default function AffiliateSignup() {
    const [formData, setFormData] = useState({
        full_name: '',
        email: '',
        password: '',
        phone: ''
    });
    const [isLoading, setIsLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
        setError('');
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsLoading(true);
        setError('');

        // Basic validation
        if (formData.password.length < 6) {
            setError('Password must be at least 6 characters long');
            setIsLoading(false);
            return;
        }

        try {
            const response = await fetch('https://base44.app/api/apps/68947005b6a22444961d3d01/functions/createSimpleAffiliate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(formData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                setSuccess(true);
            } else {
                setError(data.error || 'Signup failed');
            }
        } catch (error) {
            console.error('Signup error:', error);
            setError('Network error. Please try again.');
        } finally {
            setIsLoading(false);
        }
    };

    if (success) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 flex items-center justify-center p-4">
                <Card className="w-full max-w-md shadow-2xl border-0 rounded-3xl overflow-hidden">
                    <CardContent className="p-8 text-center">
                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                            <CheckCircle2 className="w-8 h-8 text-green-600" />
                        </div>
                        <h2 className="text-2xl font-bold text-gray-900 mb-4">Welcome to the Program!</h2>
                        <p className="text-gray-600 mb-8">
                            Your affiliate account has been created successfully. 
                            You can now login and start earning commissions!
                        </p>
                        
                        <Link to={createPageUrl('AffiliateLogin')}>
                            <Button className="w-full bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white px-8 py-4 font-semibold rounded-xl">
                                Login to Dashboard
                                <ArrowRight className="w-5 h-5 ml-2" />
                            </Button>
                        </Link>
                    </CardContent>
                </Card>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
            {/* Hero Section */}
            <section className="relative bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(147,51,234,0.3),transparent)]"></div>
                <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
                    <div className="text-center mb-16">
                        <Badge className="px-6 py-3 text-lg font-bold bg-gradient-to-r from-yellow-400 to-orange-500 text-black border-0 mb-8">
                            <Gift className="w-5 h-5 mr-2" />
                            JOIN & EARN 25%
                        </Badge>

                        <h1 className="text-4xl md:text-5xl font-bold mb-8 leading-tight">
                            Become an Affiliate
                            <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent block mt-2">
                                Start Earning Today
                            </span>
                        </h1>

                        <p className="text-xl text-blue-100 mb-12 max-w-2xl mx-auto leading-relaxed">
                            Simple signup process. Start earning 25% commission on every sale you refer.
                        </p>
                    </div>
                </div>
            </section>

            {/* Signup Form */}
            <section className="py-20 bg-gray-50 flex items-center justify-center">
                <div className="max-w-md mx-auto px-4 sm:px-6 lg:px-8 w-full">
                    <Card className="shadow-2xl border-0 rounded-3xl overflow-hidden">
                        <CardHeader className="text-center pb-6">
                            <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                                <UserPlus className="w-8 h-8 text-white" />
                            </div>
                            <CardTitle className="text-2xl font-bold text-gray-900">
                                Create Affiliate Account
                            </CardTitle>
                            <p className="text-gray-600">
                                Fill out the form below to get started
                            </p>
                        </CardHeader>

                        <CardContent className="p-8 pt-0">
                            {error && (
                                <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-lg mb-6">
                                    {error}
                                </div>
                            )}

                            <form onSubmit={handleSubmit} className="space-y-6">
                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Full Name
                                    </label>
                                    <Input
                                        type="text"
                                        name="full_name"
                                        value={formData.full_name}
                                        onChange={handleInputChange}
                                        placeholder="Enter your full name"
                                        required
                                        className="h-12"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Email Address
                                    </label>
                                    <Input
                                        type="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        placeholder="Enter your email"
                                        required
                                        className="h-12"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Phone Number
                                    </label>
                                    <Input
                                        type="tel"
                                        name="phone"
                                        value={formData.phone}
                                        onChange={handleInputChange}
                                        placeholder="Enter your phone number"
                                        required
                                        className="h-12"
                                    />
                                </div>

                                <div>
                                    <label className="block text-sm font-medium text-gray-700 mb-2">
                                        Password
                                    </label>
                                    <div className="relative">
                                        <Input
                                            type={showPassword ? "text" : "password"}
                                            name="password"
                                            value={formData.password}
                                            onChange={handleInputChange}
                                            placeholder="Create a password (min 6 characters)"
                                            required
                                            className="h-12 pr-12"
                                        />
                                        <button
                                            type="button"
                                            onClick={() => setShowPassword(!showPassword)}
                                            className="absolute inset-y-0 right-0 pr-4 flex items-center text-gray-400 hover:text-gray-600"
                                        >
                                            {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                                        </button>
                                    </div>
                                </div>

                                <Button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-bold py-3 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300"
                                >
                                    {isLoading ? 'Creating Account...' : 'Create Affiliate Account'}
                                    <ArrowRight className="w-5 h-5 ml-2" />
                                </Button>
                            </form>

                            <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                                <p className="text-gray-600 text-sm mb-4">
                                    Already have an account?
                                </p>
                                <Link to={createPageUrl('AffiliateLogin')}>
                                    <Button variant="outline" className="w-full border-2 border-purple-200 text-purple-600 hover:bg-purple-50 font-semibold rounded-xl h-12">
                                        Login Here
                                    </Button>
                                </Link>
                            </div>
                        </CardContent>
                    </Card>
                </div>
            </section>
        </div>
    );
}
