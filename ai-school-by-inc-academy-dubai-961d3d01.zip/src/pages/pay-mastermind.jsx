import React, { useEffect, useState } from 'react';
import { generateCheckout } from '@/api/functions';
import { Loader2 } from 'lucide-react';
import { createPageUrl } from '@/utils';

export default function MastermindPaymentRedirect() {
  const [error, setError] = useState(null);

  useEffect(() => {
    const handlePayment = async () => {
      try {
        const successUrl = `${window.location.origin}${createPageUrl('success')}?session_id={CHECKOUT_SESSION_ID}`;
        const cancelUrl = `${window.location.origin}${createPageUrl('ai-skills-mastermind')}`;
        
        const response = await generateCheckout({
          courseType: 'mastermind-session',
          successUrl: successUrl,
          cancelUrl: cancelUrl,
        });

        if (response.data && response.data.url) {
          window.location.href = response.data.url;
        } else {
          throw new Error(response.data.error || 'Failed to create payment link.');
        }
      } catch (err) {
        console.error('Payment Redirect Error:', err);
        setError(err.message);
      }
    };

    handlePayment();
  }, []);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 text-center p-4">
      {error ? (
        <>
          <h1 className="text-2xl font-bold text-red-600 mb-4">Payment Error</h1>
          <p className="text-gray-700 mb-4">{error}</p>
          <a href={createPageUrl('ai-skills-mastermind')} className="text-blue-600 hover:underline">
            Please try again from the course page.
          </a>
        </>
      ) : (
        <>
          <Loader2 className="w-12 h-12 text-blue-600 animate-spin mb-4" />
          <h1 className="text-2xl font-bold text-gray-800">Redirecting to Payment...</h1>
          <p className="text-gray-600">Please wait while we securely redirect you to our payment partner.</p>
        </>
      )}
    </div>
  );
}