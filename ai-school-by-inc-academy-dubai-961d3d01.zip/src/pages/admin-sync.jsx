import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, CheckCircle2, AlertCircle, Users } from 'lucide-react';
import { syncEnrollments } from '@/api/functions';

export default function AdminSync() {
  const [isLoading, setIsLoading] = useState(false);
  const [syncResults, setSyncResults] = useState(null);
  const [error, setError] = useState(null);

  const handleSync = async () => {
    setIsLoading(true);
    setError(null);
    setSyncResults(null);

    try {
      const { data, status } = await syncEnrollments();
      
      if (status === 200) {
        setSyncResults(data.results);
      } else {
        setError(data.error || 'Sync failed');
      }
    } catch (err) {
      setError(err.message || 'An error occurred during sync');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge className="px-6 py-3 text-base font-semibold bg-blue-50 text-blue-600 border-0 mb-8">
            <Users className="w-5 h-5 mr-2" />
            Admin Tools
          </Badge>
          <h1 className="text-4xl font-bold text-gray-900 mb-6">
            Manual Enrollment Sync
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Sync all completed Stripe payments with your enrollment database
          </p>
        </div>

        {/* Sync Button */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Sync Enrollments</CardTitle>
            <p className="text-gray-600">
              This will fetch all completed Stripe checkout sessions from the last 30 days and create enrollment records for any missing payments.
            </p>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={handleSync}
              disabled={isLoading}
              size="lg"
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                  Syncing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-5 h-5 mr-2" />
                  Start Sync
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Error Display */}
        {error && (
          <Card className="mb-8 border-red-200 bg-red-50">
            <CardContent className="pt-6">
              <div className="flex items-center gap-3 text-red-800">
                <AlertCircle className="w-6 h-6" />
                <div>
                  <h3 className="font-semibold">Sync Error</h3>
                  <p className="text-sm">{error}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Results Display */}
        {syncResults && (
          <Card className="border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-green-800">
                <CheckCircle2 className="w-6 h-6" />
                Sync Complete
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="text-center p-4 bg-white rounded-lg">
                  <div className="text-2xl font-bold text-gray-900">{syncResults.total}</div>
                  <div className="text-sm text-gray-600">Total Sessions</div>
                </div>
                <div className="text-center p-4 bg-white rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{syncResults.synced}</div>
                  <div className="text-sm text-gray-600">Synced</div>
                </div>
                <div className="text-center p-4 bg-white rounded-lg">
                  <div className="text-2xl font-bold text-yellow-600">{syncResults.skipped}</div>
                  <div className="text-sm text-gray-600">Skipped</div>
                </div>
                <div className="text-center p-4 bg-white rounded-lg">
                  <div className="text-2xl font-bold text-red-600">{syncResults.errors}</div>
                  <div className="text-sm text-gray-600">Errors</div>
                </div>
              </div>

              {/* Detailed Results */}
              {syncResults.details && syncResults.details.length > 0 && (
                <div className="bg-white rounded-lg p-4">
                  <h4 className="font-semibold text-gray-900 mb-4">Detailed Results</h4>
                  <div className="max-h-64 overflow-y-auto space-y-2">
                    {syncResults.details.map((detail, index) => (
                      <div key={index} className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded">
                        <div>
                          <span className="font-mono text-xs text-gray-500">{detail.sessionId}</span>
                          {detail.customerEmail && (
                            <div className="text-gray-700">{detail.customerEmail}</div>
                          )}
                        </div>
                        <Badge 
                          className={
                            detail.status === 'synced' ? 'bg-green-100 text-green-800' :
                            detail.status === 'skipped' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }
                        >
                          {detail.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}