
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import { 
    Users, 
    CheckCircle2, 
    XCircle,
    Clock,
    Mail,
    Phone,
    Globe,
    Eye,
    UserCheck,
    UserX,
    Search,
    Filter
} from "lucide-react";
import { AffiliateApplication } from '@/api/entities';
import { approveAffiliate } from '@/api/functions';

export default function AffiliateManagement() {
    const [applications, setApplications] = useState([]);
    const [filteredApplications, setFilteredApplications] = useState([]);
    const [loading, setLoading] = useState(true);
    const [filter, setFilter] = useState('all');
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedApplication, setSelectedApplication] = useState(null);
    const [rejectionReason, setRejectionReason] = useState('');
    const [isProcessing, setIsProcessing] = useState(false);

    useEffect(() => {
        loadApplications();
    }, []);

    useEffect(() => {
        // Filter applications based on current state of applications, filter, and searchTerm
        let filtered = applications;

        if (filter !== 'all') {
            filtered = filtered.filter(app => app.application_status === filter);
        }

        if (searchTerm) {
            filtered = filtered.filter(app =>
                app.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                app.email.toLowerCase().includes(searchTerm.toLowerCase())
            );
        }

        setFilteredApplications(filtered);
    }, [applications, filter, searchTerm]); // Dependencies array correctly lists all external variables used inside the effect

    const loadApplications = async () => {
        try {
            const fetchedApplications = await AffiliateApplication.list('-created_date');
            setApplications(fetchedApplications);
        } catch (error) {
            console.error('Error loading applications:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleApproveReject = async (applicationId, action, reason = '') => {
        setIsProcessing(true);
        try {
            const response = await approveAffiliate({
                applicationId,
                action,
                rejectionReason: reason
            });

            if (response.data.success) {
                alert(action === 'approve' ? 'Affiliate approved successfully!' : 'Application rejected successfully!');
                await loadApplications(); // Reload the list
                setSelectedApplication(null);
                setRejectionReason('');
            } else {
                throw new Error(response.data.error);
            }
        } catch (error) {
            console.error(`Error ${action}ing application:`, error);
            alert(`Failed to ${action} application: ${error.message}`);
        } finally {
            setIsProcessing(false);
        }
    };

    const getStatusBadge = (status) => {
        switch (status) {
            case 'pending':
                return <Badge className="bg-yellow-100 text-yellow-800 flex items-center gap-1"><Clock className="w-3 h-3" />Pending</Badge>;
            case 'approved':
                return <Badge className="bg-green-100 text-green-800 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" />Approved</Badge>;
            case 'rejected':
                return <Badge className="bg-red-100 text-red-800 flex items-center gap-1"><XCircle className="w-3 h-3" />Rejected</Badge>;
            default:
                return <Badge variant="secondary">{status}</Badge>;
        }
    };

    const parseSocialMedia = (socialMediaString) => {
        try {
            return JSON.parse(socialMediaString || '{}');
        } catch {
            return {};
        }
    };

    if (loading) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="text-center">
                    <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                    <p className="text-gray-600">Loading applications...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">Affiliate Management</h1>
                    <p className="text-gray-600">Review and manage affiliate applications</p>
                </div>

                {/* Filters and Search */}
                <Card className="mb-8">
                    <CardContent className="p-6">
                        <div className="flex flex-col sm:flex-row gap-4">
                            <div className="flex-1">
                                <div className="relative">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                                    <Input
                                        placeholder="Search by name or email..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        className="pl-10"
                                    />
                                </div>
                            </div>
                            <div className="flex gap-2">
                                <Button
                                    variant={filter === 'all' ? 'default' : 'outline'}
                                    onClick={() => setFilter('all')}
                                    className="flex items-center gap-2"
                                >
                                    <Filter className="w-4 h-4" />
                                    All ({applications.length})
                                </Button>
                                <Button
                                    variant={filter === 'pending' ? 'default' : 'outline'}
                                    onClick={() => setFilter('pending')}
                                    className="flex items-center gap-2"
                                >
                                    <Clock className="w-4 h-4" />
                                    Pending ({applications.filter(a => a.application_status === 'pending').length})
                                </Button>
                                <Button
                                    variant={filter === 'approved' ? 'default' : 'outline'}
                                    onClick={() => setFilter('approved')}
                                    className="flex items-center gap-2"
                                >
                                    <CheckCircle2 className="w-4 h-4" />
                                    Approved ({applications.filter(a => a.application_status === 'approved').length})
                                </Button>
                                <Button
                                    variant={filter === 'rejected' ? 'default' : 'outline'}
                                    onClick={() => setFilter('rejected')}
                                    className="flex items-center gap-2"
                                >
                                    <XCircle className="w-4 h-4" />
                                    Rejected ({applications.filter(a => a.application_status === 'rejected').length})
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                </Card>

                {/* Applications Grid */}
                <div className="grid gap-6">
                    {filteredApplications.map((application, index) => {
                        const socialMedia = parseSocialMedia(application.social_media_channels);
                        
                        return (
                            <motion.div
                                key={application.id}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.3, delay: index * 0.1 }}
                            >
                                <Card className="shadow-lg hover:shadow-xl transition-shadow duration-300">
                                    <CardHeader>
                                        <div className="flex justify-between items-start">
                                            <div>
                                                <CardTitle className="text-xl mb-2">{application.full_name}</CardTitle>
                                                <div className="flex flex-wrap gap-2 text-sm text-gray-600">
                                                    <span className="flex items-center gap-1">
                                                        <Mail className="w-4 h-4" />
                                                        {application.email}
                                                    </span>
                                                    <span className="flex items-center gap-1">
                                                        <Phone className="w-4 h-4" />
                                                        {application.phone}
                                                    </span>
                                                    <span className="flex items-center gap-1">
                                                        <Globe className="w-4 h-4" />
                                                        {application.country}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-2">
                                                {getStatusBadge(application.application_status)}
                                                <Button
                                                    variant="outline"
                                                    size="sm"
                                                    onClick={() => setSelectedApplication(selectedApplication?.id === application.id ? null : application)}
                                                >
                                                    <Eye className="w-4 h-4 mr-1" />
                                                    {selectedApplication?.id === application.id ? 'Hide' : 'Details'}
                                                </Button>
                                            </div>
                                        </div>
                                    </CardHeader>

                                    {selectedApplication?.id === application.id && (
                                        <CardContent className="border-t pt-6">
                                            <div className="grid md:grid-cols-2 gap-6">
                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-3">Audience Information</h4>
                                                    <div className="space-y-2 text-sm">
                                                        <div><span className="font-medium">Size:</span> {application.audience_size}</div>
                                                        <div><span className="font-medium">Primary Platform:</span> {application.primary_platform}</div>
                                                        <div><span className="font-medium">Content Niche:</span> {application.content_niche}</div>
                                                        <div><span className="font-medium">Experience:</span> {application.experience_level}</div>
                                                    </div>
                                                </div>

                                                <div>
                                                    <h4 className="font-semibold text-gray-900 mb-3">Social Media Channels</h4>
                                                    <div className="space-y-1 text-sm">
                                                        {Object.entries(socialMedia).map(([platform, url]) => {
                                                            if (url && url.trim()) {
                                                                return (
                                                                    <div key={platform}>
                                                                        <span className="font-medium capitalize">{platform}:</span>{' '}
                                                                        <a href={url} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:underline break-all">
                                                                            {url}
                                                                        </a>
                                                                    </div>
                                                                );
                                                            }
                                                            return null;
                                                        })}
                                                    </div>
                                                </div>
                                            </div>

                                            {application.motivation && (
                                                <div className="mt-6">
                                                    <h4 className="font-semibold text-gray-900 mb-3">Motivation</h4>
                                                    <p className="text-sm text-gray-700 bg-gray-50 p-4 rounded-lg">
                                                        {application.motivation}
                                                    </p>
                                                </div>
                                            )}

                                            {application.application_status === 'pending' && (
                                                <div className="mt-6 pt-6 border-t">
                                                    <div className="flex gap-4">
                                                        <Button
                                                            onClick={() => handleApproveReject(application.id, 'approve')}
                                                            disabled={isProcessing}
                                                            className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
                                                        >
                                                            <UserCheck className="w-4 h-4" />
                                                            {isProcessing ? 'Approving...' : 'Approve'}
                                                        </Button>
                                                        <div className="flex-1 flex gap-2">
                                                            <Textarea
                                                                placeholder="Rejection reason (optional)"
                                                                value={rejectionReason}
                                                                onChange={(e) => setRejectionReason(e.target.value)}
                                                                rows={1}
                                                                className="flex-1"
                                                            />
                                                            <Button
                                                                onClick={() => handleApproveReject(application.id, 'reject', rejectionReason)}
                                                                disabled={isProcessing}
                                                                variant="outline"
                                                                className="border-red-200 text-red-600 hover:bg-red-50 flex items-center gap-2 whitespace-nowrap"
                                                            >
                                                                <UserX className="w-4 h-4" />
                                                                {isProcessing ? 'Rejecting...' : 'Reject'}
                                                            </Button>
                                                        </div>
                                                    </div>
                                                </div>
                                            )}

                                            {application.application_status === 'rejected' && application.rejection_reason && (
                                                <div className="mt-6 p-4 bg-red-50 rounded-lg border border-red-200">
                                                    <h4 className="font-semibold text-red-800 mb-2">Rejection Reason</h4>
                                                    <p className="text-red-700 text-sm">{application.rejection_reason}</p>
                                                </div>
                                            )}

                                            <div className="mt-6 pt-4 border-t text-xs text-gray-500">
                                                Applied: {new Date(application.created_date).toLocaleDateString('en-US', {
                                                    year: 'numeric',
                                                    month: 'long',
                                                    day: 'numeric',
                                                    hour: '2-digit',
                                                    minute: '2-digit'
                                                })}
                                            </div>
                                        </CardContent>
                                    )}
                                </Card>
                            </motion.div>
                        );
                    })}
                </div>

                {filteredApplications.length === 0 && (
                    <div className="text-center py-12">
                        <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">No applications found</h3>
                        <p className="text-gray-600">
                            {filter === 'all' 
                                ? 'No affiliate applications yet.' 
                                : `No ${filter} applications found.`}
                        </p>
                    </div>
                )}
            </div>
        </div>
    );
}
