import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
    DollarSign, 
    Users, 
    Link as LinkIcon, 
    Copy,
    TrendingUp,
    Calendar,
    ExternalLink
} from "lucide-react";
import { createPageUrl } from "@/utils";

export default function AffiliateDashboard() {
    const [affiliateData, setAffiliateData] = useState(null);
    const [copied, setCopied] = useState(false);

    useEffect(() => {
        // Get affiliate data from localStorage
        const storedData = localStorage.getItem('affiliateData');
        if (storedData) {
            setAffiliateData(JSON.parse(storedData));
        } else {
            // Redirect to login if no data
            window.location.href = createPageUrl('AffiliateLogin');
        }
    }, []);

    const copyToClipboard = (text) => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const handleLogout = () => {
        localStorage.removeItem('affiliateData');
        window.location.href = createPageUrl('AffiliateLogin');
    };

    if (!affiliateData) {
        return (
            <div className="min-h-screen bg-gray-50 flex items-center justify-center">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500 mx-auto"></div>
                    <p className="text-gray-600 mt-4">Loading dashboard...</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <div className="flex justify-between items-start">
                        <div>
                            <h1 className="text-3xl font-bold">Welcome back, {affiliateData.full_name}!</h1>
                            <p className="text-purple-100 mt-2">Affiliate Code: {affiliateData.affiliate_code}</p>
                        </div>
                        <Button variant="outline" onClick={handleLogout} className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                            Logout
                        </Button>
                    </div>
                </div>
            </div>

            {/* Dashboard Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                {/* Stats Cards */}
                <div className="grid md:grid-cols-4 gap-6 mb-8">
                    <Card>
                        <CardContent className="p-6 text-center">
                            <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <DollarSign className="w-6 h-6 text-green-600" />
                            </div>
                            <h3 className="text-2xl font-bold">${(affiliateData.total_earnings / 100).toFixed(2)}</h3>
                            <p className="text-gray-600">Total Earnings</p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6 text-center">
                            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <Users className="w-6 h-6 text-blue-600" />
                            </div>
                            <h3 className="text-2xl font-bold">{affiliateData.total_referrals}</h3>
                            <p className="text-gray-600">Total Referrals</p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6 text-center">
                            <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <TrendingUp className="w-6 h-6 text-purple-600" />
                            </div>
                            <h3 className="text-2xl font-bold">{Math.round(affiliateData.commission_rate * 100)}%</h3>
                            <p className="text-gray-600">Commission Rate</p>
                        </CardContent>
                    </Card>

                    <Card>
                        <CardContent className="p-6 text-center">
                            <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <Calendar className="w-6 h-6 text-orange-600" />
                            </div>
                            <h3 className="text-2xl font-bold">Active</h3>
                            <p className="text-gray-600">Account Status</p>
                        </CardContent>
                    </Card>
                </div>

                {/* Affiliate Link Card */}
                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle className="flex items-center gap-2">
                            <LinkIcon className="w-5 h-5" />
                            Your Affiliate Link
                        </CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="bg-gray-50 p-4 rounded-lg mb-4">
                            <p className="font-mono text-sm break-all">{affiliateData.affiliate_link}</p>
                        </div>
                        <div className="flex gap-3">
                            <Button 
                                onClick={() => copyToClipboard(affiliateData.affiliate_link)}
                                className="flex-1"
                            >
                                <Copy className="w-4 h-4 mr-2" />
                                {copied ? 'Copied!' : 'Copy Link'}
                            </Button>
                            <Button 
                                variant="outline" 
                                onClick={() => window.open(affiliateData.affiliate_link, '_blank')}
                            >
                                <ExternalLink className="w-4 h-4 mr-2" />
                                Test Link
                            </Button>
                        </div>
                    </CardContent>
                </Card>

                {/* Success Message */}
                <Card className="bg-green-50 border-green-200">
                    <CardContent className="p-6 text-center">
                        <h3 className="text-xl font-bold text-green-800 mb-2">🎉 Dashboard Access Successful!</h3>
                        <p className="text-green-700">
                            Your affiliate login is working perfectly. Start sharing your link to earn commissions!
                        </p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}