import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { createTestAffiliate } from '@/api/functions';

export default function CreateTestAffiliate() {
    const [formData, setFormData] = useState({
        email: 'o.gaurav@gmail.com',
        password: 'Gaurav@123456',
        full_name: 'Gaurav Test'
    });
    const [results, setResults] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        
        try {
            const response = await createTestAffiliate(formData);
            setResults(response.data);
        } catch (error) {
            console.error('Create affiliate error:', error);
            setResults({ error: error.message });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-4xl mx-auto">
                <h1 className="text-3xl font-bold text-gray-900 mb-8">Create Test Affiliate</h1>
                
                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle>Create Test Affiliate Account</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <Input
                                name="email"
                                type="email"
                                placeholder="Email address"
                                value={formData.email}
                                onChange={handleInputChange}
                                required
                            />
                            <Input
                                name="password"
                                type="password"
                                placeholder="Password"
                                value={formData.password}
                                onChange={handleInputChange}
                                required
                            />
                            <Input
                                name="full_name"
                                type="text"
                                placeholder="Full Name"
                                value={formData.full_name}
                                onChange={handleInputChange}
                                required
                            />
                            <Button type="submit" disabled={loading} className="w-full">
                                {loading ? 'Creating...' : 'Create/Update Affiliate Account'}
                            </Button>
                        </form>
                    </CardContent>
                </Card>

                {results && (
                    <Card>
                        <CardHeader>
                            <CardTitle>Results</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <pre className="bg-gray-100 p-4 rounded-lg overflow-auto text-sm">
                                {JSON.stringify(results, null, 2)}
                            </pre>
                            {results.success && (
                                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                                    <h3 className="text-green-800 font-semibold">Success! ✅</h3>
                                    <p className="text-green-700">Affiliate account created/updated. You can now try logging in.</p>
                                    <Button 
                                        className="mt-2"
                                        onClick={() => window.location.href = '/AffiliateLogin'}
                                    >
                                        Go to Login Page
                                    </Button>
                                </div>
                            )}
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}