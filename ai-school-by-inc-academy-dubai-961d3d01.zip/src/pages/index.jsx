import Layout from "./Layout.jsx";

import Home from "./Home";

import Consultancy from "./Consultancy";

import Agency from "./Agency";

import Privacy from "./Privacy";

import Terms from "./Terms";

import RefundPolicy from "./RefundPolicy";

import ai-courses from "./ai-courses";

import ai-beginners-course from "./ai-beginners-course";

import ai-advanced-course from "./ai-advanced-course";

import ai-skills-mastermind from "./ai-skills-mastermind";

import contact from "./contact";

import about from "./about";

import corporate-ai-workshops from "./corporate-ai-workshops";

import ai-consultants from "./ai-consultants";

import ai-implementation-agency from "./ai-implementation-agency";

import success from "./success";

import cancelled from "./cancelled";

import admin-sync from "./admin-sync";

import pay-mastermind from "./pay-mastermind";

import Files from "./Files";

import TestEnrollments from "./TestEnrollments";

import test-course from "./test-course";

import account from "./account";

import Blog from "./Blog";

import CreateBlogPost from "./CreateBlogPost";

import BlogPost from "./BlogPost";

import TestNewsletter from "./TestNewsletter";

import chatgpt-masterclass from "./chatgpt-masterclass";

import affiliate-program from "./affiliate-program";

import AffiliateManagement from "./AffiliateManagement";

import AffiliateSignup from "./AffiliateSignup";

import AffiliateLogin from "./AffiliateLogin";

import AffiliateDashboard from "./AffiliateDashboard";

import DebugAffiliate from "./DebugAffiliate";

import CreateTestAffiliate from "./CreateTestAffiliate";

import AffiliateDebugPanel from "./AffiliateDebugPanel";

import ForgotPassword from "./ForgotPassword";

import ResetPassword from "./ResetPassword";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    Consultancy: Consultancy,
    
    Agency: Agency,
    
    Privacy: Privacy,
    
    Terms: Terms,
    
    RefundPolicy: RefundPolicy,
    
    ai-courses: ai-courses,
    
    ai-beginners-course: ai-beginners-course,
    
    ai-advanced-course: ai-advanced-course,
    
    ai-skills-mastermind: ai-skills-mastermind,
    
    contact: contact,
    
    about: about,
    
    corporate-ai-workshops: corporate-ai-workshops,
    
    ai-consultants: ai-consultants,
    
    ai-implementation-agency: ai-implementation-agency,
    
    success: success,
    
    cancelled: cancelled,
    
    admin-sync: admin-sync,
    
    pay-mastermind: pay-mastermind,
    
    Files: Files,
    
    TestEnrollments: TestEnrollments,
    
    test-course: test-course,
    
    account: account,
    
    Blog: Blog,
    
    CreateBlogPost: CreateBlogPost,
    
    BlogPost: BlogPost,
    
    TestNewsletter: TestNewsletter,
    
    chatgpt-masterclass: chatgpt-masterclass,
    
    affiliate-program: affiliate-program,
    
    AffiliateManagement: AffiliateManagement,
    
    AffiliateSignup: AffiliateSignup,
    
    AffiliateLogin: AffiliateLogin,
    
    AffiliateDashboard: AffiliateDashboard,
    
    DebugAffiliate: DebugAffiliate,
    
    CreateTestAffiliate: CreateTestAffiliate,
    
    AffiliateDebugPanel: AffiliateDebugPanel,
    
    ForgotPassword: ForgotPassword,
    
    ResetPassword: ResetPassword,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/Consultancy" element={<Consultancy />} />
                
                <Route path="/Agency" element={<Agency />} />
                
                <Route path="/Privacy" element={<Privacy />} />
                
                <Route path="/Terms" element={<Terms />} />
                
                <Route path="/RefundPolicy" element={<RefundPolicy />} />
                
                <Route path="/ai-courses" element={<ai-courses />} />
                
                <Route path="/ai-beginners-course" element={<ai-beginners-course />} />
                
                <Route path="/ai-advanced-course" element={<ai-advanced-course />} />
                
                <Route path="/ai-skills-mastermind" element={<ai-skills-mastermind />} />
                
                <Route path="/contact" element={<contact />} />
                
                <Route path="/about" element={<about />} />
                
                <Route path="/corporate-ai-workshops" element={<corporate-ai-workshops />} />
                
                <Route path="/ai-consultants" element={<ai-consultants />} />
                
                <Route path="/ai-implementation-agency" element={<ai-implementation-agency />} />
                
                <Route path="/success" element={<success />} />
                
                <Route path="/cancelled" element={<cancelled />} />
                
                <Route path="/admin-sync" element={<admin-sync />} />
                
                <Route path="/pay-mastermind" element={<pay-mastermind />} />
                
                <Route path="/Files" element={<Files />} />
                
                <Route path="/TestEnrollments" element={<TestEnrollments />} />
                
                <Route path="/test-course" element={<test-course />} />
                
                <Route path="/account" element={<account />} />
                
                <Route path="/Blog" element={<Blog />} />
                
                <Route path="/CreateBlogPost" element={<CreateBlogPost />} />
                
                <Route path="/BlogPost" element={<BlogPost />} />
                
                <Route path="/TestNewsletter" element={<TestNewsletter />} />
                
                <Route path="/chatgpt-masterclass" element={<chatgpt-masterclass />} />
                
                <Route path="/affiliate-program" element={<affiliate-program />} />
                
                <Route path="/AffiliateManagement" element={<AffiliateManagement />} />
                
                <Route path="/AffiliateSignup" element={<AffiliateSignup />} />
                
                <Route path="/AffiliateLogin" element={<AffiliateLogin />} />
                
                <Route path="/AffiliateDashboard" element={<AffiliateDashboard />} />
                
                <Route path="/DebugAffiliate" element={<DebugAffiliate />} />
                
                <Route path="/CreateTestAffiliate" element={<CreateTestAffiliate />} />
                
                <Route path="/AffiliateDebugPanel" element={<AffiliateDebugPanel />} />
                
                <Route path="/ForgotPassword" element={<ForgotPassword />} />
                
                <Route path="/ResetPassword" element={<ResetPassword />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}