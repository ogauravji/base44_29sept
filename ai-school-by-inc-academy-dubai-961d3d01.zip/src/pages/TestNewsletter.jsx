import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { subscribeNewsletter } from "@/api/functions";

export default function TestNewsletter() {
    const [email, setEmail] = useState("");
    const [result, setResult] = useState("");
    const [loading, setLoading] = useState(false);

    const testSubscription = async () => {
        if (!email) {
            setResult("Please enter an email");
            return;
        }

        setLoading(true);
        setResult("Testing...");

        try {
            const response = await subscribeNewsletter({ email, source: 'test' });
            console.log('Full response:', response);
            
            if (response.data.success) {
                setResult(`✅ Success: ${response.data.message}`);
            } else {
                setResult(`❌ Error: ${response.data.error}`);
            }
        } catch (error) {
            console.error('Test error:', error);
            setResult(`❌ Exception: ${error.message}`);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 py-8 px-4">
            <div className="max-w-2xl mx-auto">
                <h1 className="text-3xl font-bold mb-8">Newsletter Test Page</h1>
                
                <div className="bg-white p-6 rounded-lg shadow">
                    <div className="mb-4">
                        <label className="block text-sm font-medium text-gray-700 mb-2">
                            Test Email Address
                        </label>
                        <input
                            type="email"
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md"
                            placeholder="test@example.com"
                        />
                    </div>
                    
                    <Button 
                        onClick={testSubscription}
                        disabled={loading}
                        className="w-full mb-4"
                    >
                        {loading ? "Testing..." : "Test Newsletter Subscription"}
                    </Button>
                    
                    {result && (
                        <div className="p-4 bg-gray-100 rounded border">
                            <h3 className="font-medium mb-2">Result:</h3>
                            <pre className="text-sm whitespace-pre-wrap">{result}</pre>
                        </div>
                    )}
                </div>
                
                <div className="mt-8 bg-yellow-50 p-4 rounded border border-yellow-200">
                    <h3 className="font-medium text-yellow-800 mb-2">Debugging Steps:</h3>
                    <ol className="list-decimal list-inside text-sm text-yellow-700 space-y-1">
                        <li>Check browser console for errors</li>
                        <li>Verify SENDGRID_API_KEY is set in environment variables</li>
                        <li>Check spam/junk folder</li>
                        <li>Verify 'hello@incacademy.ae' is verified in SendGrid</li>
                        <li>Check SendGrid activity logs</li>
                    </ol>
                </div>
            </div>
        </div>
    );
}