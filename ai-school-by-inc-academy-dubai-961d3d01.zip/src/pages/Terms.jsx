
import React, { useEffect } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, Users, CreditCard, AlertTriangle, Mail, Phone } from "lucide-react";

export default function Terms() {
  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "Terms & Conditions | AI Marketing Training Dubai UAE - Inc. Academy Legal Agreement";
    const description = "Terms and conditions for Inc. Academy AI marketing training in Dubai, UAE. Review the legal agreement for our ChatGPT courses, corporate workshops, consultancy, and agency services in UAE.";
    const imageUrl = "https://static.wixstatic.com/media/ad9f8f_569c63b1629540f2b143e3c3085Bdfd4~mv2.png/v1/fill/w_476,h_92,al_c,q_85,usm_0.66_1.00_0.01,enc_avif,quality_auto/Inc_Academy_Logo_Transparent_edited.png";
    
    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);
  }, []);

  return (
    <div className="min-h-screen bg-white py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="px-6 py-3 text-base font-semibold bg-blue-50 text-blue-600 border-0 mb-8">
            <FileText className="w-5 h-5 mr-2" />
            Legal Agreement
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            Terms & Conditions
          </h1>
          <p className="text-xl text-gray-600 leading-relaxed">
            Last updated: January 2025
          </p>
        </div>

        {/* Content */}
        <div className="space-y-8">
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Users className="w-6 h-6 text-blue-600" />
                Acceptance of Terms
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed">
                By accessing and using Inc Academy's services, including our website, courses, workshops, 
                consultancy services, and agency solutions, you accept and agree to be bound by the terms 
                and provision of this agreement. If you do not agree to abide by the above, please do not 
                use this service.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <FileText className="w-6 h-6 text-blue-600" />
                Services Description
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                Inc Academy provides the following services:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• AI Marketing training programs and courses</li>
                <li>• Corporate workshops and team training</li>
                <li>• AI strategy consultancy services</li>
                <li>• Done-for-you marketing agency services</li>
                <li>• Educational content and resources</li>
              </ul>
              <p className="text-gray-600 leading-relaxed mt-4">
                We reserve the right to modify, suspend, or discontinue any service at our discretion 
                with reasonable notice to affected users.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <CreditCard className="w-6 h-6 text-blue-600" />
                Payment Terms
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                Payment terms and conditions:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• All fees are payable in advance unless otherwise agreed</li>
                <li>• Payments are processed securely through Stripe</li>
                <li>• Prices are subject to change with 30 days notice</li>
                <li>• Refunds are provided according to our refund policy</li>
                <li>• Corporate training fees are due upon completion unless otherwise agreed</li>
                <li>• Currency conversions may apply for international payments</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <AlertTriangle className="w-6 h-6 text-blue-600" />
                Refund Policy
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                Our refund policy is as follows:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• Course registrations: Full refund if cancelled 7 days before start date</li>
                <li>• Workshop registrations: 50% refund if cancelled 48 hours before event</li>
                <li>• Consultancy services: Refund available for unused hours within 30 days</li>
                <li>• Agency services: Refunds evaluated case-by-case based on work completed</li>
                <li>• Digital products: No refunds after access has been granted</li>
              </ul>
              <p className="text-gray-600 leading-relaxed mt-4">
                Refund requests must be submitted in writing to hello@inc.academy.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <Users className="w-6 h-6 text-blue-600" />
                User Responsibilities
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                As a user of our services, you agree to:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• Provide accurate and current information</li>
                <li>• Use our services only for lawful purposes</li>
                <li>• Respect intellectual property rights</li>
                <li>• Not share access credentials with others</li>
                <li>• Comply with all applicable laws and regulations</li>
                <li>• Maintain confidentiality of proprietary information shared</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <FileText className="w-6 h-6 text-blue-600" />
                Intellectual Property
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed mb-4">
                All content, materials, and intellectual property provided by Inc Academy remain 
                our exclusive property. This includes:
              </p>
              <ul className="space-y-2 text-gray-600">
                <li>• Course materials, videos, and presentations</li>
                <li>• Proprietary methodologies and frameworks</li>
                <li>• Software tools and templates</li>
                <li>• Brand assets and trademarks</li>
              </ul>
              <p className="text-gray-600 leading-relaxed mt-4">
                Users are granted a limited, non-transferable license to use materials solely for 
                their intended educational or business purpose.
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-3 text-2xl">
                <AlertTriangle className="w-6 h-6 text-blue-600" />
                Limitation of Liability
              </CardTitle>
            </CardHeader>
            <CardContent className="prose prose-gray max-w-none">
              <p className="text-gray-600 leading-relaxed">
                Inc Academy shall not be liable for any indirect, incidental, special, consequential, 
                or punitive damages arising out of your use of our services. Our total liability shall 
                not exceed the amount paid by you for the specific service in question. This limitation 
                applies regardless of the legal theory under which liability is asserted.
              </p>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card className="border-0 shadow-lg bg-gradient-to-r from-blue-50 to-purple-50">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Contact Us</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-600 mb-6">
                If you have any questions about these Terms & Conditions, please contact us:
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                <div className="flex items-center gap-2 text-gray-700">
                  <Mail className="w-5 h-5 text-blue-600" />
                  <span>hello@inc.academy</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <Phone className="w-5 h-5 text-blue-600" />
                  <span>+971 52 437 1377</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
