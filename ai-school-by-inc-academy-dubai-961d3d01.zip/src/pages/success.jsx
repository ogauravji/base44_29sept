import React, { useEffect } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Users, MessageCircle, ArrowRight, Home, Mail, Phone, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { motion } from "framer-motion";

export default function Success() {
  useEffect(() => {
    // --- Meta Pixel Purchase Event ---
    if (window.fbq) {
      const value = 99.00;
      const currency = 'USD';
      
      window.fbq('track', 'Purchase', {
        value: value,
        currency: currency,
      });
      console.log('Facebook Pixel Purchase event tracked.');
    } else {
      console.log('Facebook Pixel not found.');
    }
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-indigo-50">
      <div className="max-w-4xl mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring" }}
            className="w-24 h-24 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-8"
          >
            <CheckCircle className="w-12 h-12 text-white" />
          </motion.div>

          <motion.h1
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="text-4xl md:text-5xl font-bold text-gray-900 mb-6"
          >
            🎉 Welcome to the AI Revolution!
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-xl text-gray-700 mb-12 max-w-2xl mx-auto"
          >
            Your payment was successful! You're now enrolled in our program. 
            Get ready to transform your career with cutting-edge AI skills.
          </motion.p>

          {/* Next Steps Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="bg-white rounded-2xl shadow-xl p-8 mb-8"
          >
            <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center justify-center gap-3">
              <Sparkles className="w-6 h-6 text-blue-600" />
              Your Next Steps
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-xl">
                <div className="w-8 h-8 bg-blue-500 text-white rounded-full flex items-center justify-center font-semibold text-sm flex-shrink-0">
                  1
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Check Your Email</h3>
                  <p className="text-gray-600 text-sm">You'll receive a confirmation email with all the session details and joining instructions shortly.</p>
                </div>
              </div>
              <div className="flex items-start gap-4 p-4 bg-green-50 rounded-xl">
                <div className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center font-semibold text-sm flex-shrink-0">
                  2
                </div>
                <div>
                  <h3 className="font-semibold text-gray-900 mb-2">Join Our Community</h3>
                  <p className="text-gray-600 text-sm">Connect with fellow learners on WhatsApp for updates and networking.</p>
                </div>
              </div>
            </div>
          </motion.div>

          {/* WhatsApp Community Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="space-y-4"
          >
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center justify-center gap-2">
                <Users className="w-5 h-5 text-green-600" />
                Join Our WhatsApp Community
              </h3>
              <p className="text-gray-600 mb-6 text-sm">
                Get instant updates, connect with fellow learners, and access exclusive content.
              </p>
              <div className="space-y-3">
                <Button asChild className="w-full bg-blue-600 hover:bg-blue-700 text-white group">
                  <a href="https://chat.whatsapp.com/J0cD1sr5c5MHH2kH8a9lXI?mode=ac_t" target="_blank" rel="noopener noreferrer">
                    <MessageCircle className="w-5 h-5 mr-2" />
                    Join WhatsApp Group
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </a>
                </Button>
                <Button asChild variant="outline" className="w-full">
                  <Link to="/">
                    <Home className="w-5 h-5 mr-2" />
                    Back to Homepage
                  </Link>
                </Button>
              </div>
            </div>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7 }}
            className="mt-12 text-center"
          >
            <p className="text-gray-600 mb-4">
              Have questions? We're here to help!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a
                href="mailto:hello@inc.academy"
                className="flex items-center gap-2 text-blue-600 hover:text-blue-700 justify-center"
              >
                <Mail className="w-4 h-4" />
                hello@inc.academy
              </a>
              <a
                href="https://wa.me/971524371377"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 text-green-600 hover:text-green-700 justify-center"
              >
                <Phone className="w-4 h-4" />
                +971 52 437 1377
              </a>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}