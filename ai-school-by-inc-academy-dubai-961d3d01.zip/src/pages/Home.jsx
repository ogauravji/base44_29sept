
import React from "react";
import { createPageUrl } from "@/utils";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";

// Lazy load all sections for optimal performance
const BreakingNewsSection = React.lazy(() => import('../components/home/BreakingNewsSection'));
const CareerTransformSection = React.lazy(() => import('../components/home/CareerTransformSection'));
const FutureOfAISection = React.lazy(() => import('../components/home/FutureOfAISection'));
const WhyNowSection = React.lazy(() => import('../components/home/WhyNowSection'));
const OfferingsSection = React.lazy(() => import('../components/home/OfferingsSection'));
const ClientLogosSection = React.lazy(() => import('../components/home/ClientLogosSection'));
const DifferentiatorsSection = React.lazy(() => import('../components/home/DifferentiatorsSection'));
const AIJobsSection = React.lazy(() => import('../components/home/AIJobsSection'));
const AIDisruptingSection = React.lazy(() => import('../components/home/AIDisruptingSection'));
const AILeadershipSection = React.lazy(() => import('../components/home/AILeadershipSection'));
const AboutIncAcademySection = React.lazy(() => import('../components/home/AboutIncAcademySection'));
const FinalCTASection = React.lazy(() => import('../components/home/FinalCTASection'));

const LoadingFallback = () => <div className="h-64 w-full bg-gray-50 animate-pulse"></div>;

export default function Home() {
  // Simplified SEO setup
  React.useEffect(() => {
    document.title = "AI Training for Corporates in Dubai & GCC | Inc Academy";
    const metaDesc = document.querySelector('meta[name="description"]') || document.createElement('meta');
    metaDesc.name = "description";
    metaDesc.content = "Enterprise AI upskilling for HR, L&D, marketing, sales, and leadership. Workshops, courses, and implementation with governance, compliance, and ROI focus across UAE & GCC.";
    if (!document.querySelector('meta[name="description"]')) {
      document.head.appendChild(metaDesc);
    }
  }, []);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section - Optimized for instant loading */}
      <section className="relative bg-gray-900 text-white">
        <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-blue-900 to-black opacity-90"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 md:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Column: Text Content */}
            <div className="text-center lg:text-left">
              <div className="mb-6">
                <Badge className="px-6 py-3 text-base font-semibold bg-white/10 text-white border border-white/20 rounded-full">
                  <Sparkles className="w-5 h-5 mr-3 text-yellow-400" />
                  Generative AI Solutions
                </Badge>
              </div>
              <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6 leading-tight">
                Master the AI Essentials.
                <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-teal-400 bg-clip-text text-transparent block mt-2">
                  Transform Your Career.
                </span>
              </h1>
              <p className="text-xl text-gray-300 mb-10 max-w-xl mx-auto lg:mx-0 leading-relaxed">
                Unlock your potential with expert-led AI training, strategic consultancy, and hands-on implementation services designed for business professionals in the UAE.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <Button asChild size="lg" className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-4 text-lg font-semibold rounded-xl">
                  <Link to={createPageUrl("ai-courses")}>
                    Explore Courses
                    <ArrowRight className="w-5 h-5 ml-2" />
                  </Link>
                </Button>
              </div>
            </div>

            {/* Right Column: Optimized Image */}
            <div className="relative hidden lg:block">
              <div className="w-full aspect-square bg-white/5 rounded-3xl p-4">
                <img
                  src="https://i.imghippo.com/files/JUt9783Sw.jpeg"
                  alt="AI Training Dubai UAE"
                  className="w-full h-full object-cover rounded-2xl"
                  loading="eager"
                  decoding="async"
                  width="600"
                  height="600"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Lazy loaded sections with simple fallbacks */}
      <React.Suspense fallback={<LoadingFallback />}>
        <BreakingNewsSection />
      </React.Suspense>
      
      <React.Suspense fallback={<LoadingFallback />}>
        <ClientLogosSection />
      </React.Suspense>
      
      <React.Suspense fallback={<LoadingFallback />}>
        <CareerTransformSection />
      </React.Suspense>
      
      <React.Suspense fallback={<LoadingFallback />}>
        <FutureOfAISection />
      </React.Suspense>
      
      <React.Suspense fallback={<LoadingFallback />}>
        <WhyNowSection />
      </React.Suspense>

      <React.Suspense fallback={<LoadingFallback />}>
        <DifferentiatorsSection />
      </React.Suspense>

      <React.Suspense fallback={<LoadingFallback />}>
        <AIDisruptingSection />
      </React.Suspense>

      <React.Suspense fallback={<LoadingFallback />}>
        <OfferingsSection />
      </React.Suspense>

      <React.Suspense fallback={<LoadingFallback />}>
        <AIJobsSection />
      </React.Suspense>
      
      <React.Suspense fallback={<LoadingFallback />}>
        <AILeadershipSection />
      </React.Suspense>

      <React.Suspense fallback={<LoadingFallback />}>
        <AboutIncAcademySection />
      </React.Suspense>
      
      <React.Suspense fallback={<LoadingFallback />}>
        <FinalCTASection />
      </React.Suspense>
    </div>
  );
}
