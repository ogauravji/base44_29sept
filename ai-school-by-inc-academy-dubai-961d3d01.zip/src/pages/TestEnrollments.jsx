import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Enrollment } from '@/api/entities';
import { User } from '@/api/entities';
import { RefreshCw, Download, Users, DollarSign, Calendar, Mail } from 'lucide-react';

export default function TestEnrollments() {
    const [enrollments, setEnrollments] = useState([]);
    const [loading, setLoading] = useState(true);
    const [user, setUser] = useState(null);

    useEffect(() => {
        loadData();
    }, []);

    const loadData = async () => {
        try {
            setLoading(true);
            const currentUser = await User.me();
            setUser(currentUser);
            
            const enrollmentData = await Enrollment.list('-created_date', 50);
            setEnrollments(enrollmentData);
        } catch (error) {
            console.error('Error loading data:', error);
        } finally {
            setLoading(false);
        }
    };

    const getStatusColor = (status) => {
        switch(status) {
            case 'completed': return 'bg-green-100 text-green-800';
            case 'pending': return 'bg-yellow-100 text-yellow-800';
            case 'failed': return 'bg-red-100 text-red-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const getCourseColor = (courseType) => {
        switch(courseType) {
            case 'mastermind-session': return 'bg-blue-100 text-blue-800';
            case 'online-cohort': return 'bg-purple-100 text-purple-800';
            case 'ai-accelerator': return 'bg-orange-100 text-orange-800';
            case 'complete-bundle': return 'bg-green-100 text-green-800';
            default: return 'bg-gray-100 text-gray-800';
        }
    };

    const totalRevenue = enrollments
        .filter(e => e.payment_status === 'completed')
        .reduce((sum, e) => sum + (e.amount_paid || 0), 0);

    const completedEnrollments = enrollments.filter(e => e.payment_status === 'completed').length;

    if (!user) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-50">
                <div className="text-center">
                    <h1 className="text-2xl font-bold text-gray-900 mb-4">Access Denied</h1>
                    <p className="text-gray-600">You need to be logged in to view enrollments.</p>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-7xl mx-auto">
                <div className="mb-8">
                    <div className="flex justify-between items-center mb-6">
                        <h1 className="text-3xl font-bold text-gray-900">Enrollment Dashboard</h1>
                        <Button onClick={loadData} disabled={loading} className="flex items-center gap-2">
                            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                            Refresh
                        </Button>
                    </div>

                    {/* Stats Cards */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">Total Enrollments</CardTitle>
                                <Users className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">{enrollments.length}</div>
                                <p className="text-xs text-muted-foreground">
                                    {completedEnrollments} completed
                                </p>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
                                <DollarSign className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">
                                    ${(totalRevenue / 100).toLocaleString()}
                                </div>
                                <p className="text-xs text-muted-foreground">
                                    From completed payments
                                </p>
                            </CardContent>
                        </Card>

                        <Card>
                            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                                <CardTitle className="text-sm font-medium">Latest Enrollment</CardTitle>
                                <Calendar className="h-4 w-4 text-muted-foreground" />
                            </CardHeader>
                            <CardContent>
                                <div className="text-2xl font-bold">
                                    {enrollments[0] ? new Date(enrollments[0].created_date).toLocaleDateString() : 'None'}
                                </div>
                                <p className="text-xs text-muted-foreground">
                                    Most recent signup
                                </p>
                            </CardContent>
                        </Card>
                    </div>
                </div>

                {/* Enrollments List */}
                <Card>
                    <CardHeader>
                        <CardTitle>Recent Enrollments</CardTitle>
                    </CardHeader>
                    <CardContent>
                        {loading ? (
                            <div className="flex items-center justify-center py-8">
                                <RefreshCw className="w-6 h-6 animate-spin text-blue-600" />
                                <span className="ml-2">Loading enrollments...</span>
                            </div>
                        ) : enrollments.length === 0 ? (
                            <div className="text-center py-8 text-gray-500">
                                No enrollments found. Webhook might not be receiving data yet.
                            </div>
                        ) : (
                            <div className="space-y-4">
                                {enrollments.map((enrollment) => (
                                    <div key={enrollment.id} className="border rounded-lg p-4 hover:bg-gray-50">
                                        <div className="flex flex-wrap items-center justify-between gap-4">
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center gap-3 mb-2">
                                                    <h3 className="font-semibold text-gray-900 truncate">
                                                        {enrollment.customer_name || 'Unknown Customer'}
                                                    </h3>
                                                    <Badge className={getStatusColor(enrollment.payment_status)}>
                                                        {enrollment.payment_status}
                                                    </Badge>
                                                </div>
                                                <div className="flex items-center gap-2 text-sm text-gray-600 mb-1">
                                                    <Mail className="w-4 h-4" />
                                                    {enrollment.user_email}
                                                </div>
                                                <div className="text-sm text-gray-500">
                                                    {new Date(enrollment.created_date).toLocaleString()}
                                                </div>
                                            </div>
                                            <div className="flex items-center gap-3">
                                                <Badge className={getCourseColor(enrollment.course_type)}>
                                                    {enrollment.course_type?.replace('-', ' ')}
                                                </Badge>
                                                <div className="text-right">
                                                    <div className="font-semibold">
                                                        ${enrollment.amount_paid ? (enrollment.amount_paid / 100).toFixed(2) : '0.00'}
                                                    </div>
                                                    <div className="text-sm text-gray-500 uppercase">
                                                        {enrollment.currency || 'USD'}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        {enrollment.stripe_session_id && (
                                            <div className="mt-2 text-xs text-gray-400">
                                                Stripe ID: {enrollment.stripe_session_id}
                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                        )}
                    </CardContent>
                </Card>

                {/* Instructions */}
                <Card className="mt-8">
                    <CardHeader>
                        <CardTitle>Webhook Setup Instructions</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <h4 className="font-semibold mb-2">1. Get your webhook URL:</h4>
                            <code className="bg-gray-100 px-3 py-1 rounded text-sm">
                                https://ai.inc.academy/api/webhook
                            </code>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2">2. In your Stripe dashboard:</h4>
                            <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
                                <li>Go to Developers → Webhooks</li>
                                <li>Click "Add endpoint"</li>
                                <li>Paste the webhook URL above</li>
                                <li>Select event: <code>checkout.session.completed</code></li>
                                <li>Copy the webhook signing secret to your environment variables</li>
                            </ul>
                        </div>
                        <div>
                            <h4 className="font-semibold mb-2">3. Environment Variables Needed:</h4>
                            <ul className="list-disc list-inside space-y-1 text-sm text-gray-600">
                                <li><code>STRIPE_API_KEY</code> - Your Stripe secret key</li>
                                <li><code>STRIPE_WEBHOOK_SECRET</code> - Webhook signing secret from step 2</li>
                            </ul>
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}