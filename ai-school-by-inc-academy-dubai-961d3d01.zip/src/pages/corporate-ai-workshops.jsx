
import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Users,
  Building,
  Target,
  TrendingUp,
  Zap,
  CheckCircle2,
  ArrowRight,
  Download,
  Calendar,
  Clock,
  Award,
  Brain,
  Bot,
  ShoppingBag,
  Package,
  Home,
  Banknote,
  HeartHandshake,
  Plane,
  GraduationCap,
  Sparkles,
  DollarSign,
  Rocket,
  BrainCircuit,
  Globe
} from "lucide-react";
import { motion } from "framer-motion";
import InquiryFormModal from "../components/common/InquiryFormModal";
import { Link } from "react-router-dom";

const industries = [
  {
    name: "Retail & E-commerce",
    icon: ShoppingBag,
    color: "from-green-500 to-emerald-500",
    agents: ["Product Copywriter Agent", "Cart Abandonment Rescuer", "Review Summarizer Bot"]
  },
  {
    name: "Real Estate",
    icon: Home,
    color: "from-cyan-500 to-teal-500",
    agents: ["Listing Intelligence Bot", "Lead Nurture Agent", "ROI Projection Bot"]
  },
  {
    name: "FMCG",
    icon: Package,
    color: "from-orange-500 to-red-500",
    agents: ["Retail Shelf Intelligence", "Demand Forecasting Bot", "Distributor Assistant"]
  },
  {
    name: "Education",
    icon: GraduationCap,
    color: "from-violet-500 to-purple-500",
    agents: ["Course Builder Agent", "AI Tutor Bot", "Assignment Feedback Agent"]
  },
  {
    name: "Finance & Banking",
    icon: Banknote,
    color: "from-emerald-500 to-green-600",
    agents: ["Credit Risk Analyzer", "Portfolio Summary Agent", "AML Compliance Bot"]
  },
  {
    name: "Hospitality",
    icon: Plane,
    color: "from-amber-500 to-orange-500",
    agents: ["Trip Planner Agent", "Hotel Recommender Bot", "Event Concierge Bot"]
  }
];

const detailedWorkshopSessions = [
  {
    session: "Opening Keynote",
    title: "The Generative AI Revolution: Understanding the Business Landscape",
    duration: "60 mins",
    time: "9:00 AM - 10:00 AM",
    topics: [
      "Global AI automation adoption statistics and market trends",
      "How Generative AI is reshaping customer expectations",
      "Competitive analysis: Leaders vs. Laggards in AI workflow automation implementation",
      "ROI case studies from Fortune 500 companies using AI for executives programs",
      "Common myths and misconceptions about AI strategy in business"
    ],
    examples: [
      "Marketing: Use AI for productivity to analyze competitor press releases and generate strategic positioning insights",
      "Sales: Create AI-powered competitor battlecards for your sales team using AI automation",
      "Leadership: Generate executive summaries of industry AI adoption trends for AI for executives programs"
    ],
    deliverable: "AI Readiness Assessment Framework"
  },
  {
    session: "Workshop 1",
    title: "Industry-Specific Generative AI Applications & Hands-on Setup",
    duration: "90 mins",
    time: "10:15 AM - 11:45 AM",
    topics: [
      "Deep-dive into AI for corporate training use cases for your specific industry",
      "Live setup of ChatGPT Pro and Claude for AI for executives applications",
      "Department-by-department AI workflow automation opportunity mapping",
      "Creating your first AI generalist agents with custom instructions",
      "Quick-win identification for immediate AI for productivity implementation"
    ],
    examples: [
      "Marketing: Build a custom GPT for AI for CMOs that answers questions based on your brand guidelines",
      "HR: Create an AI for managers assistant for employee onboarding and policy Q&A",
      "Operations: Develop AI automation workflows for inventory management and supply chain optimization",
      "Sales: Set up AI for entrepreneurs agents for lead qualification and follow-up automation"
    ],
    deliverable: "Custom AI Opportunity Matrix + Configured AI Accounts"
  },
  {
    session: "Interactive Session",
    title: "Prompt Engineering Masterclass for Business Leaders",
    duration: "75 mins",
    time: "1:00 PM - 2:15 PM",
    topics: [
      "Advanced prompt frameworks for AI in business scenarios",
      "Creating brand-specific AI for corporate training communication guidelines",
      "Prompt templates for emails, reports, and presentations using AI for productivity",
      "Quality control and consistency mechanisms for AI generalist applications",
      "Building internal prompt libraries for AI for consultants teams"
    ],
    examples: [
      "Leadership: Develop CEO-style email templates for any team member to use with AI for business leaders",
      "PR: Create brand-consistent press release and media response templates using Generative AI",
      "Digital Marketing: Build AI for growth marketing campaign brief generators for different channels",
      "CRM: Design customer communication templates that maintain brand voice with AI workflow automation"
    ],
    deliverable: "Executive Prompt Template Library (50+ Templates)"
  },
  {
    session: "Hands-On Lab",
    title: "AI Automation Workshop with Live Implementation",
    duration: "105 mins",
    time: "2:30 PM - 4:15 PM",
    topics: [
      "Marketing automation with AI workflow automation-powered workflows",
      "Finance and operations AI for executives tools demonstration",
      "HR and recruitment AI for managers assistant configuration",
      "Integration strategies with existing CRM/ERP systems using AI automation",
      "Building your first automated workflow as an AI generalist"
    ],
    examples: [
      "Campaign Optimization: Auto-adjust ad spend based on performance metrics using AI for productivity",
      "Sales: Create AI for entrepreneurs workflows that send personalized follow-ups via HubSpot AI",
      "HR: Automate candidate screening and interview scheduling processes with AI for corporate training",
      "Operations: Build approval workflows with AI-generated summaries and recommendations for AI for business leaders"
    ],
    deliverable: "Live Automated Workflows + Integration Roadmap"
  },
  {
    session: "Strategy Session",
    title: "90-Day AI Implementation & Leadership Plan for Business Transformation",
    duration: "60 mins",
    time: "4:30 PM - 5:30 PM",
    topics: [
      "Creating your company&apos;s AI strategy course transformation roadmap",
      "Change management strategies for AI for executives adoption",
      "Team training and upskilling frameworks for AI generalist development",
      "Success metrics and KPI establishment for AI in business course outcomes",
      "Budget allocation and ROI tracking systems for AI workflow automation"
    ],
    examples: [
      "Leadership: Use AI for consultants project management tools for implementation planning",
      "HR: Develop AI for managers skills assessment and training programs for teams",
      "Marketing: Create measurement frameworks for AI for CMOs-driven campaign performance",
      "Operations: Build ROI tracking dashboards for AI automation tool adoption across departments"
    ],
    deliverable: "Complete 90-Day Implementation Blueprint + Team Training Plan"
  }
];

const clientLogos = [
  { src: "https://i.imghippo.com/files/AIj7022XwI.png", alt: "Google" },
  { src: "https://i.imghippo.com/files/BtVJ7689eU.png", alt: "TikTok" },
  { src: "https://i.imghippo.com/files/zETQ9249BY.png", alt: "Dubai Tourism" },
  { src: "https://i.imghippo.com/files/LjWL1133fc.png", alt: "Emirates" },
  { src: "https://i.imghippo.com/files/RymB7570vQ.png", alt: "Alshaya" },
  { src: "https://i.imghippo.com/files/IPE5684MnM.png", alt: "Unilever" },
  { src: "https://i.imghippo.com/files/QUIK6243XI.png", alt: "Etihad" },
  { src: "https://i.imghippo.com/files/CBg5407ZEg.png", alt: "Harvard Business School" }
];

const createPageUrl = (path) => `/${path}`;

export default function CorporateAIWorkshops() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalContent, setModalContent] = useState({ title: "", subtitle: "" });

  useEffect(() => {
    const setMetaTag = (attr, attrValue, content) => {
      let element = document.querySelector(`meta[${attr}="${attrValue}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attr, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    const title = "Corporate AI Workshops & In-House Training | UAE & GCC";
    const description = "Custom onsite and virtual workshops for marketing, HR, ops, finance, and CX. 1–2 day masterclasses with use-cases, templates, governance, and measurable business impact.";
    const keywords = "corporate AI training UAE, in-house AI workshop Dubai, executive AI workshop, AI for HR UAE, AI for marketing Dubai, AI masterclass GCC, AI governance training, AI policy UAE";
    const imageUrl = "https://i.imghippo.com/files/tfUo2263Io.png";

    document.title = title;
    setMetaTag('name', 'description', description);
    setMetaTag('name', 'keywords', keywords);
    setMetaTag('property', 'og:title', title);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:image', imageUrl);
    setMetaTag('property', 'og:url', window.location.href);
    setMetaTag('property', 'og:type', 'website');
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', title);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', imageUrl);

    // Schema.org structured data
    const script = document.createElement('script');
    script.type = 'application/ld+json';
    script.textContent = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Service",
      "name": "Corporate AI Workshops",
      "description": description,
      "provider": {
        "@type": "Organization",
        "name": "Inc Academy",
        "url": "https://ai.inc.academy"
      },
      "serviceType": "Training",
      "areaServed": ["UAE", "GCC"]
    });
    document.head.appendChild(script);
  }, []);

  const openModal = (type) => {
    if (type === 'deck') {
      setModalContent({
        title: "Download Corporate AI Training Deck",
        subtitle: "Please provide your details to receive the comprehensive corporate AI workshop deck."
      });
    } else {
      setModalContent({
        title: "Book AI Strategy Discovery Call",
        subtitle: "Schedule a call to discuss a customized AI for executives workshop for your team."
      });
    }
    setIsModalOpen(true);
  };

  return (
    <>
      <InquiryFormModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={modalContent.title}
        subtitle={modalContent.subtitle}
      />

      <div className="min-h-screen bg-white">
        {/* Hero Section */}
        <section className="relative py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 text-white overflow-hidden">
          <div className="absolute top-10 right-10 w-32 h-32 md:w-96 md:h-96 bg-white/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-10 left-10 w-32 h-32 md:w-96 md:h-96 bg-purple-300/20 rounded-full blur-3xl"></div>

          <div className="relative max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-8 md:gap-12 items-center">
              <div className="text-center lg:text-left">
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8 }}
                  className="mb-6 md:mb-8">
                  <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-white/20 text-white border border-white/30 backdrop-blur-sm hover:bg-white hover:text-purple-700 transition-all duration-300">
                    <Building className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                    Corporate AI Transformation
                  </Badge>
                </motion.div>

                <motion.h1
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.2 }}
                  className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-8 md:mb-10 leading-tight pb-2">
                  <span className="text-white block">AI Workshops Designed for</span>
                  <span className="bg-gradient-to-r from-yellow-300 to-orange-300 bg-clip-text text-transparent block mt-2">Business Teams</span>
                </motion.h1>

                <motion.p
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.4 }}
                  className="text-lg sm:text-xl md:text-2xl text-blue-100 mb-8 md:mb-12 max-w-3xl mx-auto lg:mx-0 leading-relaxed font-light">
                  Transform your leadership team with strategic Generative AI implementation across departments.
                  Comprehensive AI for executives training designed for immediate business impact and competitive advantage.
                </motion.p>

                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.6 }}
                  className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center lg:justify-start">
                  <Button
                    size="lg"
                    className="w-full sm:w-auto bg-white text-gray-900 px-6 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-2xl shadow-lg group transition-all duration-300 hover:bg-gray-100"
                    onClick={() => openModal('call')}>
                    Book AI Discovery Call
                    <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                  <Button
                    size="lg"
                    className="w-full sm:w-auto bg-white/20 text-white px-6 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-2xl shadow-lg group transition-all duration-300 hover:bg-white hover:text-purple-700"
                    onClick={() => openModal('deck')}>
                    Download Training Deck
                    <Download className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-y-0.5 transition-transform" />
                  </Button>
                </motion.div>
              </div>

              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="relative">
                <div className="w-full aspect-[4/3] bg-gradient-to-br from-blue-100/20 to-purple-100/20 rounded-3xl shadow-2xl overflow-hidden backdrop-blur-sm border border-white/20">
                  <img src="https://i.imghippo.com/files/YXo7480AlQ.png" alt="Corporate AI training session - business leaders learning Generative AI" className="w-full h-full object-cover" />
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Detailed Workshop Overview */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12 md:mb-16">
              <Badge className="bg-gradient-to-r from-purple-100 to-pink-100 text-purple-700 border border-purple-200 mb-6 md:mb-8 px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold hover:bg-purple-600 hover:text-white hover:border-purple-600 transition-all duration-300">
                <Calendar className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Sample 1-Day Executive AI Workshop (9 AM - 5:30 PM)
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 md:mb-8 leading-tight pb-2">
                <span className="bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent block">Complete Executive</span>
                <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent block mt-2">AI Workshop</span>
              </h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed px-4 sm:px-0">
                Intensive, hands-on AI strategy course designed for C-suite executives and department heads.
                Full-day immersive experience with immediate actionable outcomes and live AI automation tool setup.
              </p>
            </div>

            <div className="space-y-6 md:space-y-8">
              {detailedWorkshopSessions.map((session, index) =>
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}>
                  <Card className="border border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300 rounded-3xl overflow-hidden bg-white">
                    <CardHeader className="pb-4 bg-gradient-to-r from-blue-50 to-purple-50">
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div className="flex items-start gap-4">
                          <div className="w-12 h-12 md:w-16 md:h-16 bg-gradient-to-r from-indigo-500 to-blue-600 rounded-2xl flex items-center justify-center text-white font-bold text-lg md:text-xl shadow-lg">
                            {index + 1}
                          </div>
                          <div className="flex-1 min-w-0">
                            <Badge variant="outline" className="mb-2 text-xs font-medium border border-gray-200 bg-gray-100 text-gray-700 rounded-full py-1 px-3">{session.session}</Badge>
                            <CardTitle className="text-lg md:text-xl lg:text-2xl font-bold text-gray-800 leading-tight">
                              {session.title}
                            </CardTitle>
                            <div className="flex flex-wrap items-center gap-4 mt-3 text-sm text-gray-600">
                              <div className="flex items-center gap-1">
                                <Clock className="w-4 h-4" />
                                <span className="font-medium">{session.duration}</span>
                              </div>
                              <div className="flex items-center gap-1">
                                <Calendar className="w-4 h-4" />
                                <span>{session.time}</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-6 md:p-8 bg-white">
                      <div className="grid lg:grid-cols-2 gap-6 mb-6">
                        <div>
                          <h4 className="font-semibold text-dark mb-4 flex items-center gap-2">
                            <Target className="w-5 h-5 text-indigo-600" />
                            Key Learning Objectives:
                          </h4>
                          <div className="space-y-3">
                            {session.topics.map((topic, topicIndex) =>
                              <div key={topicIndex} className="flex items-start gap-2">
                                <CheckCircle2 className="w-4 h-4 text-indigo-600 flex-shrink-0 mt-1" />
                                <span className="text-gray-700 text-sm leading-relaxed">{topic}</span>
                              </div>
                            )}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold text-dark mb-4 flex items-center gap-2">
                            <Sparkles className="w-5 h-5 text-blue-500" />
                            Department-Specific Examples:
                          </h4>
                          <div className="space-y-3">
                            {session.examples.map((example, exampleIndex) =>
                              <div key={exampleIndex} className="bg-blue-50 border-l-4 border-blue-400 p-3 rounded-r-lg">
                                <p className="text-gray-700 text-sm italic">{example}</p>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-4 md:p-6 border border-purple-200">
                        <h5 className="font-semibold text-dark mb-2 flex items-center gap-2">
                          <Award className="w-5 h-5 text-green-600" />
                          Session Deliverable:
                        </h5>
                        <p className="text-indigo-700 font-medium">{session.deliverable}</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </div>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="mt-16 md:mt-24 text-center">
              <div className="bg-gradient-to-br from-indigo-600 to-blue-600 rounded-3xl p-6 md:p-12 text-white">
                <h3 className="text-2xl md:text-3xl lg:text-4xl font-bold mb-6">
                  Complete AI Workshop Package Includes
                </h3>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
                  {[
                    { icon: Clock, title: "8.5 Hours", desc: "Intensive Training" },
                    { icon: Users, title: "Expert-Led", desc: "Industry Specialists" },
                    { icon: Award, title: "5 Deliverables", desc: "Take-Home Resources" },
                    { icon: Bot, title: "Live Setup", desc: "AI Tools Configured" }].
                    map((item, index) =>
                      <div key={index} className="text-center">
                        <div className="w-12 h-12 md:w-16 md:h-16 bg-indigo-700/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
                          <item.icon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                        </div>
                        <h4 className="font-bold text-lg md:text-xl mb-2">{item.title}</h4>
                        <p className="text-indigo-100">{item.desc}</p>
                      </div>
                    )}
                </div>
              </div>
            </motion.div>
          </div>
        </section>

        {/* Industries We Serve */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12 md:mb-16">
              <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-blue-50 text-blue-600 border border-blue-200 mb-6 md:mb-8 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all duration-300">
                <Target className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Industry Expertise
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-dark mb-4 md:mb-6">
                Industries We
                <span className="bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent block md:inline md:ml-3"> Serve</span>
              </h2>
              <p className="text-lg md:text-xl text-gray-600 max-w-4xl mx-auto font-light leading-relaxed">
                Tailored AI for corporate training workshops with industry-specific use cases, compliance frameworks,
                and AI automation implementation strategies designed for your sector.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
              {industries.map((industry, index) =>
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}>
                  <Card className="border border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300 group cursor-pointer h-full rounded-2xl overflow-hidden">
                    <CardContent className="p-6 md:p-8">
                      <div className="flex items-center gap-4 mb-6">
                        <div className={`w-12 h-12 md:w-16 md:h-16 rounded-xl bg-gradient-to-r ${industry.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                          <industry.icon className="w-6 h-6 md:w-8 md:h-8 text-white" />
                        </div>
                        <h3 className="text-xl md:text-2xl font-bold text-dark group-hover:text-blue-600 transition-colors">
                          {industry.name}
                        </h3>
                      </div>

                      <div>
                        <h4 className="font-semibold text-dark mb-3 text-sm uppercase tracking-wide">
                          Featured AI Agents:
                        </h4>
                        <div className="space-y-2">
                          {industry.agents.map((agent, agentIndex) =>
                            <div key={agentIndex} className="flex items-center gap-2">
                              <Bot className="w-4 h-4 text-blue-600 flex-shrink-0" />
                              <span className="text-gray-600 text-sm font-medium">{agent}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </div>
          </div>
        </section>

        {/* About Inc Academy */}
        <section className="py-16 md:py-24 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-7xl mx-auto">
            <div className="text-center mb-12 md:mb-16">
              <Badge className="px-4 md:px-6 py-2 md:py-3 text-sm md:text-base font-semibold bg-gradient-to-r from-blue-100 to-purple-100 text-blue-700 border border-blue-200 mb-6 md:mb-8 hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-colors">
                <Globe className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                Industry Leadership
              </Badge>
              <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-900 mb-6 md:mb-8 leading-tight pb-1">
                <span className="block">About</span>
                <span className="text-blue-600 block mt-2"> Inc Academy</span>
              </h2>
            </div>

            <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8 }}
                className="relative order-2 lg:order-1">
                <div className="relative z-10">
                  <div className="w-full h-auto bg-gradient-to-br from-blue-100 to-purple-100 rounded-3xl shadow-2xl overflow-hidden ring-4 ring-white/50">
                    <img
                      src="https://i.imghippo.com/files/tfUo2263Io.png"
                      alt="Gaurav Oberoi, Founder of Inc. Academy"
                      className="w-full h-full object-cover rounded-3xl"
                      loading="lazy"
                      decoding="async"
                    />
                  </div>
                </div>
                <div className="absolute top-8 -right-8 w-24 h-24 md:w-32 md:h-32 bg-gradient-to-r from-blue-200/60 to-purple-200/60 rounded-full blur-3xl"></div>
                <div className="absolute -bottom-8 -left-8 w-32 h-32 md:w-40 md:h-40 bg-gradient-to-r from-purple-200/60 to-pink-200/60 rounded-full blur-3xl"></div>
              </motion.div>

              <div className="order-1 lg:order-2">
                <div className="bg-white/70 backdrop-blur-sm rounded-3xl p-8 md:p-10 shadow-xl border border-white/40">
                  <h3 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4 md:mb-6 leading-tight pb-1">
                    15+ Years of Digital Training Legacy
                  </h3>
                  <p className="text-base md:text-lg text-gray-700 leading-relaxed mb-6 md:mb-8">
                    Founded and led by Gaurav Oberoi, Inc Academy has been at the forefront of
                    digital marketing education in the MENA region. We&apos;ve evolved from traditional
                    digital marketing training to become the region&apos;s leading AI marketing transformation partner.
                  </p>

                  <div className="space-y-3 md:space-y-4 mb-6 md:mb-8">
                    {[
                      "Former Google Regional Trainer",
                      "Dubai Tourism consultant for Expo 2020",
                      "TikTok MENA collaborator",
                      "Active startup investor & advisor"].
                      map((achievement, index) =>
                        <div key={index} className="flex items-start gap-2 md:gap-3 p-3 rounded-xl bg-gradient-to-r from-blue-50/80 to-purple-50/80 border border-blue-100">
                          <CheckCircle2 className="w-4 h-4 md:w-5 md:h-5 text-blue-600 flex-shrink-0" />
                          <span className="text-gray-700 text-sm md:text-base font-medium">{achievement}</span>
                        </div>
                      )}
                  </div>

                  <div className="grid grid-cols-2 gap-4 mb-8">
                    <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-2xl text-center border border-blue-200 shadow-sm">
                      <div className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-2">9,000+</div>
                      <p className="text-sm text-gray-600">Professionals Trained</p>
                    </div>
                    <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-2xl text-center border border-purple-200 shadow-sm">
                      <div className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">15+</div>
                      <p className="text-sm text-gray-600">Years Experience</p>
                    </div>
                  </div>

                  <Link to={createPageUrl("about")}>
                    <Button className="w-full sm:w-auto bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 md:px-8 py-3 md:py-4 font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group">
                      More About Gaurav
                      <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Client Logos Section */}
        <section className="bg-white pt-0 pb-16 sm:pb-20 -mt-12 md:-mt-16 relative z-10">
          <div className="mx-auto max-w-5xl px-6 lg:px-8">
            <div className="bg-white rounded-2xl shadow-xl p-8 sm:p-12">
              <div className="mx-auto grid max-w-lg grid-cols-4 items-center gap-x-8 gap-y-10 sm:max-w-xl sm:grid-cols-6 sm:gap-x-10 lg:mx-0 lg:max-w-none lg:grid-cols-8">
                {clientLogos.map((client, index) =>
                  <img
                    key={index}
                    className="col-span-2 max-h-12 w-full object-contain lg:col-span-1 opacity-70 hover:opacity-100 transition-opacity"
                    src={client.src}
                    alt={client.alt}
                    width="158"
                    height="48"
                    loading="lazy"
                    decoding="async"
                  />
                )}
              </div>
            </div>
          </div>
        </section>

        {/* AI Efficiency Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-blue-50 via-indigo-50/50 to-purple-50/30">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <Badge className="px-4 py-2 text-sm font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 mb-6 rounded-full hover:bg-emerald-600 hover:text-white hover:border-emerald-600 transition-all duration-300">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  Business Impact
                </Badge>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-6 leading-tight">
                  <span className="text-gray-900 block">The New Economics of</span>
                  <span className="bg-gradient-to-r from-emerald-600 to-blue-600 bg-clip-text text-transparent block mt-2"> Efficiency</span>
                </h2>
                <p className="text-lg text-gray-700 mb-8 leading-relaxed">
                  Generative AI isn't just a technological advancement; it's an economic revolution for your business. By automating repetitive tasks and providing deep analytical insights, AI workflow automation frees up your most valuable resource—your team—to focus on high-impact strategic work. This shift leads to dramatic improvements in AI for productivity, cost savings, and overall business agility.
                </p>
                <div className="grid sm:grid-cols-2 gap-6">
                  <div className="bg-white/80 p-6 rounded-2xl border border-emerald-100 shadow-lg backdrop-blur-sm">
                    <DollarSign className="w-8 h-8 text-emerald-600 mb-3" />
                    <h4 className="font-bold text-gray-900 text-lg mb-2">Drastic Cost Reduction</h4>
                    <p className="text-gray-600 text-sm">Automate up to 70% of manual data entry and administrative tasks through AI automation.</p>
                  </div>
                  <div className="bg-white/80 p-6 rounded-2xl border border-blue-100 shadow-lg backdrop-blur-sm">
                    <Clock className="w-8 h-8 text-blue-600 mb-3" />
                    <h4 className="font-bold text-gray-900 text-lg mb-2">Accelerated Timelines</h4>
                    <p className="text-gray-600 text-sm">Reduce project timelines and time-to-market by up to 50% with AI workflow automation.</p>
                  </div>
                </div>
              </div>
              <div className="relative">
                <div className="bg-gradient-to-br from-white/90 to-blue-50/70 rounded-3xl p-8 shadow-2xl backdrop-blur-sm border border-white/60">
                  <img src="https://i.imghippo.com/files/VT2668B.png" alt="AI automation dashboard for business efficiency" className="rounded-2xl shadow-lg" />
                </div>
                <div className="absolute top-8 -right-8 w-24 h-24 bg-emerald-200/40 rounded-full blur-3xl"></div>
                <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-blue-200/40 rounded-full blur-3xl"></div>
              </div>
            </div>
          </div>
        </section>

        {/* Future of AI Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-gray-50 to-blue-50">
          <div className="max-w-7xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="hidden lg:block">
                <img src="https://i.imghippo.com/files/oCNQ8363A.jpeg" alt="Future AI automation and business transformation" className="rounded-3xl shadow-xl" />
              </div>
              <div>
                <Badge className="px-4 py-2 text-sm font-semibold bg-purple-50 text-purple-600 border border-purple-200 mb-6 hover:bg-purple-600 hover:text-white hover:border-purple-600 transition-all duration-300">
                  <Rocket className="w-4 h-4 mr-2" />
                  The Next Frontier
                </Badge>
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold text-gray-800 mb-6">The Future is Autonomous</h2>
                <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                  The evolution of Generative AI is moving beyond simple task automation towards fully autonomous agents that can manage complex workflows. These AI for business leaders agents will strategize, execute, and optimize entire business functions with minimal human oversight. Preparing your team for this AI automation shift is no longer optional—it&apos;s essential for survival and long-term market leadership.
                </p>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <BrainCircuit className="w-6 h-6 text-indigo-600 flex-shrink-0 mt-1" />
                    <p><span className="font-semibold text-dark">Predictive Strategy:</span> AI agents that forecast market trends and formulate proactive business strategies for AI for executives programs.</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <Zap className="w-6 h-6 text-indigo-600 flex-shrink-0 mt-1" />
                    <p><span className="font-semibold text-dark">Self-Optimizing Operations:</span> Autonomous systems that continuously refine marketing campaigns, supply chains, and customer service through AI workflow automation.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 md:py-20 px-4 sm:px-6 lg:px-8 bg-white">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-4 md:mb-6">
              Transform Your Team
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent"> Today</span>
            </h2>
            <p className="text-lg md:text-xl text-gray-600 mb-8 md:mb-12 leading-relaxed">
              Ready to give your team the AI for executives skills they need to drive growth and innovation?
              Let&apos;s discuss a customized AI strategy course workshop for your organization.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 md:gap-6 justify-center">
              <Button
                size="lg"
                className="bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white px-6 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 group"
                onClick={() => openModal('call')}>
                Book a Discovery Call
                <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Link to={createPageUrl("ai-implementation-agency")}>
                <Button
                  size="lg"
                  className="w-full sm:w-auto bg-white text-gray-900 px-6 md:px-10 py-3 md:py-4 text-base md:text-lg font-semibold rounded-2xl shadow-lg group transition-all duration-300 hover:bg-gray-100">
                  Learn About Our Agency Services
                  <ArrowRight className="w-4 h-4 md:w-5 md:h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
