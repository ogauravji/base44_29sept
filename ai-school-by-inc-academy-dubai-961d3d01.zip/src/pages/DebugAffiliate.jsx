import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { debugAffiliate } from '@/api/functions';

export default function DebugAffiliate() {
    const [email, setEmail] = useState('o.gaurav@gmail.com');
    const [results, setResults] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        
        try {
            const response = await debugAffiliate({ email });
            setResults(response.data);
        } catch (error) {
            console.error('Debug error:', error);
            setResults({ error: error.message });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="min-h-screen bg-gray-50 p-6">
            <div className="max-w-4xl mx-auto">
                <h1 className="text-3xl font-bold text-gray-900 mb-8">Debug Affiliate</h1>
                
                <Card className="mb-8">
                    <CardHeader>
                        <CardTitle>Check Affiliate Records</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <Input
                                type="email"
                                placeholder="Email address"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                            <Button type="submit" disabled={loading}>
                                {loading ? 'Checking...' : 'Check Records'}
                            </Button>
                        </form>
                    </CardContent>
                </Card>

                {results && (
                    <Card>
                        <CardHeader>
                            <CardTitle>Database Records</CardTitle>
                        </CardHeader>
                        <CardContent>
                            <pre className="bg-gray-100 p-4 rounded-lg overflow-auto text-sm">
                                {JSON.stringify(results, null, 2)}
                            </pre>
                        </CardContent>
                    </Card>
                )}
            </div>
        </div>
    );
}