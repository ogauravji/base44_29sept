
import React, { useState } from "react";
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { 
    Users, 
    DollarSign, 
    TrendingUp, 
    Target, 
    Gift,
    CheckCircle2,
    ArrowRight,
    Star,
    Globe,
    BarChart3,
    Zap,
    Instagram,
    Linkedin,
    Youtube,
    Twitter
} from "lucide-react";
import { createPageUrl } from "@/utils";
import { registerAffiliate } from '@/api/functions';

export default function AffiliateProgram() {
    const [formData, setFormData] = useState({
        full_name: '',
        email: '',
        phone: '',
        country: '',
        audience_size: '',
        primary_platform: '',
        content_niche: '',
        experience_level: 'Beginner',
        motivation: '',
        instagram: '',
        linkedin: '',
        youtube: '',
        tiktok: '',
        twitter: '',
        facebook: '',
        website: ''
    });
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isSubmitted, setIsSubmitted] = useState(false);

    const handleInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSelectChange = (name, value) => {
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setIsSubmitting(true);

        try {
            const response = await registerAffiliate(formData);
            
            if (response.data.success) {
                setIsSubmitted(true);
            } else {
                throw new Error(response.data.error || 'Application failed');
            }
        } catch (error) {
            console.error('Application error:', error);
            alert(`Application failed: ${error.message}. Please try again or contact support.`);
        } finally {
            setIsSubmitting(false);
        }
    };

    // Success state
    if (isSubmitted) {
        return (
            <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 flex items-center justify-center px-4 py-8">
                <motion.div
                    initial={{ opacity: 0, y: -30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6 }}
                    className="max-w-2xl mx-auto text-center"
                >
                    <Card className="shadow-2xl border-0 bg-white rounded-3xl overflow-hidden">
                        <CardContent className="p-12">
                            <div className="w-24 h-24 bg-gradient-to-r from-green-400 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8">
                                <CheckCircle2 className="w-12 h-12 text-white" />
                            </div>
                            
                            <h1 className="text-4xl font-bold text-gray-900 mb-4">
                                🎉 Application Submitted!
                            </h1>
                            
                            <p className="text-xl text-gray-600 mb-8">
                                Thank you for applying to become an Inc Academy affiliate partner!
                            </p>
                            
                            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 mb-8">
                                <h3 className="text-2xl font-bold text-gray-900 mb-4">What's Next?</h3>
                                <div className="space-y-4 text-left">
                                    <div className="flex items-start gap-3">
                                        <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                                        <div>
                                            <p className="font-semibold text-gray-900">Review Process</p>
                                            <p className="text-gray-600">Our team will review your application within 2-3 business days</p>
                                        </div>
                                    </div>
                                    <div className="flex items-start gap-3">
                                        <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                                        <div>
                                            <p className="font-semibold text-gray-900">Email Notification</p>
                                            <p className="text-gray-600">You'll receive an email with our decision and next steps</p>
                                        </div>
                                    </div>
                                    <div className="flex items-start gap-3">
                                        <CheckCircle2 className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                                        <div>
                                            <p className="font-semibold text-gray-900">Get Started</p>
                                            <p className="text-gray-600">If approved, you'll receive your unique affiliate link and resources</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div className="flex flex-col sm:flex-row gap-4 justify-center">
                                <Link to={createPageUrl('Home')}>
                                    <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 font-semibold rounded-xl">
                                        Back to Home
                                    </Button>
                                </Link>
                            </div>
                        </CardContent>
                    </Card>
                </motion.div>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-indigo-50">
            {/* Hero Section */}
            <section className="relative bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white overflow-hidden">
                <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(147,51,234,0.3),transparent)]"></div>
                <div className="absolute top-20 left-10 w-72 h-72 bg-purple-400/10 rounded-full blur-3xl"></div>
                <div className="absolute bottom-20 right-10 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl"></div>

                <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
                    <div className="text-center mb-16">
                        <Badge className="px-6 py-3 text-lg font-bold bg-gradient-to-r from-yellow-400 to-orange-500 text-black border-0 mb-8">
                            <Gift className="w-5 h-5 mr-2" />
                            EARN 25% COMMISSION
                        </Badge>

                        <h1 className="text-5xl md:text-6xl font-bold mb-8 leading-tight">
                            Inc Academy
                            <span className="bg-gradient-to-r from-cyan-400 to-pink-400 bg-clip-text text-transparent block mt-2">
                                Affiliate Program
                            </span>
                        </h1>

                        <p className="text-xl md:text-2xl text-blue-100 mb-12 max-w-3xl mx-auto leading-relaxed">
                            Partner with us and earn substantial commissions by promoting industry-leading AI training programs. 
                            Join hundreds of successful affiliates already earning with Inc Academy.
                        </p>

                        <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            <Link to={createPageUrl('AffiliateSignup')}>
                                <Button size="lg" className="bg-gradient-to-r from-yellow-500 to-orange-600 hover:from-yellow-600 hover:to-orange-700 text-black font-bold px-10 py-4 text-lg rounded-2xl shadow-lg">
                                    Create Account Now
                                    <ArrowRight className="w-5 h-5 ml-2" />
                                </Button>
                            </Link>
                        </div>
                    </div>

                    {/* Stats */}
                    <div className="grid md:grid-cols-3 gap-8">
                        {[
                            { icon: DollarSign, value: "25%", label: "Commission Rate" },
                            { icon: Users, value: "500+", label: "Active Affiliates" },
                            { icon: Target, value: "15%", label: "Avg. Conversion" }
                        ].map((stat, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 20 }}
                                animate={{ opacity: 1, y: 0 }}
                                transition={{ duration: 0.6, delay: index * 0.1 }}
                                className="text-center"
                            >
                                <div className="w-16 h-16 bg-white/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
                                    <stat.icon className="w-8 h-8 text-yellow-400" />
                                </div>
                                <h3 className="text-3xl font-bold mb-2">{stat.value}</h3>
                                <p className="text-blue-200">{stat.label}</p>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Program Benefits */}
            <section className="py-20 bg-white">
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                            Why Partner With Us?
                        </h2>
                        <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                            Join the most rewarding affiliate program in AI education with industry-leading commissions and support.
                        </p>
                    </div>

                    <div className="grid md:grid-cols-3 gap-8">
                        {[
                            {
                                icon: DollarSign,
                                title: "High Commissions",
                                description: "Earn 25% commission on every successful referral. Our premium courses mean higher earnings per sale."
                            },
                            {
                                icon: Globe,
                                title: "Global Market",
                                description: "Tap into the growing demand for AI skills worldwide. Perfect for any audience interested in professional development."
                            },
                            {
                                icon: BarChart3,
                                title: "Real-Time Tracking",
                                description: "Monitor your clicks, conversions, and earnings in real-time with our advanced tracking system."
                            },
                            {
                                icon: Zap,
                                title: "Marketing Support",
                                description: "Get access to proven marketing materials, email templates, and social media content that converts."
                            },
                            {
                                icon: Users,
                                title: "Dedicated Support",
                                description: "Work with our dedicated affiliate team who will help you maximize your earnings and success."
                            },
                            {
                                icon: Star,
                                title: "Premium Brand",
                                description: "Promote a trusted brand with 15+ years in digital education and thousands of satisfied students."
                            }
                        ].map((benefit, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.6, delay: index * 0.1 }}
                            >
                                <Card className="h-full hover:shadow-xl transition-all duration-300">
                                    <CardContent className="p-8 text-center">
                                        <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-blue-500 rounded-2xl flex items-center justify-center mx-auto mb-6">
                                            <benefit.icon className="w-8 h-8 text-white" />
                                        </div>
                                        <h3 className="text-xl font-bold mb-4 text-gray-900">{benefit.title}</h3>
                                        <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* FAQ Section */}
            <section className="py-20 bg-white">
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
                    <div className="text-center mb-16">
                        <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
                            Frequently Asked Questions
                        </h2>
                    </div>

                    <div className="space-y-8">
                        {[
                            {
                                question: "How much can I earn?",
                                answer: "You earn 25% commission on every successful referral. With our courses ranging from $99 to $2,500, your commissions can range from $25 to $625 per sale. Top affiliates earn $5,000+ per month."
                            },
                            {
                                question: "When do I get paid?",
                                answer: "Commissions are paid monthly via PayPal, bank transfer, or other preferred methods. Minimum payout is $100. You'll receive detailed reports of all your earnings and referrals."
                            },
                            {
                                question: "What marketing materials do you provide?",
                                answer: "We provide email templates, social media graphics, banner ads, product images, video promos, and detailed product information. All materials are professionally designed and proven to convert."
                            },
                            {
                                question: "Do I need to be approved?",
                                answer: "No! With our new streamlined process, you can create an account instantly and start promoting right away. Your account is activated immediately upon signup."
                            },
                            {
                                question: "Can I promote on social media?",
                                answer: "Absolutely! Social media promotion is encouraged. We provide platform-specific content and guidelines for Instagram, LinkedIn, YouTube, TikTok, and more."
                            }
                        ].map((faq, index) => (
                            <motion.div
                                key={index}
                                initial={{ opacity: 0, y: 20 }}
                                whileInView={{ opacity: 1, y: 0 }}
                                viewport={{ once: true }}
                                transition={{ duration: 0.6, delay: index * 0.1 }}
                            >
                                <Card className="hover:shadow-lg transition-shadow duration-300">
                                    <CardContent className="p-8">
                                        <h3 className="text-xl font-bold text-gray-900 mb-4">{faq.question}</h3>
                                        <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                                    </CardContent>
                                </Card>
                            </motion.div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Login Section for Existing Affiliates */}
            <section className="py-16 bg-gray-900 text-white">
                <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                    <h2 className="text-3xl md:text-4xl font-bold mb-6">
                        Already an Affiliate?
                    </h2>
                    <p className="text-xl text-gray-300 mb-8">
                        Access your dashboard to track earnings and get your affiliate links
                    </p>
                    <Link to={createPageUrl('AffiliateLogin')}>
                        <Button 
                            size="lg" 
                            className="bg-white text-gray-900 hover:bg-gray-100 px-8 py-4 font-bold rounded-xl"
                        >
                            Login to Dashboard
                            <ArrowRight className="w-5 h-5 ml-2" />
                        </Button>
                    </Link>
                </div>
            </section>
        </div>
    );
}
